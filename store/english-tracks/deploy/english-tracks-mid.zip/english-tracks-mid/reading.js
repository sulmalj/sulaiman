/* القطع (Reading) — كل قطعة مع أسئلتها — ملف مولّد بالسكربت tools/english/build_data.py (لا تعدّله يدوياً)
   o[0] = الإجابة الصحيحة (الخيارات تنخلط في الموقع) */
window.READING = [
{
"n": 1,
"k": 1,
"title": "Laughter in Hospitals and Schools",
"text": [
"1. There are many positive effects of laughter. Laughing is fun. Laughing helps us relax in stressful situations. Laughter also helps people forget about their pain and _facilitates_ learning. Indeed, one study found that students who laugh more remember more things and complete their homework more quickly. With these facts in mind, there are two areas where we should try to help people laugh more: hospitals and schools.",
"2. Hospitals, of course, have many people who are in pain. For serious pain, doctors _prescribe_ drugs to patients, but laughter could help reduce the need to take too many pills. How? One idea is for hospitals to make sure that each room has a television or a laptop where patients can watch funny videos. Another idea is for hospitals to give patients fun games to play with each other. This is probably better than funny videos because people laugh the most when they're around other people. Finally, hospitals can tell visitors how helpful laughter is. _They_ should try to make the patients they're visiting laugh.",
"3. Schools are another great place to use laughter. Professors and teachers usually work hard to create great lessons, but teachers rarely try hard enough to make their students laugh. One accounting professor, for example, knew that his lessons were boring, so he told the students a joke every five or ten minutes. The jokes weren't really funny, but his students still laughed. _They_ also remembered the lessons more. Simple ideas like this can make a big difference."
],
"qs": [
{
"q": "The writer thinks that telling students jokes is a ______.",
"o": [
"simple idea",
"funny idea",
"boring idea",
"great idea"
],
"e": "الفقرة 3 آخر جملة: «Simple ideas like this can make a big difference» ← الكاتب يعتبر فكرة النكت فكرة بسيطة (simple idea)."
},
{
"q": "People laugh the most when they're ______.",
"o": [
"around other people",
"in stressful situations",
"watching funny videos",
"not in pain or at school"
],
"e": "الفقرة 2: «people laugh the most when they're around other people»."
},
{
"q": "Laughter helps people ______ their pain.",
"o": [
"forget about",
"remember",
"explain",
"learn about"
],
"e": "الفقرة 1: «Laughter also helps people forget about their pain»."
},
{
"q": "Why does the writer think professors and teachers should try to make students laugh?",
"o": [
"Students will remember more from the lessons.",
"Students never complete their homework quickly.",
"Professors rarely make great efforts.",
"Classes are usually boring."
],
"e": "الفقرة 3: الطلاب ضحكوا و«They also remembered the lessons more» ← يتذكرون الدروس أكثر."
},
{
"q": "What does the underlined word \"facilitates\" in paragraph 1 mean?",
"o": [
"helps",
"remembers",
"stops",
"slows down"
],
"e": "facilitates learning = يسهّل التعلّم ويساعد عليه ← helps."
},
{
"q": "What does the underlined word \"prescribe\" in paragraph 2 mean?",
"o": [
"give",
"take",
"watch",
"use"
],
"e": "«doctors prescribe drugs to patients» = الدكتور يعطي (يصرف) الدواء للمريض ← give."
},
{
"q": "What does the underlined word \"They\" in paragraph 2 refer to?",
"o": [
"visitors",
"videos",
"hospitals",
"patients"
],
"e": "الجملة قبلها: «hospitals can tell visitors how helpful laughter is. They should try…» ← They = الزوار (visitors)."
},
{
"q": "What does the underlined word \"They\" in paragraph 3 refer to?",
"o": [
"The students",
"The professors",
"The jokes",
"The lessons"
],
"e": "الجملة قبلها: «his students still laughed. They also remembered…» ← They = الطلاب."
},
{
"q": "What is the best title for the passage?",
"o": [
"Two places that need more laughter",
"Patients and laughter",
"Students and laughter",
"The main reasons of laughter"
],
"e": "الفقرة 1: «there are two areas where we should try to help people laugh more: hospitals and schools» ← مكانين يحتاجون ضحك أكثر."
},
{
"q": "According to paragraph 1, students who laugh more ______.",
"o": [
"complete their homework more quickly",
"take fewer tests at school",
"sleep better at night",
"talk more in class"
],
"e": "الفقرة 1: «one study found that students who laugh more remember more things and complete their homework more quickly»."
}
],
"x": 1
},
{
"n": 2,
"k": 2,
"title": "Working From Home",
"text": [
"1. Alex begins his day with some coffee. Then he takes a short walk in a nearby park before _heading to_ work. But he doesn't need to go far. He just walks back home, opens up his laptop, and gets started. Alex works from home every day. You might think this sounds great. After all, many people don't like their offices. At home, they can make things exactly how they like. But many workers actually find working from home to be more stressful. Alex says this is true for him. He explains, \"It's like the workday never ends. When I used to go to an office, I'd leave work and not think about _it_ until the next day. Now, I answer emails and texts at all hours of the day.\"",
"2. Working from home is becoming more common and even normal in some industries. For employers, it saves money. They don't need to pay for office space. They also don't need to _spring for_ things like office parties, or provide places like game rooms where workers can relax. And then workers save a lot of time. In most countries, workers need 30 to 60 minutes to get to work. Working from home means you get an hour or two of extra time each day.",
"3. But, as we can see with Alex, it's not perfect for workers. That's why businesses should still try to reduce workplace stress. One idea is to provide online meditation classes. Workers can do something quiet together that helps _them_ improve their attention. Another idea is to just make a rule that says workers can't send emails after a certain time. Working from home certainly has its advantages, but it's not without problems. Ideas like these, though, can make it much better."
],
"qs": [
{
"q": "How much time do workers need to get to work in most countries?",
"o": [
"30 to 60 minutes",
"An hour or two",
"10 to 20 minutes",
"More than two hours"
],
"e": "الفقرة 2: «In most countries, workers need 30 to 60 minutes to get to work»."
},
{
"q": "Workers who take online meditation classes ______.",
"o": [
"can improve their attention",
"can't send emails after a certain time",
"go to the office every day",
"need more time to get to work"
],
"e": "الفقرة 3: «Workers can do something quiet together that helps them improve their attention»."
},
{
"q": "In paragraph 2, why does the writer mention not needing to provide places for workers to relax?",
"o": [
"To show how employers save money",
"To show that workers don't like game rooms",
"To explain why workers feel stressed",
"To show that offices are not safe"
],
"e": "الفقرة 2 تتكلم عن توفير المال: «For employers, it saves money… They also don't need to… provide places like game rooms» ← المثال يوضّح كيف يوفّر صاحب العمل."
},
{
"q": "What do the underlined words \"heading to\" in paragraph 1 mean?",
"o": [
"going to",
"coming back from",
"looking at",
"thinking about"
],
"e": "«before heading to work» = قبل ما يروح للعمل ← going to."
},
{
"q": "What does the underlined word \"it\" in paragraph 1 refer to?",
"o": [
"work",
"the park",
"the coffee",
"the laptop"
],
"e": "«I'd leave work and not think about it until the next day» ← it ترجع على work."
},
{
"q": "What do the underlined words \"spring for\" in paragraph 2 mean?",
"o": [
"pay for",
"look for",
"ask for",
"wait for"
],
"e": "«spring for things like office parties» = يدفع تكاليف الحفلات ← pay for."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"workers",
"businesses",
"classes",
"emails"
],
"e": "«Workers can do something quiet together that helps them…» ← them = العمّال (workers)."
},
{
"q": "Why does Alex find working from home stressful?",
"o": [
"He feels like the workday never ends.",
"He doesn't like his laptop.",
"He needs an hour to get to work.",
"His home is too noisy."
],
"e": "الفقرة 1: Alex يقول «It's like the workday never ends… I answer emails and texts at all hours»."
},
{
"q": "What does Alex do before he starts work?",
"o": [
"He has some coffee and takes a short walk.",
"He drives to his office in the city centre.",
"He reads the news on his phone in bed.",
"He goes to an online meditation class."
],
"e": "الفقرة 1: «Alex begins his day with some coffee. Then he takes a short walk in a nearby park»."
},
{
"q": "What is the best title for the passage?",
"o": [
"The Good and Bad Sides of Working From Home",
"Why Working From Home Is Perfect for Everyone",
"Why Offices Are Always Better Than Home",
"Office Parties: What Employers Should Pay For"
],
"e": "آخر الفقرة 3: «Working from home certainly has its advantages, but it's not without problems» ← فأفضل عنوان: The Good and Bad Sides of Working From Home"
}
],
"x": 1
},
{
"n": 3,
"k": 3,
"title": "Stress at Work",
"text": [
"1. The stress of modern jobs can make it challenging for employees to focus while they are working. This stress may also lead to employees getting sick more often or even quitting. When this happens, employers must use time and resources to find and train new employees.",
"2. Popular solutions for this problem may include buying plants for the office, providing lunches on birthdays, creating game rooms, and hosting meditation classes. These solutions may help some employees, but they don't _give a boost_ to everyone. Some employees, for example, say meditation doesn't support them at all and adds to their stress. They spend the whole time thinking about the problems in their lives, and it's hard to stop thinking about _them_ when they return to work afterwards.",
"3. In fact, the best solutions for workplace stress tend to happen _spontaneously_. Carefully planned solutions can feel like more work for employees, while those that happen in the moment tend to be more effective and enjoyable.",
"4. So, for example, instead of carefully planning a party, buying gifts, or building a game room, be ready to act quickly when you hear a good idea. Someone might say, \"I wish I could try every cake at that café.\" Suddenly, the boss could say, \"That's a great idea! Let's all go do it right now!\" Imagine working somewhere where fun things like that could happen at any moment. That doesn't sound like a stressful workplace at all!"
],
"qs": [
{
"q": "The writer says it's ______ for employees to focus while working.",
"o": [
"challenging",
"successful",
"interesting",
"relaxing"
],
"e": "الفقرة 1: «The stress of modern jobs can make it challenging for employees to focus»."
},
{
"q": "Some employees don't like meditation classes because the classes ______.",
"o": [
"add to their stress",
"use time and resources",
"take place during lunch",
"make them miss work"
],
"e": "الفقرة 2: «meditation doesn't support them at all and adds to their stress»."
},
{
"q": "The writer says that carefully planned solutions feel like ______ for employees.",
"o": [
"more work",
"more time",
"more rest",
"more fun"
],
"e": "الفقرة 3: «Carefully planned solutions can feel like more work for employees»."
},
{
"q": "The writer gives an example to show how ______.",
"o": [
"trying cakes together can be better than building a game room",
"planning a party can be better than building a game room",
"building a game room can be better than trying cakes",
"planning a party can be better than trying cakes"
],
"e": "الفقرة 4: بدل بناء غرفة ألعاب (building a game room)، المدير يقول «Let's all go do it right now!» ويروحون يجربون الكيك ← تجربة الكيك أحسن من بناء غرفة ألعاب."
},
{
"q": "Which idea for reducing stress does the writer NOT mention?",
"o": [
"buying books",
"buying plants",
"buying lunches",
"buying gifts"
],
"e": "الفقرة 2 ذكرت plants و lunches، والفقرة 4 ذكرت gifts. أما الكتب (books) ما انذكرت."
},
{
"q": "What do the underlined words \"give a boost\" in paragraph 2 mean?",
"o": [
"help",
"stress",
"entertain",
"stop"
],
"e": "«they don't give a boost to everyone» = ما تساعد الكل ← help."
},
{
"q": "What does the underlined word \"spontaneously\" in paragraph 3 mean?",
"o": [
"without planning",
"without helping",
"with careful thinking",
"with a lot of work"
],
"e": "الفقرة 3: الحلول «spontaneously» عكس «Carefully planned»، يعني تصير فجأة «in the moment» ← without planning."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"the problems in their lives",
"the employees",
"the meditation classes",
"the game rooms"
],
"e": "«thinking about the problems in their lives, and it's hard to stop thinking about them» ← them = المشاكل."
},
{
"q": "What happens when employees get sick often or quit?",
"o": [
"Employers must find and train new employees.",
"Employers must build more game rooms.",
"Employees must take more meditation classes.",
"Employees must work longer hours."
],
"e": "الفقرة 1: «employers must use time and resources to find and train new employees»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Spontaneous ways to reduce stress at work",
"How to plan a perfect office party",
"Why meditation is the best solution",
"Building game rooms at work"
],
"e": "القطعة كلها عن حلول ضغط العمل، وأحسنها اللي تصير بدون تخطيط (spontaneously)."
}
],
"x": 1
},
{
"n": 4,
"k": 4,
"title": "Saving Money as a Student",
"text": [
"1. For many university students, money is a common worry. Most of them have a small monthly income, such as a university allowance or some help from their families, but they still have to pay for books, transport, food and their phones. As a result, a lot of students reach the end of the month with an empty wallet and no idea where their money went. The good news is that saving money does not need a big income. It mainly needs a plan and a few good habits.",
"2. The first habit is to make a _budget_. This is a simple plan that shows how much money you receive each month and how you are going to spend it. To build one, write down everything you buy for two or three weeks, even a cup of coffee or a snack from the machine. Many students are shocked when they see the list, because small daily purchases can add up to several hundred riyals. Once you know where your money goes, it becomes much easier to control it.",
"3. The second habit is to reduce costs that you do not really need. For example, bringing lunch from home two or three times a week can save a lot of money over a semester. Instead of buying new textbooks, you can borrow them from the library or buy used copies from older students, who are often happy to sell _them_ at a low price. It is also wise to cancel app subscriptions that you rarely use.",
"4. Finally, experts suggest that students should \"pay themselves first.\" This means putting a small amount into savings as soon as the money arrives, before spending anything. Even 50 riyals a month is a good start, because the habit is more important than the amount. Students who _gradually_ build this habit are usually better prepared for unexpected costs, and they often manage their money more wisely after graduation."
],
"qs": [
{
"q": "According to paragraph 1, many students reach the end of the month ______.",
"o": [
"with an empty wallet and no idea where their money went",
"with enough money left to buy their books for next term",
"with a lot of money saved in the bank for the next month",
"with extra help from their families and some money to spare"
],
"e": "الفقرة 1: «a lot of students reach the end of the month with an empty wallet and no idea where their money went» ← يخلص الشهر وجيبهم فاضي وما يدرون وين راحت فلوسهم."
},
{
"q": "What does the underlined word \"budget\" in paragraph 2 mean?",
"o": [
"a plan for the money you receive and spend",
"a list of the books you need for the semester",
"a type of bank account for students who save",
"the monthly allowance that the university pays you"
],
"e": "الفقرة 2 تشرح الكلمة: «This is a simple plan that shows how much money you receive each month and how you are going to spend it»."
},
{
"q": "The writer gives the example of a cup of coffee to show that ______.",
"o": [
"even small purchases should be written down",
"students drink too much coffee",
"coffee is more expensive than books",
"students should stop buying snacks"
],
"e": "الفقرة 2: «write down everything you buy for two or three weeks, even a cup of coffee» ← حتى الأشياء الصغيرة تنكتب في القائمة."
},
{
"q": "Why are many students shocked when they see their list?",
"o": [
"Small daily purchases can add up to several hundred riyals.",
"Their books cost more than their food.",
"They forgot to write down their phone bills.",
"Their families send them less money than before."
],
"e": "الفقرة 2: «Many students are shocked when they see the list, because small daily purchases can add up to several hundred riyals»."
},
{
"q": "Which way of reducing costs does the writer NOT mention?",
"o": [
"Walking to university instead of driving",
"Bringing lunch from home a few times a week",
"Borrowing textbooks from the library",
"Cancelling some of your app subscriptions"
],
"e": "الفقرة 3 ذكرت الغداء من البيت، واستعارة الكتب من المكتبة، وإلغاء اشتراكات التطبيقات. أما المشي للجامعة بدل السيارة ما انذكر."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"the used textbooks",
"the older students",
"the libraries",
"the app subscriptions"
],
"e": "«buy used copies from older students, who are often happy to sell them» ← الطلاب الكبار يبيعون الكتب المستعملة، فـ them = الكتب المستعملة."
},
{
"q": "The writer says it is wise to cancel app subscriptions that you ______.",
"o": [
"rarely use",
"use every day",
"share with friends",
"pay for every week"
],
"e": "الفقرة 3: «It is also wise to cancel app subscriptions that you rarely use»."
},
{
"q": "According to paragraph 4, what does \"pay themselves first\" mean?",
"o": [
"Putting some money into savings as soon as it arrives",
"Buying the things you want before anything else",
"Paying all your bills at the end of the month",
"Asking your family for money before you spend"
],
"e": "الفقرة 4: «This means putting a small amount into savings as soon as the money arrives, before spending anything»."
},
{
"q": "What does the underlined word \"gradually\" in paragraph 4 mean?",
"o": [
"slowly over time",
"very quickly",
"all at once",
"only once"
],
"e": "gradually = تدريجياً، شوي شوي مع الوقت. يعني الطالب يبني عادة التوفير خطوة خطوة."
},
{
"q": "What is the best title for the passage?",
"o": [
"How Students Can Save Money",
"Why Students Need a Bigger Income to Save",
"Why Students Should Never Buy Coffee",
"The History of Saudi Money"
],
"e": "الفقرة 1: «It mainly needs a plan and a few good habits»، وباقي القطعة تشرح هذي العادات (الميزانية، تقليل المصاريف، التوفير أول ما يجي المال) ← فأفضل عنوان: How Students Can Save Money"
}
]
},
{
"n": 5,
"k": 5,
"title": "The Story of Coffee",
"text": [
"1. Today, coffee is one of the most popular drinks on the planet, and millions of people cannot imagine starting their day without it. However, few of them know that this ordinary drink has a long and interesting history. Its journey began in the highlands of Ethiopia, in East Africa, and it later passed through the Arabian Peninsula before it reached the rest of the world.",
"2. A famous old story explains how coffee was discovered. According to this story, a goat herder called Kaldi noticed that his goats became unusually _lively_ after eating red berries from a certain bush. They jumped around and did not want to sleep at night. Kaldi decided to try the berries himself, and he also felt more awake. Nobody knows if the story is true, but it is still told in many countries.",
"3. Historians agree that people in Yemen were drinking coffee by the fifteenth century. They roasted the beans inside the berries and boiled them in water, and some people drank the coffee to stay awake during the night. The port of Mocha became famous for selling coffee beans to traders from many countries. Soon, coffee houses opened in cities such as Mecca, Cairo and Istanbul. People went there to talk, play games and hear the latest news, so _they_ became important meeting places.",
"4. In the seventeenth century, traders brought coffee to Europe, and from there it spread across the world. Today it is prepared in many different ways, from espresso to Turkish coffee. In Saudi Arabia, Arabic coffee is usually light in colour and flavoured with cardamom, and it is served in small cups with dates. Offering it to guests is a tradition that shows _hospitality_, and in 2022 the country celebrated \"the Year of Saudi Coffee\" to honour this important part of its culture."
],
"qs": [
{
"q": "According to paragraph 1, where did the journey of coffee begin?",
"o": [
"In Ethiopia",
"In Yemen",
"In Istanbul",
"In Europe"
],
"e": "الفقرة 1: «Its journey began in the highlands of Ethiopia, in East Africa»."
},
{
"q": "What does the underlined word \"lively\" in paragraph 2 mean?",
"o": [
"active and full of energy",
"tired and sleepy",
"hungry",
"sick and weak"
],
"e": "lively = نشيط ومليان حيوية. والجملة بعدها تقول: «They jumped around and did not want to sleep at night»."
},
{
"q": "What did Kaldi do after he noticed the change in his goats?",
"o": [
"He tried the berries himself.",
"He sold the goats to traders.",
"He took the berries to Yemen.",
"He stopped the goats from eating the berries."
],
"e": "الفقرة 2: «Kaldi decided to try the berries himself, and he also felt more awake»."
},
{
"q": "The writer says that the story of Kaldi ______.",
"o": [
"may not be true, but it is still told",
"is supported by all historians of coffee",
"was written down by Kaldi himself",
"is only told to children in Ethiopia"
],
"e": "الفقرة 2: «Nobody knows if the story is true, but it is still told in many countries»."
},
{
"q": "How did people in Yemen prepare coffee?",
"o": [
"They roasted the beans and boiled them in water.",
"They ate the red berries without cooking them.",
"They mixed the beans with milk and dates.",
"They dried the leaves of the bush."
],
"e": "الفقرة 3: «They roasted the beans inside the berries and boiled them in water»."
},
{
"q": "Why did the port of Mocha become famous?",
"o": [
"It sold coffee beans to traders from many countries.",
"It had the first coffee house in the world.",
"It was the home of Kaldi and his goats.",
"It grew cardamom for Arabic coffee."
],
"e": "الفقرة 3: «The port of Mocha became famous for selling coffee beans to traders from many countries»."
},
{
"q": "What does the underlined word \"they\" in paragraph 3 refer to?",
"o": [
"coffee houses",
"people",
"games",
"traders"
],
"e": "«coffee houses opened… People went there to talk… so they became important meeting places» ← اللي صارت أماكن لقاء هي المقاهي."
},
{
"q": "Which activity in coffee houses does the writer NOT mention?",
"o": [
"reading books",
"talking",
"playing games",
"hearing the latest news"
],
"e": "الفقرة 3: «People went there to talk, play games and hear the latest news». وقراءة الكتب ما انذكرت."
},
{
"q": "What does the underlined word \"hospitality\" in paragraph 4 mean?",
"o": [
"being friendly and generous to guests",
"being proud of your country",
"being careful with money",
"being quiet and polite at work"
],
"e": "hospitality = الضيافة والكرم مع الضيوف. والجملة نفسها: «Offering it to guests is a tradition that shows hospitality»."
},
{
"q": "What is the best title for the passage?",
"o": [
"The long journey of coffee",
"How to make Arabic coffee",
"Kaldi and his goats",
"Coffee houses in Istanbul"
],
"e": "القطعة تحكي رحلة القهوة من إثيوبيا لليمن ثم المدن العربية وأوروبا والعالم، لين وصلت للقهوة السعودية اليوم."
}
]
},
{
"n": 6,
"k": 6,
"title": "Electric Cars",
"text": [
"1. Electric cars are no longer a strange sight. In many countries, more and more drivers are choosing them instead of cars that run on petrol. An electric car does not have a normal engine. Instead, it has a large battery that drivers charge with electricity, either at home or at a public charging station. Many governments _encourage_ people to buy these cars, and some offer lower taxes or other benefits to those who do.",
"2. Supporters of electric cars point out several advantages. Because the cars do not burn fuel, they produce no smoke from an exhaust pipe, which helps to keep the air in busy cities cleaner. They are also very quiet, so streets with many electric cars are less noisy. In addition, electricity usually costs less than petrol for the same distance, and electric cars need less repair work because they have fewer moving parts.",
"3. However, electric cars are not perfect. First, they are often more expensive to buy than similar petrol cars, mainly because batteries cost a lot to make. Second, charging takes time. At a fast charger, a battery can be mostly full in around thirty minutes, but at home it may take a whole night. Third, there are still not enough charging stations in some areas, so drivers who travel long distances between cities may worry that _they_ will run out of power on the road.",
"4. Most experts _expect_ these problems to become smaller in the coming years. Battery prices have fallen a lot over the last ten years, and new batteries can store more energy than older ones. At the same time, companies are building charging stations along highways and in shopping centres. For these reasons, many people believe that electric cars will soon become the normal choice for new drivers, although petrol cars will probably stay on the roads for a long time."
],
"qs": [
{
"q": "According to paragraph 1, what does an electric car have instead of a normal engine?",
"o": [
"a large battery",
"a petrol tank",
"a solar panel",
"an exhaust pipe"
],
"e": "الفقرة 1: «An electric car does not have a normal engine. Instead, it has a large battery»."
},
{
"q": "What does the underlined word \"encourage\" in paragraph 1 mean?",
"o": [
"give support so that people want to do something",
"make something difficult for people to do",
"stop people from doing something they want",
"complain to people about something they do"
],
"e": "encourage = يشجّع، يعني يخلّي الناس يبون يسوون الشي. الفقرة 1: «Many governments encourage people to buy these cars»."
},
{
"q": "What do some governments offer to people who buy electric cars?",
"o": [
"lower taxes or other benefits",
"free electricity for a year",
"a free charging station at home",
"free repair work"
],
"e": "الفقرة 1: «some offer lower taxes or other benefits to those who do»."
},
{
"q": "Which advantage of electric cars does the writer NOT mention?",
"o": [
"They are safer in accidents.",
"They produce no smoke from an exhaust pipe.",
"They are very quiet.",
"They need less repair work."
],
"e": "الفقرة 2 ذكرت: ما فيها دخان، وهادية، والكهرباء أرخص، وتصليحها أقل. أما إنها أأمن في الحوادث ما انذكر."
},
{
"q": "Why do electric cars need less repair work?",
"o": [
"They have fewer moving parts.",
"They do not burn fuel.",
"Their batteries are cheap.",
"They are very quiet."
],
"e": "الفقرة 2: «electric cars need less repair work because they have fewer moving parts»."
},
{
"q": "Why are electric cars often more expensive to buy?",
"o": [
"Batteries cost a lot to make.",
"They need more repair work.",
"Governments add higher taxes to them.",
"Electricity costs more than petrol."
],
"e": "الفقرة 3: «they are often more expensive to buy than similar petrol cars, mainly because batteries cost a lot to make»."
},
{
"q": "How long may charging take at home?",
"o": [
"a whole night",
"around thirty minutes",
"a few minutes",
"a whole week"
],
"e": "الفقرة 3: «at home it may take a whole night». أما الثلاثين دقيقة فهي في الشاحن السريع (fast charger)."
},
{
"q": "What does the underlined word \"they\" in paragraph 3 refer to?",
"o": [
"drivers",
"charging stations",
"cities",
"batteries"
],
"e": "«drivers who travel long distances between cities may worry that they will run out of power» ← اللي يخاف هم السائقين، فـ they = drivers."
},
{
"q": "What does the underlined word \"expect\" in paragraph 4 mean?",
"o": [
"think that something will happen",
"want something to stop",
"forget about something",
"be angry about something"
],
"e": "expect = يتوقّع. الخبراء يتوقعون إن المشاكل بتصغر «in the coming years»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Electric Cars: Benefits, Problems and the Future",
"Why Nobody Will Ever Buy an Electric Car",
"The End of Petrol Cars in the Next Few Years",
"Why Electric Cars Have No Future Without Chargers"
],
"e": "الفقرة 2 المميزات، والفقرة 3 العيوب، والفقرة 4: «electric cars will soon become the normal choice for new drivers». (وقالت إن سيارات البنزين بتبقى وقت طويل، فما بتختفي قريب.) ← فأفضل عنوان: Electric Cars: Benefits, Problems and the Future"
}
]
},
{
"n": 7,
"k": 7,
"title": "Paper Books or E-books?",
"text": [
"1. Not long ago, reading a book meant holding paper in your hands. Today, however, many people read on phones, tablets or special devices called e-readers. These digital books, or e-books, have become very popular, especially among young people. As a result, a common question is whether e-books will one day replace paper books completely, or whether both will continue to exist side by side.",
"2. E-books certainly have some clear advantages. A small e-reader can hold thousands of books, which makes it very _convenient_ for students and travellers who do not want to carry heavy bags. E-books are often cheaper than printed copies, and you can download one in seconds without leaving your home. Readers can also change the size of the letters, which is helpful for older people or anyone with weak eyesight. Some devices even include a dictionary, so you can check the meaning of a new word immediately.",
"3. On the other hand, many readers still prefer paper books, and research suggests they may have a good reason. In several studies, people who read a text on paper understood and remembered it slightly better than people who read the same text on a screen. One possible explanation is that screens come with many _distractions_. While you are reading on a phone, messages and notifications keep appearing, and it is easy to stop reading and check _them_. In addition, looking at a bright screen for hours can make your eyes feel tired and dry.",
"4. So which kind of book is better? The answer probably depends on the reader and the situation. A student might use an e-book to search quickly for information, but choose a printed book for serious study before an exam. Many people simply enjoy both. In the end, the format matters less than the habit itself, because people who read regularly improve their vocabulary, their writing and their ability to think clearly."
],
"qs": [
{
"q": "According to paragraph 1, what is a common question about e-books?",
"o": [
"Whether they will replace paper books completely",
"Whether they are good for young people",
"How much an e-reader costs",
"Who made the first e-book"
],
"e": "الفقرة 1: «a common question is whether e-books will one day replace paper books completely»."
},
{
"q": "What does the underlined word \"convenient\" in paragraph 2 mean?",
"o": [
"easy and useful",
"heavy and large",
"expensive",
"difficult to use"
],
"e": "convenient = مريح وسهل الاستخدام. لأن جهاز صغير يشيل آلاف الكتب بدل الشنط الثقيلة."
},
{
"q": "Who is helped when readers change the size of the letters?",
"o": [
"older people or anyone with weak eyesight",
"students who travel a lot",
"people who read very fast",
"children who are learning to read"
],
"e": "الفقرة 2: «Readers can also change the size of the letters, which is helpful for older people or anyone with weak eyesight»."
},
{
"q": "Which advantage of e-books does the writer NOT mention?",
"o": [
"They do not need electricity.",
"They are often cheaper.",
"You can download them in seconds.",
"Some devices include a dictionary."
],
"e": "الفقرة 2 ذكرت: أرخص، وتنزّله في ثواني، وبعض الأجهزة فيها قاموس. أما إنها ما تحتاج كهرباء ما انذكر."
},
{
"q": "According to several studies, people who read on paper ______.",
"o": [
"understood and remembered the text slightly better",
"read much faster than people who used a screen",
"preferred e-books for serious study",
"got tired more quickly than screen readers"
],
"e": "الفقرة 3: «people who read a text on paper understood and remembered it slightly better than people who read the same text on a screen»."
},
{
"q": "What does the underlined word \"distractions\" in paragraph 3 mean?",
"o": [
"things that take your attention away",
"things that help you remember a text",
"small dictionaries inside a device",
"prices that are lower than usual"
],
"e": "distractions = أشياء تشتّت انتباهك وتبعدك عن القراءة. والجملة بعدها توضّح: «it is easy to stop reading»."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"messages and notifications",
"the pages you are reading",
"studies about reading",
"your tired eyes"
],
"e": "«messages and notifications keep appearing, and it is easy to stop reading and check them» ← them = الرسائل والتنبيهات."
},
{
"q": "What can happen if you look at a bright screen for hours?",
"o": [
"Your eyes can feel tired and dry.",
"You can remember more information.",
"Your phone can stop working.",
"You can read more quickly."
],
"e": "الفقرة 3: «looking at a bright screen for hours can make your eyes feel tired and dry»."
},
{
"q": "The writer gives the example of a student to show that ______.",
"o": [
"people may choose a different kind of book for different situations",
"e-books are always better than paper books for serious study",
"students no longer use printed books, even before their exams",
"e-books are too slow for students who need to search for information"
],
"e": "الفقرة 4: «The answer probably depends on the reader and the situation. A student might use an e-book to search quickly for information, but choose a printed book for serious study» ← يختار حسب الموقف."
},
{
"q": "What is the best title for the passage?",
"o": [
"Paper or Screen: What Matters Is Reading",
"Why E-books Will Soon Replace Paper Books",
"Why Nobody Should Read on a Screen",
"E-books: The Only Choice for Students"
],
"e": "القطعة تذكر مميزات الكتب الإلكترونية (الفقرة 2) والورقية (الفقرة 3)، وآخرها: «the format matters less than the habit itself» ← فأفضل عنوان: Paper or Screen: What Matters Is Reading"
}
]
},
{
"n": 8,
"k": 8,
"title": "Social Media and the News",
"text": [
"1. In the past, people waited for the evening news on TV or bought a newspaper in the morning to find out what was happening in the world. Today, the situation is very different. A large number of young people now get most of their news from social media apps on their phones. On these apps, a story can be shared by thousands of users within minutes, so news travels faster than ever before.",
"2. This change has brought some real benefits. People can follow important events as they happen, and they can see photos and videos posted by ordinary people who are actually there, not only by professional journalists. During emergencies such as floods or heavy storms, official accounts can quickly warn people and tell _them_ which roads to avoid. Social media also allows people to discuss the news and share different opinions.",
"3. However, the speed of social media has a serious disadvantage. Many posts are shared before anyone checks whether they are true, which allows false information, often called fake news, to spread easily. Some people share fake stories by mistake because the stories look real. Others create them on purpose, because shocking stories attract attention and more followers. Fake news can _mislead_ people and cause unnecessary fear, for example when a false message claims that a popular product is dangerous.",
"4. Fortunately, there are simple ways to protect yourself. First, check the source: is the story from a well-known news organisation or an official account, or from an unknown page? Second, see whether other _reliable_ websites are reporting the same story. Third, look carefully at the date, because old stories are sometimes shared again as if they were new. Finally, if you are still not sure, do not share the post. Being a careful reader is now an important skill for everyone."
],
"qs": [
{
"q": "According to paragraph 1, how did people find out the news in the past?",
"o": [
"They watched the news on TV or bought a newspaper.",
"They used social media apps on their phones.",
"They asked journalists to tell them the news.",
"They followed official accounts on the internet."
],
"e": "الفقرة 1: «people waited for the evening news on TV or bought a newspaper in the morning»."
},
{
"q": "The writer says that on social media, news travels ______.",
"o": [
"faster than ever before",
"more slowly than on TV",
"only among journalists",
"only in the evening"
],
"e": "الفقرة 1: «a story can be shared by thousands of users within minutes, so news travels faster than ever before»."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"people",
"official accounts",
"roads",
"floods and storms"
],
"e": "«official accounts can quickly warn people and tell them which roads to avoid» ← الحسابات الرسمية تقول للناس، فـ them = people."
},
{
"q": "Which benefit of social media does the writer NOT mention?",
"o": [
"It helps people find jobs.",
"People can follow events as they happen.",
"People can see photos and videos from ordinary people.",
"People can discuss the news and share opinions."
],
"e": "الفقرة 2 ذكرت متابعة الأحداث وقت حدوثها، وصور وفيديوهات الناس العاديين، والنقاش وتبادل الآراء. أما إيجاد وظائف ما انذكر."
},
{
"q": "Why do some people create fake stories on purpose?",
"o": [
"Shocking stories attract attention and more followers.",
"They want to warn people quickly during floods and storms.",
"They believe the stories are real and want to help others.",
"They want to see whether other websites report the same story."
],
"e": "الفقرة 3: «Others create them on purpose, because shocking stories attract attention and more followers». (اللي يحسبها صحيحة هذا ينشرها بالغلط، مو يصنعها.)"
},
{
"q": "What does the underlined word \"mislead\" in paragraph 3 mean?",
"o": [
"make someone believe something that is not true",
"help someone understand the news more clearly",
"make someone check the source of a story",
"make someone feel safe during an emergency"
],
"e": "mislead = يضلّل، يخلي الشخص يصدّق شي غلط. والكلام عن الأخبار الكاذبة."
},
{
"q": "The writer gives the example of a false message about a popular product to show that fake news can ______.",
"o": [
"cause unnecessary fear",
"help people avoid danger",
"make products cheaper",
"stop people from using social media"
],
"e": "الفقرة 3: «Fake news can mislead people and cause unnecessary fear, for example when a false message claims that a popular product is dangerous»."
},
{
"q": "What does the underlined word \"reliable\" in paragraph 4 mean?",
"o": [
"that you can trust",
"that is very new",
"that is very popular",
"that nobody knows"
],
"e": "reliable = موثوق، تقدر تثق فيه، زي المواقع الإخبارية المعروفة. وعكسها «an unknown page»."
},
{
"q": "Why should readers look carefully at the date of a story?",
"o": [
"Old stories are sometimes shared again as if they were new.",
"New stories are always fake, so you should not share them.",
"Official accounts do not write the date.",
"Old stories are more reliable than new ones."
],
"e": "الفقرة 4: «look carefully at the date, because old stories are sometimes shared again as if they were new»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Social Media News: Check Before You Share",
"Why Newspapers Are Never Wrong About the News",
"Only Journalists Should Post News Online",
"Social Media: Useful Only During Floods and Storms"
],
"e": "القطعة تذكر فوائد الأخبار في السوشال ميديا (الفقرة 2)، ومشكلة الأخبار الكاذبة (الفقرة 3)، وكيف نتأكد قبل ما ننشر (الفقرة 4) ← فأفضل عنوان: Social Media News: Check Before You Share"
}
]
},
{
"n": 9,
"k": 9,
"title": "Camels: Ships of the Desert",
"text": [
"1. For thousands of years, camels have played a central role in the life of the Arabian Peninsula. Before cars and planes existed, they carried people and goods across huge deserts, and caravans of camels connected towns and markets that were hundreds of kilometres apart. Families also depended on them for milk, meat, wool and leather. Because camels can cross the sand for long distances, people have long called them \"ships of the desert.\"",
"2. Camels are perfectly suited to hot and dry places. Many people believe that the hump is full of water, but in fact it stores fat. When food is hard to find, the camel's body can use this fat for energy. Camels can also _survive_ for many days without drinking, and when they finally find water, they can drink as much as 100 litres in about ten minutes. Their bodies lose very little water, which helps them stay healthy in extreme heat.",
"3. The camel's body also protects it from the desert in other ways. Two rows of long eyelashes keep sand out of its eyes, and it can close its nostrils during sandstorms. Its large, wide feet spread out when they touch the ground, so _they_ do not sink into soft sand. Thick pads of hard skin on its knees and chest allow the animal to sit _comfortably_ on hot ground.",
"4. Even in modern Saudi Arabia, where most people travel by car, camels remain an important part of the culture. Camel milk is popular because it is healthy and contains a lot of vitamin C. Camel racing is a well-known sport, and in beauty competitions, judges look at features such as the shape of the camel's head and hump. One of the largest of these events is the King Abdulaziz Camel Festival, which takes place every year and attracts visitors from Saudi Arabia and other countries."
],
"qs": [
{
"q": "According to paragraph 1, what did caravans of camels do in the past?",
"o": [
"They connected towns and markets that were far apart.",
"They carried cars and planes across the huge deserts.",
"They took part in races between towns and markets.",
"They protected towns and markets from strong sandstorms."
],
"e": "الفقرة 1: «caravans of camels connected towns and markets that were hundreds of kilometres apart»."
},
{
"q": "Which product that families got from camels does the writer NOT mention?",
"o": [
"cheese",
"milk",
"wool",
"leather"
],
"e": "الفقرة 1: «Families also depended on them for milk, meat, wool and leather». والجبن (cheese) ما انذكر."
},
{
"q": "What does a camel's hump really store?",
"o": [
"fat",
"water",
"milk",
"vitamins"
],
"e": "الفقرة 2: «Many people believe that the hump is full of water, but in fact it stores fat»."
},
{
"q": "What does the underlined word \"survive\" in paragraph 2 mean?",
"o": [
"stay alive",
"become sick",
"travel fast",
"fall asleep"
],
"e": "survive = يعيش ويبقى حي. يعني الجمل يقدر يعيش أيام كثيرة بدون ما يشرب."
},
{
"q": "How much water can a camel drink in about ten minutes?",
"o": [
"as much as 100 litres",
"about 10 litres",
"about 1,000 litres",
"about 1 litre"
],
"e": "الفقرة 2: «they can drink as much as 100 litres in about ten minutes»."
},
{
"q": "What keeps sand out of a camel's eyes?",
"o": [
"two rows of long eyelashes",
"its large, wide feet",
"the pads on its knees",
"its hump"
],
"e": "الفقرة 3: «Two rows of long eyelashes keep sand out of its eyes»."
},
{
"q": "What does the underlined word \"they\" in paragraph 3 refer to?",
"o": [
"the camel's feet",
"the eyelashes",
"the nostrils",
"sandstorms"
],
"e": "«Its large, wide feet spread out when they touch the ground, so they do not sink into soft sand» ← اللي ما تغرق في الرمل هي الأقدام."
},
{
"q": "What does the underlined word \"comfortably\" in paragraph 3 mean?",
"o": [
"without pain or difficulty",
"very quickly",
"with a lot of noise",
"for a short time only"
],
"e": "comfortably = براحة، بدون ألم أو صعوبة. لأن الجلد القاسي على الركب والصدر يحميه من الأرض الحارة."
},
{
"q": "Why is camel milk popular?",
"o": [
"It is healthy and contains a lot of vitamin C.",
"It is cheaper than other kinds of milk.",
"It is given to the winners of camel races.",
"It is only sold at the camel festival."
],
"e": "الفقرة 4: «Camel milk is popular because it is healthy and contains a lot of vitamin C»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Camels: Ships of the Desert",
"Camels: No Longer Important in Saudi Arabia",
"How Camels Store Water in Their Humps",
"Camel Racing: Saudi Arabia's Most Popular Sport"
],
"e": "الفقرة 2 و3 تشرح كيف جسم الجمل مناسب للصحراء، والفقرة 4: «camels remain an important part of the culture» ← فأفضل عنوان: Camels: Ships of the Desert"
}
]
},
{
"n": 10,
"k": 10,
"title": "Recycling at Home",
"text": [
"1. Every household produces rubbish: empty bottles, food packaging, old newspapers and leftover food. In many cities, most of this waste is taken to landfills, which are huge areas of land where rubbish is buried. Landfills take up a lot of space, and some materials stay there for a very long time. A plastic bottle, for example, can take hundreds of years to break down. Recycling is one of the easiest ways to _reduce_ this problem, and it can begin in your own kitchen.",
"2. Recycling means collecting used materials and turning them into new products. Old newspapers can become new paper or cardboard boxes, glass jars can be melted to make new jars, and plastic bottles can be made into new bottles or even the material used in some clothes. Aluminium cans are especially valuable, because they can be recycled again and again without losing quality. In this way, recycling saves energy and protects natural resources such as trees, water and metals.",
"3. Starting at home does not have to be complicated. First, find out which materials are collected in your area, because the rules are different from city to city. Next, keep two or three separate bins or bags, for example one for paper and cardboard and one for plastic and metal. Rinse bottles and cans before you put _them_ in the bin, since dirty items can spoil a whole bag of clean materials. Finally, take full bags to a recycling point or put them out on the right collection day.",
"4. However, recycling should not be the first step. The best way to protect the environment is to produce less waste in the first place. Families can carry reusable shopping bags, buy products with less packaging and repair broken items instead of throwing them away. When _ordinary_ families make small changes like these every day, the total effect on the environment can be enormous."
],
"qs": [
{
"q": "According to paragraph 1, what are landfills?",
"o": [
"huge areas of land where rubbish is buried",
"places where materials are recycled",
"factories that make plastic bottles",
"special bins for food waste"
],
"e": "الفقرة 1: «landfills, which are huge areas of land where rubbish is buried»."
},
{
"q": "What does the underlined word \"reduce\" in paragraph 1 mean?",
"o": [
"make smaller or less",
"make bigger or more",
"explain or describe",
"start or create"
],
"e": "reduce = يقلّل. يعني إعادة التدوير تخفّف مشكلة النفايات."
},
{
"q": "Why are aluminium cans especially valuable?",
"o": [
"They can be recycled again and again without losing quality.",
"They break down in a few days in a landfill.",
"They are the easiest material to clean at home.",
"They can be made into the material used in clothes."
],
"e": "الفقرة 2: «Aluminium cans are especially valuable, because they can be recycled again and again without losing quality»."
},
{
"q": "Which natural resource does the writer NOT mention?",
"o": [
"oil",
"trees",
"water",
"metals"
],
"e": "الفقرة 2: «protects natural resources such as trees, water and metals». والنفط (oil) ما انذكر."
},
{
"q": "Why should people find out which materials are collected in their area?",
"o": [
"The rules are different from city to city.",
"Some materials are dangerous to collect.",
"Recycling points are only open once a year.",
"Landfills do not accept plastic."
],
"e": "الفقرة 3: «find out which materials are collected in your area, because the rules are different from city to city»."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"bottles and cans",
"separate bins",
"full bags",
"recycling points"
],
"e": "«Rinse bottles and cans before you put them in the bin» ← them = القوارير والعلب."
},
{
"q": "According to paragraph 3, why is it important to put only clean items in the recycling bin?",
"o": [
"Dirty items can spoil a whole bag of clean materials.",
"Clean items are heavier and easier to carry.",
"Recycling points pay more for clean items.",
"Clean bottles can be used again at home."
],
"e": "الفقرة 3: «since dirty items can spoil a whole bag of clean materials» ← الشي الوسخ يخرّب كيس كامل من المواد النظيفة."
},
{
"q": "What does the underlined word \"ordinary\" in paragraph 4 mean?",
"o": [
"normal, not special",
"rich, with a lot of money",
"famous, known by many people",
"large, with many children"
],
"e": "ordinary = عادي. يعني الأسر العادية لو سوّت تغييرات صغيرة كل يوم يصير لها أثر كبير."
},
{
"q": "The writer's main point in paragraph 4 is that ______.",
"o": [
"producing less waste is better than recycling it",
"recycling is the only way to help the environment",
"families should buy more shopping bags",
"broken items cannot be repaired"
],
"e": "الفقرة 4: «recycling should not be the first step. The best way to protect the environment is to produce less waste in the first place»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Recycling and reducing waste at home",
"How plastic bottles are made",
"The history of landfills",
"Why aluminium is valuable"
],
"e": "القطعة عن مشكلة النفايات، وكيف ندوّر في البيت خطوة خطوة، وفي الأخير تقليل النفايات من البداية."
}
]
},
{
"n": 11,
"k": 11,
"title": "Shopping Online or in Stores?",
"text": [
"1. Twenty years ago, buying a new phone or a pair of shoes usually meant a trip to a shop or a shopping centre. Today, millions of people in Saudi Arabia and around the world buy these things with a few taps on their phones. Online shopping has grown very quickly, especially since delivery services became faster and more common. However, shops and malls are still full of customers, which shows that both ways of shopping have something to offer.",
"2. For many people, the biggest advantage of online shopping is convenience. You can order at midnight from your bed, and you do not need to drive through traffic or look for a parking space. It is also easy to compare the prices of the same product on several websites, which helps shoppers find a better _deal_. Customer reviews are another benefit, because they allow you to learn about other buyers' experiences before you decide.",
"3. On the other hand, online shopping has some disadvantages. You cannot touch a product or try it on, so clothes and shoes sometimes arrive in the wrong size or look different from the photos. Returning these items can take time and _effort_. Some shoppers also worry about giving their card details to websites that they do not know well. In addition, it is easy to spend too much money when buying is so fast and simple.",
"4. Physical stores offer things that a screen cannot. Shoppers can ask staff for advice, check the quality of a product with their own eyes and take _it_ home immediately. For many Saudi families, a visit to the mall is also a social activity: they walk around together, eat at a restaurant and meet friends. For these reasons, most people do not choose only one option. Instead, they shop online for some things and visit stores for others, depending on what they need."
],
"qs": [
{
"q": "According to paragraph 1, why has online shopping grown so quickly?",
"o": [
"Delivery services became faster and more common.",
"Many shops and malls closed and lost their customers.",
"Phones and computers became much cheaper than before.",
"Prices online became lower than prices in all stores."
],
"e": "الفقرة 1: «Online shopping has grown very quickly, especially since delivery services became faster and more common»."
},
{
"q": "The writer says that shops and malls are still full of customers, which shows that ______.",
"o": [
"both ways of shopping have something to offer",
"online shopping is not popular in Saudi Arabia",
"people prefer stores for everything they buy",
"delivery services are too slow"
],
"e": "الفقرة 1: «shops and malls are still full of customers, which shows that both ways of shopping have something to offer»."
},
{
"q": "Which advantage of online shopping does the writer NOT mention?",
"o": [
"free delivery",
"ordering at any time, even at midnight",
"comparing prices on several websites",
"reading customer reviews"
],
"e": "الفقرة 2 ذكرت الطلب نص الليل، ومقارنة الأسعار، وتقييمات المشترين. أما التوصيل المجاني ما انذكر."
},
{
"q": "What does the underlined word \"deal\" in paragraph 2 mean?",
"o": [
"a good price for something you buy",
"a shop where you can buy things",
"a fast way to deliver products",
"a review written by a customer"
],
"e": "«find a better deal» = تلقى سعر أو عرض أحسن، والجملة عن مقارنة الأسعار."
},
{
"q": "Why are customer reviews useful?",
"o": [
"They let you learn about other buyers' experiences.",
"They let you return the wrong sizes quickly and easily.",
"They protect your card details on websites you do not know.",
"They let you get your orders delivered much faster."
],
"e": "الفقرة 2: «they allow you to learn about other buyers' experiences before you decide»."
},
{
"q": "Why do clothes and shoes sometimes arrive in the wrong size?",
"o": [
"Shoppers cannot touch them or try them on.",
"Websites send the wrong items on purpose.",
"Delivery services are too fast.",
"Shoppers do not read the reviews."
],
"e": "الفقرة 3: «You cannot touch a product or try it on, so clothes and shoes sometimes arrive in the wrong size»."
},
{
"q": "What does the underlined word \"effort\" in paragraph 3 mean?",
"o": [
"hard work",
"money",
"luck",
"happiness"
],
"e": "effort = جهد وتعب. يعني إرجاع الأغراض ياخذ وقت وجهد."
},
{
"q": "What does the underlined word \"it\" in paragraph 4 refer to?",
"o": [
"a product",
"a screen",
"the mall",
"advice"
],
"e": "«check the quality of a product with their own eyes and take it home immediately» ← it = المنتج."
},
{
"q": "The writer gives the example of Saudi families at the mall to show that ______.",
"o": [
"shopping in stores can be a social activity",
"malls are cheaper than websites",
"families prefer to shop at midnight",
"restaurants are more popular than shops"
],
"e": "الفقرة 4: «For many Saudi families, a visit to the mall is also a social activity»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Online Shopping and Stores: Pros and Cons",
"Why Online Shopping Will Replace All Malls",
"Why Stores Are Always Cheaper",
"Online Shopping Is Never Safe"
],
"e": "القطعة تقارن بين الطريقتين: مميزات التسوق أونلاين (الفقرة 2) وعيوبه (الفقرة 3) ومميزات المحلات (الفقرة 4) ← فأفضل عنوان: Online Shopping and Stores: Pros and Cons"
}
]
},
{
"n": 12,
"k": 12,
"title": "Learning to Cook",
"text": [
"1. Many young people today leave home for university without knowing how to cook even a simple meal. Instead, they depend on restaurants, fast food and delivery apps. This is quick and easy, but it has two clear disadvantages. First, eating out every day is expensive, and second, many restaurant meals contain more oil, salt and sugar than our bodies need. Learning to cook is a practical solution to both problems.",
"2. When you prepare food at home, you are in control. You choose fresh _ingredients_, you decide how much salt or oil to use, and you can make portions that are the right size for you. Cooking at home is also much cheaper. A meal that costs 40 riyals from a delivery app might cost less than half that amount if you make it yourself, and leftovers can be kept in the fridge for the next day's lunch.",
"3. Beginners often feel _nervous_ because they think cooking needs special talent. In fact, it is a skill that anyone can learn with practice. It is best to start with a few simple dishes, such as an omelette, rice, pasta or a fresh salad, and then try more difficult recipes later. Online videos show every step clearly, and family members are usually happy to help. Asking your mother or grandmother to teach you a traditional dish like kabsa is a lovely way to learn and to spend time with _her_.",
"4. Cooking has other benefits as well. Many people find it relaxing, because it gives them a break from screens and studying. It also builds confidence: the first time you cook a meal for your friends or family and they enjoy it, you will feel very proud. So instead of ordering food again tonight, why not open the fridge and create something yourself?"
],
"qs": [
{
"q": "According to paragraph 1, what do many young people depend on instead of cooking?",
"o": [
"restaurants, fast food and delivery apps",
"their friends at university",
"frozen food from the supermarket",
"the university restaurant only"
],
"e": "الفقرة 1: «they depend on restaurants, fast food and delivery apps»."
},
{
"q": "What are the two disadvantages of eating out every day?",
"o": [
"It is expensive, and the meals often have too much oil, salt and sugar.",
"It is slow, and the food often arrives at your home cold.",
"It is boring, and the portions are usually too small for students.",
"It is expensive, and most restaurants are far from the university."
],
"e": "الفقرة 1: «eating out every day is expensive, and second, many restaurant meals contain more oil, salt and sugar than our bodies need»."
},
{
"q": "What does the underlined word \"ingredients\" in paragraph 2 mean?",
"o": [
"the foods you use to make a dish",
"the tools you use in the kitchen",
"the menus you see in restaurants",
"the videos that show each step"
],
"e": "ingredients = المكوّنات اللي تسوي منها الأكل. الفقرة 2: «You choose fresh ingredients» ← تختار المكوّنات الطازجة اللي بتطبخ فيها."
},
{
"q": "Which advantage of cooking at home is NOT mentioned in paragraph 2?",
"o": [
"It is faster than ordering from a restaurant.",
"You can choose fresh ingredients.",
"You can decide how much salt or oil to use.",
"It is much cheaper."
],
"e": "الفقرة 2 ذكرت المكونات الطازجة، وكمية الملح والزيت، وإنه أرخص بكثير. أما إنه أسرع من المطعم ما انذكر."
},
{
"q": "According to the writer, a meal that costs 40 riyals from a delivery app might cost ______ at home.",
"o": [
"less than half that amount",
"more than 40 riyals",
"exactly the same amount",
"about 30 riyals"
],
"e": "الفقرة 2: «A meal that costs 40 riyals from a delivery app might cost less than half that amount if you make it yourself» ← أقل من 20 ريال."
},
{
"q": "What does the underlined word \"nervous\" in paragraph 3 mean?",
"o": [
"worried",
"hungry",
"proud",
"bored"
],
"e": "nervous = متوتر وقلقان. المبتدئ يتوتر لأنه يحسب الطبخ يحتاج موهبة خاصة."
},
{
"q": "The writer says that cooking is a skill that ______.",
"o": [
"anyone can learn with practice",
"needs special talent",
"only mothers and grandmothers have",
"people can only learn from videos"
],
"e": "الفقرة 3: «In fact, it is a skill that anyone can learn with practice»."
},
{
"q": "What does the underlined word \"her\" in paragraph 3 refer to?",
"o": [
"your mother or grandmother",
"a traditional dish",
"a beginner",
"an online video"
],
"e": "«Asking your mother or grandmother to teach you… and to spend time with her» ← her = الأم أو الجدة."
},
{
"q": "Why do many people find cooking relaxing?",
"o": [
"It gives them a break from screens and studying.",
"It helps them sleep earlier.",
"It makes them feel hungry.",
"It helps them finish their studies faster."
],
"e": "الفقرة 4: «Many people find it relaxing, because it gives them a break from screens and studying»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Learning to Cook",
"Why Restaurant Food Is Healthier",
"The History of Kabsa",
"How Delivery Apps Work"
],
"e": "القطعة كلها تشجّع على تعلّم الطبخ: الفقرة 1 «Learning to cook is a practical solution to both problems»، وبعدها فوايده وكيف تبدأ ← Learning to Cook."
}
]
},
{
"n": 13,
"k": 13,
"title": "Working Part-Time While Studying",
"text": [
"1. More and more university students today have part-time jobs. They work a few hours a week in cafés, shops, offices, or even at their own university while they continue their studies. Some students work because they need money for transport, books, or personal needs, while others simply want to gain experience before they graduate. Although this was less common in the past, it is now a normal part of student life for many young people.",
"2. A part-time job can bring several benefits. First, it gives students their own money, so they do not always have to depend on their families. Second, students learn skills that are hard to learn in a classroom, such as communicating with customers, working in a team, and managing their time. Many employers say that these skills are just as important as good grades. Third, work experience looks good on a CV, and it can _increase_ a student's chances of finding a good job after university.",
"3. However, working while studying is not always easy. Students who work too many hours often feel tired in lectures, and they may not have enough time to prepare for tests. As a result, their grades can fall. For this reason, many advisors suggest working no more than fifteen to twenty hours a week. Another useful idea is to look for a job with _flexible_ hours, which allows students to work less during exam periods and more during the holidays.",
"4. Before applying for a job, students should think carefully about their timetable and their goals. If possible, they should choose work that is connected to their major. For example, a student who studies computer science could work in a computer shop, while a nursing student might find a job in a pharmacy. In this way, the job does not only pay the bills; it also helps _them_ prepare for their future career. With good planning, a part-time job can be a valuable part of university life."
],
"qs": [
{
"q": "According to paragraph 1, why do some students work?",
"o": [
"They need money for transport, books, or personal needs.",
"Their university asks all students to find a job.",
"They want to stop studying and start working.",
"They have already graduated from university."
],
"e": "الفقرة 1: «Some students work because they need money for transport, books, or personal needs» ← يحتاجون فلوس للمواصلات والكتب واحتياجاتهم."
},
{
"q": "Which skill does the writer NOT mention?",
"o": [
"speaking a foreign language",
"communicating with customers",
"working in a team",
"managing their time"
],
"e": "الفقرة 2 ذكرت: «communicating with customers, working in a team, and managing their time». أما اللغة الأجنبية ما انذكرت."
},
{
"q": "According to many employers, the skills that students learn at work are ______.",
"o": [
"just as important as good grades",
"less important than good grades",
"easy to learn in a classroom",
"only useful in cafés and shops"
],
"e": "الفقرة 2: «Many employers say that these skills are just as important as good grades» ← مهمة بنفس أهمية الدرجات."
},
{
"q": "What does the underlined word \"increase\" in paragraph 2 mean?",
"o": [
"make bigger",
"make smaller",
"show",
"stop"
],
"e": "«it can increase a student's chances» = يزيد فرص الطالب ← make bigger (يكبّر/يزيد)."
},
{
"q": "What can happen to students who work too many hours?",
"o": [
"Their grades can fall.",
"They get more time to prepare for tests.",
"They graduate earlier.",
"They feel more active in lectures."
],
"e": "الفقرة 3: «Students who work too many hours often feel tired… As a result, their grades can fall» ← درجاتهم تنزل."
},
{
"q": "How many hours a week do many advisors suggest students work, at most?",
"o": [
"fifteen to twenty",
"ten to fifteen",
"twenty to thirty",
"forty"
],
"e": "الفقرة 3: «many advisors suggest working no more than fifteen to twenty hours a week» ← بالكثير 15 إلى 20 ساعة."
},
{
"q": "What does the underlined word \"flexible\" in paragraph 3 mean?",
"o": [
"able to change easily",
"very long and tiring",
"fixed and not changing",
"well paid every month"
],
"e": "flexible = مرن، يتغيّر بسهولة. والدليل نفس الجملة: «which allows students to work less during exam periods and more during the holidays»."
},
{
"q": "The writer gives the example of a nursing student to show that ______.",
"o": [
"students can choose work that is connected to their major",
"nursing students need more money than other students",
"pharmacies pay more than computer shops",
"all students should work in a computer shop"
],
"e": "الفقرة 4: «they should choose work that is connected to their major. For example… a nursing student might find a job in a pharmacy» ← المثال يوضّح إن الطالب يختار شغل له علاقة بتخصصه."
},
{
"q": "What does the underlined word \"them\" in paragraph 4 refer to?",
"o": [
"the students",
"the bills",
"the jobs",
"the computer shops"
],
"e": "الفقرة 4 تتكلم عن الطلاب: «the job does not only pay the bills; it also helps them prepare for their future career» ← الشغل يساعدهم (الطلاب) يستعدون لمستقبلهم."
},
{
"q": "What is the best title for the passage?",
"o": [
"Part-time jobs: benefits, problems, and advice",
"Why students should never work",
"The best jobs for computer students",
"How to write a good CV"
],
"e": "الفقرة 2 فيها الفوائد، والفقرة 3 فيها الصعوبات، والفقرة 4 فيها نصائح ← العنوان الأنسب: فوائد ومشاكل ونصائح."
}
]
},
{
"n": 14,
"k": 14,
"title": "Don't Skip Breakfast",
"text": [
"1. Many people say that breakfast is the most important meal of the day, but a large number of students and workers leave home without eating anything. Some of them wake up late and do not have time, while others simply do not feel hungry in the morning. A few people even believe that skipping breakfast is a good way to lose weight. So, is it really a problem to start the day with an empty stomach?",
"2. After seven or eight hours of sleep, the body has used a lot of its energy, and the brain needs fuel to work well. Breakfast gives you this energy. Several studies have suggested that students who eat breakfast regularly _concentrate_ better in class, remember information more easily, and feel less tired during morning lectures. Teachers also notice that hungry students are more likely to lose interest in the lesson.",
"3. Skipping breakfast can also affect what you eat later. People who miss the morning meal often feel very hungry by midday, so _they_ may eat large meals at lunch or buy fast food and snacks between meals. Because of this, skipping breakfast does not always help people lose weight. In fact, it can sometimes have the _opposite_ effect. A balanced breakfast helps you control your hunger until lunchtime.",
"4. Fortunately, a healthy breakfast does not have to take a long time. In Saudi Arabia, many families enjoy traditional choices such as eggs, beans, cheese, and bread, which give the body protein and keep you full for longer. Yogurt with fruit or a bowl of oats with milk are also quick options. If you are in a hurry, you can take a banana and a handful of nuts with you. The important thing is to give your body something good before the day begins."
],
"qs": [
{
"q": "According to paragraph 1, why do some people skip breakfast?",
"o": [
"They wake up late and do not have time.",
"Breakfast is too expensive for them to buy.",
"Their doctors tell them not to eat in the morning.",
"They always eat a big dinner the night before."
],
"e": "الفقرة 1: «Some of them wake up late and do not have time» ← يصحون متأخر وما عندهم وقت."
},
{
"q": "According to paragraph 1, a few people believe that skipping breakfast ______.",
"o": [
"is a good way to lose weight",
"makes them more active",
"improves their grades",
"saves them a lot of money"
],
"e": "الفقرة 1: «A few people even believe that skipping breakfast is a good way to lose weight»."
},
{
"q": "What does the underlined word \"concentrate\" in paragraph 2 mean?",
"o": [
"focus",
"sleep",
"eat",
"relax"
],
"e": "concentrate = يركّز. الطالب اللي يفطر يركّز أحسن في الحصة ← focus."
},
{
"q": "Which result of eating breakfast does the writer NOT mention?",
"o": [
"sleeping better at night",
"concentrating better in class",
"remembering information more easily",
"feeling less tired during lectures"
],
"e": "الفقرة 2 ذكرت: «concentrate better in class, remember information more easily, and feel less tired during morning lectures». النوم الأحسن بالليل ما انذكر."
},
{
"q": "What do teachers notice about hungry students?",
"o": [
"They are more likely to lose interest in the lesson.",
"They are more likely to ask questions in the lesson.",
"They usually finish their class work faster than others.",
"They usually bring breakfast to eat during the lesson."
],
"e": "الفقرة 2: «Teachers also notice that hungry students are more likely to lose interest in the lesson»."
},
{
"q": "What does the underlined word \"they\" in paragraph 3 refer to?",
"o": [
"people who miss the morning meal",
"teachers who notice hungry students",
"snacks between meals",
"large meals at lunch"
],
"e": "الفقرة 3: «People who miss the morning meal often feel very hungry by midday, so they may eat large meals» ← they = الناس اللي ما يفطرون."
},
{
"q": "Why does skipping breakfast not always help people lose weight?",
"o": [
"They may eat more later in the day.",
"They sleep for seven or eight hours.",
"Breakfast has no effect on hunger.",
"They walk less in the morning."
],
"e": "الفقرة 3: يجوعون الظهر و«may eat large meals at lunch or buy fast food and snacks between meals. Because of this, skipping breakfast does not always help people lose weight» ← ياكلون أكثر بعدين."
},
{
"q": "What does the underlined word \"opposite\" in paragraph 3 mean?",
"o": [
"completely different",
"very small",
"the same",
"healthy"
],
"e": "opposite = عكس، مختلف تماماً. يعني بدل ما ينقص وزنه ممكن يزيد."
},
{
"q": "The writer mentions eggs, beans, cheese, and bread to show that ______.",
"o": [
"traditional breakfasts can keep you full for longer",
"traditional breakfasts take a long time to prepare",
"people should only eat bread in the morning",
"fruit is better than eggs"
],
"e": "الفقرة 4: «traditional choices such as eggs, beans, cheese, and bread, which give the body protein and keep you full for longer» ← الفطور التقليدي يشبّعك لوقت أطول."
},
{
"q": "What is the best title for the passage?",
"o": [
"Don't Skip Breakfast",
"Breakfast: The Least Important Meal of the Day",
"Breakfast: Only Important for Young Children",
"Why a Healthy Breakfast Takes a Long Time"
],
"e": "الفقرة 2 تقول إن الفطور يعطي طاقة، والفقرة 4: «a healthy breakfast does not have to take a long time» ← الفطور مهم والصحي منه سريع وسهل ← فأفضل عنوان: Don't Skip Breakfast"
}
]
},
{
"n": 15,
"k": 15,
"title": "AlUla: A Window to the Past",
"text": [
"1. AlUla is a region in the northwest of Saudi Arabia, in the Madinah area. It is famous for its beautiful sandstone mountains, its green oasis full of palm trees, and its long history. People have lived in this valley for thousands of years, because it had water and was on an important trade road. Today, AlUla is one of the most popular places for visitors in the Kingdom, and many tourists from inside and outside Saudi Arabia travel there every year.",
"2. The most famous site in AlUla is Hegra, which is also known as Mada'in Salih. Hegra was built by the Nabataeans, the same people who built the city of Petra in Jordan. More than 100 tombs were cut into the rocks, and many of _them_ have beautiful decorations above their doors. In 2008, Hegra became the first place in Saudi Arabia to be added to UNESCO's World Heritage List. Not far from the town of AlUla, visitors can also see Jabal Ikmah, a mountain covered with ancient writings, which some people call an \"open library\".",
"3. Apart from its history, AlUla has amazing natural _landscapes_. One of the most famous is Elephant Rock, a huge rock that looks like an elephant. Visitors can go hiking in the mountains, ride horses through the desert, or watch the stars at night. Because there are few city lights in the area, the night sky is unusually clear, and stargazing tours have become very popular.",
"4. In recent years, AlUla has also become a centre for culture and events. During the winter season, it hosts music concerts, art _exhibitions_, and festivals, and its unusual concert hall, Maraya, is covered with mirrors. At the same time, the government is working hard to protect the old sites while it develops tourism. For example, visitors must book a tour to enter Hegra, so the number of people at the site at one time is limited. If you ever travel around the Kingdom, AlUla is a place you should not miss."
],
"qs": [
{
"q": "Why have people lived in the AlUla valley for thousands of years?",
"o": [
"It had water and was on an important trade road.",
"It had tall buildings and a large concert hall.",
"It had a large university and many famous libraries.",
"It was far from the desert and had cool weather."
],
"e": "الفقرة 1: «People have lived in this valley for thousands of years, because it had water and was on an important trade road»."
},
{
"q": "Which of these does the writer NOT mention as something AlUla is famous for?",
"o": [
"its beaches",
"its sandstone mountains",
"its green oasis",
"its long history"
],
"e": "الفقرة 1: «It is famous for its beautiful sandstone mountains, its green oasis full of palm trees, and its long history». الشواطئ ما انذكرت."
},
{
"q": "The writer says that the Nabataeans also built ______.",
"o": [
"the city of Petra",
"Jabal Ikmah",
"Elephant Rock",
"the Maraya concert hall"
],
"e": "الفقرة 2: «the Nabataeans, the same people who built the city of Petra in Jordan»."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"the tombs",
"the Nabataeans",
"the doors",
"the people of Petra"
],
"e": "الفقرة 2: «More than 100 tombs were cut into the rocks, and many of them have beautiful decorations above their doors» ← them = المقابر (tombs)."
},
{
"q": "What happened in 2008?",
"o": [
"Hegra was added to UNESCO's World Heritage List.",
"Hegra was first built by the Nabataeans in the valley.",
"Maraya hosted its first winter music concert.",
"Elephant Rock was discovered by visitors on a hike."
],
"e": "الفقرة 2: «In 2008, Hegra became the first place in Saudi Arabia to be added to UNESCO's World Heritage List»."
},
{
"q": "Why do some people call Jabal Ikmah an \"open library\"?",
"o": [
"It is covered with ancient writings.",
"It has a modern library inside it.",
"Students go there to study.",
"Visitors can buy books there."
],
"e": "الفقرة 2: «Jabal Ikmah, a mountain covered with ancient writings» ← جبل مليان كتابات قديمة، عشان كذا يسمّونه \"مكتبة مفتوحة\"."
},
{
"q": "What does the underlined word \"landscapes\" in paragraph 3 mean?",
"o": [
"natural views, such as mountains and rocks",
"tall buildings in modern cities",
"old tombs cut into the rocks",
"concerts and art festivals"
],
"e": "landscapes = المناظر الطبيعية. والفقرة تعطي أمثلة: «Elephant Rock» والجبال والصحراء."
},
{
"q": "What does the underlined word \"exhibitions\" in paragraph 4 mean?",
"o": [
"public shows of art or other things",
"hotels where visitors can stay",
"trips to the mountains",
"old roads used for trade"
],
"e": "exhibitions = معارض. «art exhibitions» = معارض فنية يعرضون فيها أعمال فنية للناس."
},
{
"q": "The writer gives the example of booking a tour to enter Hegra to show that ______.",
"o": [
"the government is working to protect the old sites",
"Hegra is too expensive for most visitors",
"tourists do not like visiting Hegra",
"Hegra is open only in the winter"
],
"e": "الفقرة 4: «the government is working hard to protect the old sites… For example, visitors must book a tour to enter Hegra» ← المثال يوضّح إن الحكومة تحمي المواقع القديمة."
},
{
"q": "What is the best title for the passage?",
"o": [
"AlUla: History, Nature and Culture",
"AlUla: Famous Only for Its Old Tombs",
"AlUla: A New City of Modern Buildings",
"Why Tourists Should Visit AlUla Only at Night"
],
"e": "الفقرة 2 عن التاريخ (Hegra)، والفقرة 3 عن الطبيعة، والفقرة 4 عن الثقافة والفعاليات ← العلا مميزة بتاريخها وطبيعتها وثقافتها ← فأفضل عنوان: AlUla: History, Nature and Culture"
}
]
},
{
"n": 16,
"k": 16,
"title": "Pets and Our Health",
"text": [
"1. Many families around the world keep pets at home, such as cats, birds, rabbits, or fish. Most people get a pet simply because they love animals and enjoy their company. However, scientists have become more and more interested in another question: can pets actually be good for our health? Recent research suggests that the answer is often yes, although pets are not a cure for every problem.",
"2. First, pets can help reduce stress. When people stroke a cat or play with a friendly animal, their bodies produce chemicals that make them feel calm and happy. Some studies have also found that watching fish swim in a tank can lower a person's heart rate. In addition, pets can help people feel less lonely, especially older people who live alone. A pet gives _them_ a reason to get up every morning and something to care for.",
"3. Pets can also improve physical health. Pet owners, for example, often spend twenty or thirty minutes a day feeding, cleaning and playing with their animals, so they are more active than many people without pets. Children who grow up with pets may also learn to be kind and _gentle_, because they have to treat a small animal carefully. Some hospitals and care homes even invite trained animals to visit patients, because these visits can make patients more cheerful.",
"4. However, having a pet is a big _responsibility_. Pets need food, fresh water, a clean place to live, and regular visits to the vet. They also need attention every day, even when their owners are busy or tired. Before getting a pet, families should think carefully about whether they have enough time, space, and money. A pet is not a toy that you can forget about; it is a living creature that depends on you."
],
"qs": [
{
"q": "According to paragraph 1, why do most people get a pet?",
"o": [
"They love animals and enjoy their company.",
"Their doctors tell them it is good for their health.",
"Pets are cheap to buy and easy to look after.",
"Scientists ask them to take part in their research."
],
"e": "الفقرة 1: «Most people get a pet simply because they love animals and enjoy their company»."
},
{
"q": "The writer says that pets are ______.",
"o": [
"not a cure for every problem",
"a cure for every problem",
"bad for our health",
"only good for children"
],
"e": "الفقرة 1 آخر جملة: «although pets are not a cure for every problem» ← مو علاج لكل مشكلة."
},
{
"q": "According to some studies, watching fish swim in a tank can ______.",
"o": [
"lower a person's heart rate",
"make people feel lonely",
"increase stress",
"improve children's grades"
],
"e": "الفقرة 2: «watching fish swim in a tank can lower a person's heart rate»."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"older people who live alone",
"pets such as cats and birds",
"chemicals that make people calm",
"fish that swim in a tank"
],
"e": "الفقرة 2: «especially older people who live alone. A pet gives them a reason to get up» ← them = كبار السن اللي ساكنين لحالهم."
},
{
"q": "How much time do pet owners often spend each day looking after their animals?",
"o": [
"twenty or thirty minutes",
"two or three hours",
"five minutes",
"the whole day"
],
"e": "الفقرة 3: «Pet owners, for example, often spend twenty or thirty minutes a day feeding, cleaning and playing with their animals»."
},
{
"q": "What does the underlined word \"gentle\" in paragraph 3 mean?",
"o": [
"careful and not rough",
"loud and active",
"lazy",
"afraid"
],
"e": "gentle = لطيف وما يكون عنيف. والدليل نفس الجملة: «because they have to treat a small animal carefully»."
},
{
"q": "Why do some hospitals and care homes invite trained animals?",
"o": [
"The visits can make patients more cheerful.",
"The animals help doctors give medicine.",
"The patients need more exercise.",
"The animals need a place to live."
],
"e": "الفقرة 3: «Some hospitals and care homes even invite trained animals to visit patients, because these visits can make patients more cheerful»."
},
{
"q": "What does the underlined word \"responsibility\" in paragraph 4 mean?",
"o": [
"a duty to take care of something",
"a kind of game for children",
"a gift for a family member",
"a short holiday with animals"
],
"e": "responsibility = مسؤولية. والجملة بعدها تذكر وش يحتاج الحيوان: أكل وماي ومكان نظيف وطبيب بيطري."
},
{
"q": "Which need of pets does the writer NOT mention?",
"o": [
"toys",
"fresh water",
"visits to the vet",
"daily attention"
],
"e": "الفقرة 4 ذكرت: «food, fresh water, a clean place to live, and regular visits to the vet» و«attention every day». الألعاب ما انذكرت (الكاتب قال إن الحيوان «not a toy» بس)."
},
{
"q": "What is the best title for the passage?",
"o": [
"Pets and Health: Benefits and Responsibilities",
"Pets: The Cure for Every Illness",
"Why Only Older People Should Keep Pets",
"Why Families Should Not Keep Pets"
],
"e": "الفقرة 2 و3 عن فوائد الحيوانات الأليفة للصحة، والفقرة 4: «having a pet is a big responsibility» ← مفيدة بس تحتاج اهتمام ← فأفضل عنوان: Pets and Health: Benefits and Responsibilities"
}
]
},
{
"n": 17,
"k": 17,
"title": "Robots in Our Daily Lives",
"text": [
"1. When people hear the word \"robot\", they often think of the metal machines in science fiction films. In reality, robots are already part of everyday life, even if we do not always notice them. Some clean our homes, some help doctors in hospitals, and others build cars in large factories. As technology improves and becomes cheaper, robots are expected to become even more common in the next few years.",
"2. In factories, robots usually do jobs that are dangerous, heavy, or boring for people. Unlike human workers, they can work twenty-four hours a day without getting tired, and they rarely make mistakes. This allows companies to produce more goods in less time. Robots are also used in places that are too dangerous for humans, such as deep under the sea, where _they_ can collect information safely.",
"3. Robots are becoming common at home, too. Robot vacuum cleaners move around the house by themselves and clean the floor while the family is out. Some restaurants and hotels use robots to _deliver_ food and towels to guests, and in some hospitals, robots carry medicine from one floor to another. These machines do not replace people completely, but they save time and allow staff to focus on more important tasks.",
"4. However, not everyone is happy about this change. Many workers are worried that robots will take their jobs, and their fear is understandable. Experts agree that robots will replace some jobs, especially simple and repetitive ones. At the same time, robots will create new jobs for people who design, program, and repair them. For this reason, many experts _encourage_ young people to learn technology skills now, so that they will be ready for the jobs of the future."
],
"qs": [
{
"q": "When people hear the word \"robot\", they often think of ______.",
"o": [
"the machines in science fiction films",
"the robot vacuum cleaners in their homes",
"the doctors who work in large hospitals",
"the cars that are built in large factories"
],
"e": "الفقرة 1: «they often think of the metal machines in science fiction films»."
},
{
"q": "Why are robots expected to become more common?",
"o": [
"Technology is improving and becoming cheaper.",
"People prefer machines to human workers.",
"Many factories are closing down every year.",
"More people are watching science fiction films."
],
"e": "الفقرة 1: «As technology improves and becomes cheaper, robots are expected to become even more common»."
},
{
"q": "Which kind of factory job does the writer NOT say robots do?",
"o": [
"creative jobs",
"dangerous jobs",
"heavy jobs",
"boring jobs"
],
"e": "الفقرة 2: «robots usually do jobs that are dangerous, heavy, or boring for people». الشغل الإبداعي ما انذكر."
},
{
"q": "What does the underlined word \"they\" in paragraph 2 refer to?",
"o": [
"robots",
"humans",
"companies",
"goods"
],
"e": "الفقرة 2: «Robots are also used in places that are too dangerous for humans… where they can collect information safely» ← they = الروبوتات."
},
{
"q": "What does the underlined word \"deliver\" in paragraph 3 mean?",
"o": [
"take something to a person",
"cook something for a person",
"clean something for a person",
"sell something to a person"
],
"e": "«deliver food and towels to guests» = يوصّلون الأكل والمناشف للضيوف ← take something to a person."
},
{
"q": "The writer gives the example of robot vacuum cleaners to show that ______.",
"o": [
"robots are becoming common at home",
"robots are dangerous for families",
"factories need more workers",
"families do not like cleaning"
],
"e": "الفقرة 3 تبدأ بـ«Robots are becoming common at home, too» وبعدها مثال المكنسة الروبوت."
},
{
"q": "According to paragraph 3, robots allow staff to ______.",
"o": [
"focus on more important tasks",
"go home early every day",
"stop working completely",
"earn more money"
],
"e": "الفقرة 3: «they save time and allow staff to focus on more important tasks»."
},
{
"q": "Which jobs will robots most likely replace, according to experts?",
"o": [
"simple and repetitive jobs",
"jobs designing robots",
"jobs programming robots",
"jobs repairing robots"
],
"e": "الفقرة 4: «robots will replace some jobs, especially simple and repetitive ones». أما التصميم والبرمجة والتصليح فهي وظائف جديدة بتطلع."
},
{
"q": "What does the underlined word \"encourage\" in paragraph 4 mean?",
"o": [
"advise and support someone to do something",
"prevent someone from doing something",
"pay someone to do something",
"forget to do something"
],
"e": "encourage = يشجّع. الخبراء يشجّعون الشباب يتعلّمون مهارات التقنية."
},
{
"q": "What is the best title for the passage?",
"o": [
"Robots Today and the Skills We Need Tomorrow",
"Robots Will Take All Our Jobs, So Why Learn?",
"Robots: Only Used in Factories",
"Why People Should Stop Using Robots at Home"
],
"e": "الفقرة 1: «robots are already part of everyday life»، والفقرة 4 تنصح بتعلّم مهارات التقنية للمستقبل ← فأفضل عنوان: Robots Today and the Skills We Need Tomorrow"
}
]
},
{
"n": 18,
"k": 18,
"title": "Saving Water",
"text": [
"1. Water is one of the most important resources on Earth. We need it for drinking, cooking, cleaning, and growing food, and factories use huge amounts of it as well. However, clean fresh water is limited, and the world's population is still growing. In dry regions such as the Arabian Peninsula, where rain is rare and summers are long and hot, saving water is not just a good idea; it is a necessity.",
"2. Saudi Arabia is one of the driest countries in the world. It has no permanent rivers or lakes, so a large part of its drinking water comes from the sea. Seawater is cleaned in special factories called desalination plants, which remove the salt. In fact, the Kingdom is one of the largest producers of desalinated water in the world. However, this process is expensive and uses a lot of energy, so every litre that is wasted has a real cost.",
"3. Fortunately, everyone can help save water at home. For example, you can turn off the tap while you brush your teeth, which can save several litres every minute. Taking a short shower instead of filling a bath also makes a big difference. If a tap is leaking, you should repair it quickly, because even a small leak can waste thousands of litres in a year. Many families also put simple devices on _their_ taps that _reduce_ the amount of water that comes out.",
"4. Water can also be saved outside the house. Plants should be watered early in the morning or in the evening, when it is cooler, so that less water is lost in the heat. Choosing local plants that need little water is another good idea, and washing the car with a bucket uses far less water than using a hose. If everyone makes small changes like these, we can protect this _precious_ resource for future generations."
],
"qs": [
{
"q": "According to paragraph 1, why is saving water a necessity in the Arabian Peninsula?",
"o": [
"Rain is rare and summers are long and hot.",
"The population is getting smaller.",
"Factories do not use any water.",
"There are too many rivers."
],
"e": "الفقرة 1: «where rain is rare and summers are long and hot, saving water is not just a good idea; it is a necessity»."
},
{
"q": "Where does a large part of Saudi Arabia's drinking water come from?",
"o": [
"the sea",
"rivers",
"lakes",
"rain"
],
"e": "الفقرة 2: «It has no permanent rivers or lakes, so a large part of its drinking water comes from the sea»."
},
{
"q": "What do desalination plants do?",
"o": [
"They remove the salt from seawater.",
"They collect rainwater.",
"They clean the water in rivers.",
"They produce electricity for homes."
],
"e": "الفقرة 2: «Seawater is cleaned in special factories called desalination plants, which remove the salt»."
},
{
"q": "Why does every litre of wasted water have a real cost?",
"o": [
"Desalination is expensive and uses a lot of energy.",
"Drinking water is only sold in shops and restaurants.",
"Leaking taps are expensive and hard to repair.",
"Plants need more water during the long, hot summers."
],
"e": "الفقرة 2: «this process is expensive and uses a lot of energy, so every litre that is wasted has a real cost»."
},
{
"q": "Which way of saving water at home does the writer NOT mention?",
"o": [
"using the washing machine less often",
"turning off the tap while brushing your teeth",
"taking a short shower",
"repairing a leaking tap"
],
"e": "الفقرة 3 ذكرت: قفل الحنفية وقت تفريش الأسنان، والشاور القصير، وتصليح الحنفية اللي تسرّب. الغسالة ما انذكرت."
},
{
"q": "What does the underlined word \"their\" in paragraph 3 refer to?",
"o": [
"families",
"taps",
"devices",
"litres"
],
"e": "الفقرة 3: «Many families also put simple devices on their taps» ← their = العوائل (families)."
},
{
"q": "What does the underlined word \"reduce\" in paragraph 3 mean?",
"o": [
"make smaller",
"make bigger",
"clean",
"heat"
],
"e": "reduce = يقلّل. الأجهزة تقلّل كمية الماي اللي تطلع من الحنفية."
},
{
"q": "The writer gives the example of washing the car with a bucket to show that ______.",
"o": [
"there are simple ways to save water outside the house",
"hoses are better than buckets for washing a car",
"people should not wash their cars at all in summer",
"it is better to wash cars at a car wash than at home"
],
"e": "الفقرة 4 تبدأ بـ«Water can also be saved outside the house» ومثال السطل: «washing the car with a bucket uses far less water than using a hose»."
},
{
"q": "What does the underlined word \"precious\" in paragraph 4 mean?",
"o": [
"very valuable",
"very cheap",
"very dirty",
"very new"
],
"e": "precious = ثمين وغالي، يعني مورد مهم لازم نحافظ عليه."
},
{
"q": "What is the best title for the passage?",
"o": [
"Small Changes to Save Precious Water",
"Saudi Arabia's Many Rivers and Lakes",
"Why Saving Water Is Not Necessary",
"Stop Watering Your Plants in Summer"
],
"e": "القطعة تشرح أهمية الماي وندرته (الفقرة 1 و2)، وطرق بسيطة لتوفيره (الفقرة 3 و4): «If everyone makes small changes like these, we can protect this precious resource» ← فأفضل عنوان: Small Changes to Save Precious Water"
}
]
},
{
"n": 19,
"k": 19,
"title": "Libraries Are Changing",
"text": [
"1. In the past, libraries were quiet buildings full of shelves of books, where people went to borrow novels or study in silence. Today, some people believe that libraries are no longer needed, because almost any information can be found online in seconds. However, libraries have not disappeared. Instead, many of them are changing in order to meet the needs of modern visitors.",
"2. Modern libraries offer much more than books. Most of them provide computers, free Wi-Fi, and comfortable areas where students can work together on group projects. Some libraries also have \"maker spaces\", where visitors can use 3D printers and other tools to build their own designs. Others run free courses in languages, computer skills, and writing, which are especially useful for people who want to improve their CV.",
"3. Libraries have also become important community centres. They organise activities for children, such as story time and reading competitions, which help children develop a love of reading. They also hold talks with writers and workshops for adults. For families who cannot _afford_ computers or many books, the library gives _them_ free access to knowledge. This is why some cities are building new libraries instead of closing old ones.",
"4. Of course, books are still at the heart of every library, but the way people read is changing. Many libraries now lend e-books and audiobooks, so members can read or listen on their phones wherever they are. Librarians have also taken on a new role: they teach visitors how to find _reliable_ information and how to recognise false stories online. In a world full of information, this skill may be one of the most valuable services that libraries offer."
],
"qs": [
{
"q": "Why do some people believe that libraries are no longer needed?",
"o": [
"Almost any information can be found online in seconds.",
"Libraries are too noisy for people who want to study.",
"Books have become too expensive for most people to buy.",
"Libraries close too early for students and workers."
],
"e": "الفقرة 1: «some people believe that libraries are no longer needed, because almost any information can be found online in seconds»."
},
{
"q": "According to paragraph 1, many libraries are changing in order to ______.",
"o": [
"meet the needs of modern visitors",
"save money on new books and shelves",
"sell more books to their visitors",
"become quieter places for study"
],
"e": "الفقرة 1: «many of them are changing in order to meet the needs of modern visitors»."
},
{
"q": "What can visitors do in \"maker spaces\"?",
"o": [
"use 3D printers and other tools",
"borrow novels",
"study in silence",
"listen to audiobooks"
],
"e": "الفقرة 2: «\"maker spaces\", where visitors can use 3D printers and other tools to build their own designs»."
},
{
"q": "Which free course does the writer NOT mention?",
"o": [
"cooking",
"languages",
"computer skills",
"writing"
],
"e": "الفقرة 2: «free courses in languages, computer skills, and writing». الطبخ ما انذكر."
},
{
"q": "According to the writer, free courses are especially useful for people who want to ______.",
"o": [
"improve their CV",
"write novels",
"build 3D printers",
"become librarians"
],
"e": "الفقرة 2: «which are especially useful for people who want to improve their CV»."
},
{
"q": "What does the underlined word \"afford\" in paragraph 3 mean?",
"o": [
"have enough money to pay for",
"borrow from another person",
"carry from one place to another",
"understand how to use"
],
"e": "afford = يقدر يدفع حقه (عنده فلوس كفاية). العوائل اللي ما تقدر تشتري كمبيوتر أو كتب."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"families who cannot afford computers",
"computers and many books",
"writers who give talks",
"cities that build new libraries"
],
"e": "الفقرة 3: «For families who cannot afford computers or many books, the library gives them free access to knowledge» ← them = العوائل."
},
{
"q": "According to paragraph 4, what do many libraries now lend besides paper books?",
"o": [
"e-books and audiobooks",
"phones and tablets",
"laptops and cameras",
"newspapers and magazines"
],
"e": "الفقرة 4: «Many libraries now lend e-books and audiobooks»."
},
{
"q": "What does the underlined word \"reliable\" in paragraph 4 mean?",
"o": [
"that you can trust",
"that is false",
"that is very old",
"that costs a lot"
],
"e": "reliable = موثوق. وهي عكس «false stories» اللي في نفس الجملة."
},
{
"q": "What is the best title for the passage?",
"o": [
"How libraries are changing",
"Why libraries are closing",
"The history of books",
"How to find information online"
],
"e": "الفقرة 1: «libraries have not disappeared. Instead, many of them are changing»، وباقي القطعة يشرح هذا التغيير."
}
]
},
{
"n": 20,
"k": 20,
"title": "Photography as a Hobby",
"text": [
"1. Photography has become one of the most popular hobbies in the world. In the past, people needed expensive cameras and special skills to take good photos, and they often had to wait several days to see the results. Today, almost everyone carries a smartphone with a high-quality camera, so anyone can become a photographer. Every day, millions of photos are taken and shared, from family events to beautiful views of nature.",
"2. Photography can change the way people see the world. When you take photos regularly, you begin to notice small details that you never saw before, such as the light on an old building or the colours of the sky at sunset. Many photographers also say that their hobby has made them more _patient_, because they sometimes have to wait a long time for the perfect moment, for example for a bird to land on a tree.",
"3. If you want to improve your photos, a few simple tips can help. First, pay attention to the light. Outside, the best time is usually early in the morning or just before sunset, when the light is soft and warm. Second, try not to put your subject in the centre of every photo, because moving it a little to one side often makes the picture more interesting. Finally, clean your lens _gently_ before you start, since a dirty lens can make photos look unclear.",
"4. Photography can also bring people together. Many photographers share their work online or join local photography clubs, where members go on trips and give each other advice. Some even enter competitions and win prizes for their best pictures. However, experts remind photographers to ask permission before taking photos of people, because not everyone wants _their_ picture to be taken or shared. Whether you prefer nature, buildings, or food, photography is a creative way to express yourself and keep special memories."
],
"qs": [
{
"q": "Why can anyone become a photographer today?",
"o": [
"Almost everyone carries a smartphone with a high-quality camera.",
"Expensive cameras have become free for everyone to use.",
"Photography clubs now give free cameras to all members.",
"People no longer need good light to take beautiful photos."
],
"e": "الفقرة 1: «almost everyone carries a smartphone with a high-quality camera, so anyone can become a photographer»."
},
{
"q": "The writer says that when you take photos regularly, you begin to notice ______.",
"o": [
"small details",
"loud noises",
"other people's mistakes",
"expensive cameras"
],
"e": "الفقرة 2: «you begin to notice small details that you never saw before»."
},
{
"q": "What does the underlined word \"patient\" in paragraph 2 mean?",
"o": [
"able to wait calmly",
"quick to get angry",
"able to work fast",
"easily tired"
],
"e": "patient = صبور، يقدر ينتظر بهدوء بدون ما يزهق. الفقرة 2: «Many photographers also say that their hobby has made them more patient»."
},
{
"q": "The writer gives the example of a bird landing on a tree to show that ______.",
"o": [
"photographers sometimes wait a long time for the perfect moment",
"birds are the best and most popular subject for photos",
"photographers usually prefer nature to buildings and food",
"it is quick and easy to take a perfect photo of a bird"
],
"e": "الفقرة 2: «they sometimes have to wait a long time for the perfect moment, for example for a bird to land on a tree»."
},
{
"q": "When is usually the best time to take photos outside?",
"o": [
"early in the morning or just before sunset",
"at noon, when the sun is high and strong",
"late at night, after the sun has gone down",
"in the middle of the afternoon, when it is hot"
],
"e": "الفقرة 3: «Outside, the best time is usually early in the morning or just before sunset, when the light is soft and warm»."
},
{
"q": "What does the underlined word \"gently\" in paragraph 3 mean?",
"o": [
"softly and carefully",
"quickly and roughly",
"strongly and hard",
"often and regularly"
],
"e": "gently = بلطف وبهدوء، يعني تنظّف العدسة بشويش بدون قوة."
},
{
"q": "Which way of bringing people together does the writer NOT mention in paragraph 4?",
"o": [
"teaching photography in schools",
"sharing their work online",
"joining local photography clubs",
"entering competitions"
],
"e": "الفقرة 4 ذكرت: المشاركة أونلاين، والنوادي، والمسابقات. التدريس في المدارس ما انذكر."
},
{
"q": "Why should photographers ask permission before taking photos of people?",
"o": [
"Not everyone wants their picture to be taken or shared.",
"Asking permission is the best way to win competition prizes.",
"People always pay photographers for the photos they take.",
"Photography clubs ask all their members to do this."
],
"e": "الفقرة 4: «ask permission before taking photos of people, because not everyone wants their picture to be taken or shared»."
},
{
"q": "What does the underlined word \"their\" in paragraph 4 refer to?",
"o": [
"the people in the photos",
"the photographers",
"the experts",
"the club members"
],
"e": "الفقرة 4: «before taking photos of people, because not everyone wants their picture to be taken» ← their = الناس اللي ينصوّرون."
},
{
"q": "What is the best title for the passage?",
"o": [
"Photography: A Hobby Anyone Can Enjoy",
"Why Photography Is Too Expensive Today",
"Good Photos Need Special Cameras",
"Why Smartphones Are Bad for Photography"
],
"e": "الفقرة 1: «anyone can become a photographer»، والقطعة تذكر فوائد التصوير (الفقرة 2 و4) ونصائح له (الفقرة 3) ← فأفضل عنوان: Photography: A Hobby Anyone Can Enjoy"
}
]
},
{
"n": 21,
"k": 21,
"title": "Talent or Teamwork?",
"text": [
"1. In almost every sport, fans and club owners tend to assume that the team with the best individual players will win. It seems logical: if you buy the fastest striker and the strongest defender, success should follow. As a result, clubs often spend enormous sums of money on a few famous names. Nevertheless, history is full of expensive teams that failed and modest teams that won, which suggests that talent alone is not the whole story.",
"2. One well-known study looked at this question in professional basketball and football. The researchers found that adding top players improved a team's results, but only up to a point. After that point, adding even more stars seemed to make performance worse. Interestingly, the same pattern did not appear in baseball, where players spend much of the game acting on their own rather than depending on one another. The researchers' explanation was that when a team has too many stars, players may compete for attention instead of cooperating, and nobody wants to do the less _glamorous_ work.",
"3. Coaches who build successful teams usually focus on roles rather than reputations. A player who rarely scores but always defends, passes, and communicates may be _considerably_ more valuable than his statistics show. Such players make the people around them better, even though fans may not notice _them_. In addition, teams that train together for years tend to develop an almost automatic understanding, so they can react to problems on the field without needing to stop and think.",
"4. This does not mean that talent is unimportant. A team of hard-working but limited players will rarely beat a team that is both skilled and united. The real question is balance. Clubs that select players only for their individual quality risk creating a group of strong individuals who do not fit together, whereas clubs that also consider character, attitude, and the needs of the team are more likely to achieve lasting success.",
"5. The lesson is relevant far beyond sport. Companies, hospitals, and research groups also tend to hire \"stars\" and expect excellent results to follow automatically. However, the evidence from sport suggests that the way people work together may matter as much as how talented each person is. A group's performance, in other words, is not simply the sum of its members' abilities."
],
"qs": [
{
"q": "What can we understand from paragraph 1?",
"o": [
"Spending a lot of money on famous players does not guarantee success.",
"Modest teams usually beat expensive teams in most sports.",
"Clubs rarely spend large sums of money on famous players.",
"Fans do not care much about the individual players in a team."
],
"e": "الفقرة 1: «history is full of expensive teams that failed and modest teams that won» ← يعني الفلوس والأسماء الكبيرة ما تضمن الفوز. (وخيار usually beat غلط لأنه ما قال إنها تفوز غالباً)."
},
{
"q": "Why did the same pattern NOT appear in baseball?",
"o": [
"Baseball players act on their own more than they depend on each other.",
"Baseball teams usually have fewer star players than other teams.",
"Baseball players train together for many more years than others.",
"Baseball teams spend less money on their players than football teams."
],
"e": "الفقرة 2: «in baseball, where players spend much of the game acting on their own rather than depending on one another»."
},
{
"q": "What does the underlined word \"glamorous\" in paragraph 2 mean?",
"o": [
"attractive and exciting",
"tiring and physical",
"safe and easy",
"quiet and simple"
],
"e": "glamorous = مبهر وجذّاب يلفت الأنظار. «the less glamorous work» = الشغل اللي ما يلفت الانتباه، فالنجوم ما يبون يسوونه."
},
{
"q": "The writer gives the example of a player who rarely scores but always defends and passes to show that ______.",
"o": [
"a player's value is not always shown by his statistics",
"defenders should try to score more goals",
"fans always notice hard-working players",
"statistics are the best way to judge a player"
],
"e": "الفقرة 3: «may be considerably more valuable than his statistics show» ← قيمة اللاعب أكبر من أرقامه."
},
{
"q": "What does the underlined word \"considerably\" in paragraph 3 mean?",
"o": [
"much",
"slightly",
"rarely",
"quickly"
],
"e": "considerably = بشكل كبير ← much (more valuable بكثير)."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"the players who rarely score",
"the people around these players",
"the fans in the stadium",
"the coaches of the team"
],
"e": "«Such players make the people around them better, even though fans may not notice them» ← them = هاللاعبين (اللي ما يسجلون بس يدافعون ويمررون)، الجمهور ما ينتبه لهم."
},
{
"q": "Which of these does the writer NOT mention as something clubs should consider when choosing players?",
"o": [
"the player's age",
"the player's character",
"the player's attitude",
"the needs of the team"
],
"e": "الفقرة 4: «consider character, attitude, and the needs of the team» ← العمر ما انذكر."
},
{
"q": "Which statement would the writer most likely agree with?",
"o": [
"Talent matters, but it must be balanced with teamwork.",
"Talent is not important in team sports.",
"Clubs should only buy the most famous players.",
"Hard-working limited players usually beat skilled teams."
],
"e": "الفقرة 4: «This does not mean that talent is unimportant… The real question is balance» ← الموهبة مهمة بس لازم توازن مع روح الفريق."
},
{
"q": "What is the writer's main purpose in paragraph 5?",
"o": [
"to show that the lesson from sport also applies to other workplaces",
"to criticize the way hospitals and companies treat their best workers",
"to explain how companies and research groups choose their managers",
"to prove that companies and hospitals should never hire star workers"
],
"e": "الفقرة 5: «The lesson is relevant far beyond sport» وبعدها ذكر الشركات والمستشفيات ومجموعات البحث ← الدرس ينطبق برا الرياضة بعد."
},
{
"q": "What is the best title for the passage?",
"o": [
"Why the Best Players Don't Always Make the Best Team",
"How to Become a Star Player in Any Team Sport",
"The History of the World's Most Expensive Football Clubs",
"Why Baseball Is Different From Basketball and Football"
],
"e": "القطعة كلها تشرح إن جمع أفضل اللاعبين ما يكفي، وإن التعاون والتوازن مهمين مثل الموهبة."
}
]
},
{
"n": 22,
"k": 22,
"title": "Choosing a Major: Passion or Practicality?",
"text": [
"1. When students choose a university major, they often receive two very different pieces of advice. The first is \"follow your passion\": study what you love, and success will come. The second is more practical: choose a subject that leads to a well-paid, secure job. Both approaches seem reasonable, yet _they_ can push a student in opposite directions, and many young people feel caught between their own interests and the expectations of their families.",
"2. Supporters of the passion approach argue that motivation is the key to success. A student who is genuinely curious about history or design is likely to attend classes, read beyond the required texts, and keep going when the work becomes difficult. In contrast, a student who chose a subject only for its salary may lose interest and find it hard to _persist_ during difficult courses. From this point of view, a strong interest is not a luxury but an important practical advantage.",
"3. Critics, however, point out that passion can be unreliable. Many eighteen-year-olds have not yet experienced enough subjects to know what they truly love, and interests often change over time. Furthermore, some fields attract far more graduates than there are jobs, so a student who follows a passion without researching the job market may face serious consequences later. Some career researchers even suggest that passion often develops after people become skilled at something, rather than existing before they start.",
"4. A more balanced approach may be to treat the decision as a combination of three questions: What do I enjoy? What am I good at? And what does the job market need? A subject that scores reasonably well on all three is usually a safer choice than one that scores extremely high on one and very low on the others. Students can gather _evidence_ for these questions by talking to graduates, reading about the daily work in different careers, and taking introductory courses before they commit.",
"5. Finally, it is worth remembering that a major does not decide a person's whole future. Many graduates work in fields that are only loosely connected to what they studied, because skills such as writing clearly, solving problems, and working with others are useful in almost any job. Choosing a major is important, but it is a starting point rather than a final destination. Students who keep learning after graduation will have opportunities that their degree alone could not give them."
],
"qs": [
{
"q": "According to paragraph 1, the second piece of advice tells students to ______.",
"o": [
"choose a subject that leads to a well-paid, secure job",
"study what they love, and success will come",
"follow the advice of their friends and teachers",
"choose the easiest subject at their university"
],
"e": "الفقرة 1: «The second is more practical: choose a subject that leads to a well-paid, secure job»."
},
{
"q": "What does the underlined word \"they\" in paragraph 1 refer to?",
"o": [
"the two approaches",
"students",
"families",
"university majors"
],
"e": "«Both approaches seem reasonable, yet they can push a student in opposite directions» ← they = الطريقتين (النصيحتين)."
},
{
"q": "What does the underlined word \"persist\" in paragraph 2 mean?",
"o": [
"continue trying",
"give up",
"complain",
"change the subject"
],
"e": "persist = يستمر ويواصل رغم الصعوبة، ومثلها في نفس الفقرة «keep going when the work becomes difficult»."
},
{
"q": "Which reason does the writer NOT give for why passion can be unreliable?",
"o": [
"Passionate students usually get lower grades.",
"Many eighteen-year-olds do not know yet what they truly love.",
"Interests often change over time.",
"Some fields have far more graduates than jobs."
],
"e": "الفقرة 3 ذكرت: «have not yet experienced enough subjects to know what they truly love» و«interests often change over time» و«far more graduates than there are jobs». أما الدرجات الأقل ما انذكرت."
},
{
"q": "What can we understand from the last sentence of paragraph 3?",
"o": [
"Becoming good at something may make people enjoy it more.",
"People should never follow their passion.",
"Passion always exists before people start something.",
"Skilled people usually lose their passion."
],
"e": "الفقرة 3: «passion often develops after people become skilled at something, rather than existing before they start» ← لما تتقن الشي ممكن تحبه بعدين."
},
{
"q": "What does the underlined word \"evidence\" in paragraph 4 mean?",
"o": [
"information that shows what is true",
"a final decision about your future",
"a short introductory course at university",
"a high salary from a secure job"
],
"e": "evidence = دليل/معلومات تثبت الشي. الطالب يجمع معلومات من الخريجين وغيرهم عشان يعرف الجواب الصحيح لأسئلته."
},
{
"q": "According to paragraph 4, which subject is usually a safer choice?",
"o": [
"one that scores reasonably well on all three questions",
"one that scores extremely high on one question",
"one that the student's family chooses",
"one that has the highest salary"
],
"e": "الفقرة 4: «A subject that scores reasonably well on all three is usually a safer choice»."
},
{
"q": "The writer mentions writing clearly and solving problems to show that ______.",
"o": [
"some skills are useful in almost any job",
"graduates should only work in the field they studied",
"writing is the most important university subject",
"employers do not care about university majors"
],
"e": "الفقرة 5: «skills such as writing clearly, solving problems, and working with others are useful in almost any job»."
},
{
"q": "What is the writer's attitude toward the advice \"follow your passion\"?",
"o": [
"It has real value, but it should not be the only factor.",
"It is useless advice.",
"It is the only advice students need.",
"It is only suitable for history and design students."
],
"e": "الكاتب عرض فايدة الشغف في الفقرة 2: «a strong interest is not a luxury but an important practical advantage»، وانتقاده في الفقرة 3: «passion can be unreliable»، وبعدين اقترح «treat the decision as a combination of three questions» ← الشغف له قيمة حقيقية بس مو العامل الوحيد."
},
{
"q": "What is the best title for the passage?",
"o": [
"Choosing a Major: Passion or Practicality?",
"How to Get a Job Without a Degree",
"Why Students Should Always Follow Their Passion",
"The Best Universities in Saudi Arabia"
],
"e": "القطعة تقارن بين نصيحتين: «follow your passion» والاختيار العملي «choose a subject that leads to a well-paid, secure job»، وبعدها تقترح «A more balanced approach» ← العنوان يجمع الاثنين."
}
]
},
{
"n": 23,
"k": 23,
"title": "Smart Cities: Promise and Problems",
"text": [
"1. Around the world, city governments are investing heavily in what are often called \"smart city\" projects. The basic idea is to use sensors, cameras, and the internet to collect information about how a city works, and then use that information to make better decisions. Supporters believe this approach could make cities more efficient, safer, and easier to live in, especially as urban populations continue to grow.",
"2. Transport is the area where the benefits are easiest to see. In some cities, traffic lights no longer follow a fixed timetable; instead, _they_ adjust to the number of cars waiting, which can reduce queues at busy junctions. Passengers can check on their phones exactly when the next bus will arrive, so they spend less time waiting at stops. Data from millions of journeys can also show planners where a new bus route or metro line is most needed, rather than relying on guesswork.",
"3. However, critics warn that smart technology raises serious questions. The first concerns privacy. A system that tracks vehicles, phones, and faces can reveal a great deal about where people go and whom they meet. If this information is not carefully protected, it could be misused or stolen by criminals. Many experts therefore argue that cities should collect only the data they genuinely need and should be open with residents about how it is used.",
"4. A second concern is cost and reliability. Smart systems are expensive to install and maintain, and they depend on software that can fail or be attacked. A city whose traffic, water, and electricity are all controlled by connected systems may become _vulnerable_ if those systems break down at the same time. Some planners also worry that money spent on impressive technology might be better spent on basic services such as wider pavements or more frequent buses.",
"5. Finally, there is the question of fairness. Services that rely on smartphone apps may be convenient for young, confident users but difficult for elderly residents or people who cannot afford the latest devices. A truly smart city, it could be argued, is not the one with the most technology, but the one that uses technology to serve all of its residents. Technology, in this view, should be a tool for good planning rather than a _substitute_ for it."
],
"qs": [
{
"q": "According to paragraph 1, the basic idea of a smart city is to ______.",
"o": [
"collect information about how a city works and use it to make better decisions",
"build more roads and buildings so that cities can grow faster",
"reduce the number of people who live and work in cities",
"replace city governments with computers that make all decisions"
],
"e": "الفقرة 1: «to collect information about how a city works, and then use that information to make better decisions»."
},
{
"q": "What does the underlined word \"they\" in paragraph 2 refer to?",
"o": [
"traffic lights",
"cars",
"passengers",
"busy junctions"
],
"e": "«traffic lights no longer follow a fixed timetable; instead, they adjust to the number of cars waiting» ← they = إشارات المرور."
},
{
"q": "Which transport benefit does the writer NOT mention?",
"o": [
"cheaper bus tickets",
"shorter queues at busy junctions",
"knowing when the next bus will arrive",
"planning new routes based on data"
],
"e": "الفقرة 2 ذكرت: «reduce queues at busy junctions» و«when the next bus will arrive» و«where a new bus route or metro line is most needed». أما التذاكر الأرخص ما انذكرت."
},
{
"q": "According to paragraph 3, what could happen if personal information is not carefully protected?",
"o": [
"It could be misused or stolen by criminals.",
"Traffic lights could stop working.",
"Residents could stop using buses.",
"Cities could collect less data."
],
"e": "الفقرة 3: «If this information is not carefully protected, it could be misused or stolen by criminals»."
},
{
"q": "What do many experts argue cities should do with data?",
"o": [
"collect only the data they need and be open about how it is used",
"collect as much data as possible and never explain how it is used",
"sell the data to private companies to help pay for new projects",
"stop using cameras and sensors completely and collect no data at all"
],
"e": "الفقرة 3: «cities should collect only the data they genuinely need and should be open with residents about how it is used»."
},
{
"q": "What does the underlined word \"vulnerable\" in paragraph 4 mean?",
"o": [
"easily harmed or damaged",
"very modern and connected",
"well protected and safe",
"cheap and easy to run"
],
"e": "vulnerable = معرّض للضرر وسهل يتأذى. السياق: إذا تعطلت الأنظمة كلها مرة وحدة المدينة تتضرر."
},
{
"q": "The writer mentions wider pavements and more frequent buses to show that ______.",
"o": [
"some money could be spent on basic services instead of expensive technology",
"smart technology is cheaper to install than wider pavements and buses",
"buses are the most important part of every smart city transport system",
"planners want people to stop using cars and walk on the pavements"
],
"e": "الفقرة 4: «money spent on impressive technology might be better spent on basic services such as wider pavements or more frequent buses»."
},
{
"q": "What can we understand from paragraph 5?",
"o": [
"A city that depends only on apps may leave some residents behind.",
"Elderly people never use technology or smartphone apps in cities.",
"Young people do not need any of the services that cities offer.",
"Smart cities should stop using smartphone apps for their services."
],
"e": "الفقرة 5: الخدمات اللي تعتمد على التطبيقات «difficult for elderly residents or people who cannot afford the latest devices» ← فيه ناس ممكن ينحرمون منها."
},
{
"q": "What does the underlined word \"substitute\" in paragraph 5 mean?",
"o": [
"a replacement",
"a tool",
"a problem",
"a plan"
],
"e": "substitute = بديل. يعني التقنية لازم تساعد التخطيط الجيد، مو تصير بديل عنه."
},
{
"q": "What is the best title for the passage?",
"o": [
"Smart Cities: Promise and Problems",
"How to Build Your Own Smartphone App",
"Why Cities Should Stop Using Technology",
"The History of Public Transport"
],
"e": "القطعة تذكر فوايد المدن الذكية «Transport is the area where the benefits are easiest to see»، وبعدها مشاكلها «critics warn that smart technology raises serious questions» ← العنوان Smart Cities: Promise and Problems."
}
]
},
{
"n": 24,
"k": 24,
"title": "Why We Need Bees",
"text": [
"1. When people think of bees, they usually think of honey. Yet honey is only a small part of the value bees provide. As they move from flower to flower collecting food, bees carry pollen, which allows many plants to produce fruit and seeds. This process, known as pollination, is _essential_ for a large number of the crops that humans eat, including apples, almonds, and many vegetables. Without pollinators, our diet would be far less varied.",
"2. In recent decades, scientists and farmers in many countries have reported worrying declines in bee populations. Beekeepers in parts of Europe and North America have sometimes lost a significant share of their colonies over a single winter, and studies suggest that many species of wild bees have become less common. Because wild bees also pollinate crops and wild plants, their decline may be an even greater concern than the losses of honeybees, which beekeepers can at least try to replace.",
"3. There appears to be no single cause. Instead, researchers point to a combination of pressures. As natural land is turned into farms, roads, and buildings, bees lose the variety of flowers they depend on. Certain pesticides, which are chemicals used to kill insects that damage crops, can harm bees as well. Parasites and diseases spread easily between colonies, and changes in climate may cause flowers to bloom at times when bees are not active. Each factor on its own might be manageable, but together they put bees under serious stress.",
"4. The consequences of losing bees would not be limited to farms. Many wild plants also rely on insects for pollination, and the birds and animals that eat those plants and their fruit would be affected in turn. Some farmers have already had to rent hives and transport _them_ over long distances simply to make sure their crops are pollinated, which adds to the cost of food.",
"5. Fortunately, the situation is not hopeless. Governments in some regions have _restricted_ the use of pesticides that are considered most harmful to bees. Farmers can leave strips of wild flowers along the edges of their fields, and city residents can plant bee-friendly flowers in gardens and on balconies. Such actions may seem small, but if they are adopted widely, they could make a real difference. Protecting bees, in the end, is a way of protecting our own food supply."
],
"qs": [
{
"q": "The writer says that honey is ______.",
"o": [
"only a small part of the value bees provide",
"the most important thing bees provide",
"needed for pollination",
"the reason bee populations are falling"
],
"e": "الفقرة 1: «Yet honey is only a small part of the value bees provide»."
},
{
"q": "The writer mentions apples, almonds, and many vegetables to show that ______.",
"o": [
"many crops that humans eat depend on pollination",
"bees prefer fruit to flowers",
"honey is made from apples and almonds",
"vegetables do not need pollinators"
],
"e": "الفقرة 1: «pollination, is essential for a large number of the crops that humans eat, including apples, almonds, and many vegetables»."
},
{
"q": "What does the underlined word \"essential\" in paragraph 1 mean?",
"o": [
"very necessary",
"harmful",
"unusual",
"expensive"
],
"e": "essential = ضروري جداً، والجملة بعدها توضّح: «Without pollinators, our diet would be far less varied»."
},
{
"q": "Why may the decline of wild bees be a greater concern than the losses of honeybees?",
"o": [
"Beekeepers cannot replace wild bees in the same way.",
"Wild bees produce more honey than honeybees.",
"Wild bees live only in Europe and North America.",
"Honeybees do not pollinate crops."
],
"e": "الفقرة 2: خسارة نحل العسل يقدر النحّال يعوّضها «honeybees, which beekeepers can at least try to replace»، أما النحل البري لا."
},
{
"q": "Which of these does the writer NOT mention as a pressure on bees?",
"o": [
"noise from cities",
"the loss of natural land",
"certain pesticides",
"parasites and diseases"
],
"e": "الفقرة 3 ذكرت: «natural land is turned into farms, roads, and buildings» و«Certain pesticides» و«Parasites and diseases» وتغيّر المناخ. أما الإزعاج ما انذكر."
},
{
"q": "What is the writer's main purpose in paragraph 4?",
"o": [
"to show that losing bees would affect more than farms",
"to explain why farmers prefer wild bees",
"to describe the birds that eat wild plants",
"to show that food will soon become cheaper"
],
"e": "الفقرة 4 أولها: «The consequences of losing bees would not be limited to farms» ← الضرر يوصل للنباتات البرية والطيور والحيوانات وسعر الأكل."
},
{
"q": "What does the underlined word \"them\" in paragraph 4 refer to?",
"o": [
"hives",
"farmers",
"crops",
"birds and animals"
],
"e": "«Some farmers have already had to rent hives and transport them over long distances» ← them = خلايا النحل."
},
{
"q": "What does the underlined word \"restricted\" in paragraph 5 mean?",
"o": [
"limited by rules",
"encouraged",
"increased",
"studied"
],
"e": "restricted = حدّت منه وقيّدته بقوانين. الحكومات قللت استخدام المبيدات الأكثر ضرراً على النحل."
},
{
"q": "Which statement would the writer most likely agree with?",
"o": [
"Small actions by many people can help protect bees.",
"Nothing can be done to save bees.",
"Only governments can protect bees.",
"Bees are important mainly because of honey."
],
"e": "الفقرة 5: «Such actions may seem small, but if they are adopted widely, they could make a real difference»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Bees: Small Insects with a Big Role in Our Food",
"How to Produce More Honey at Home",
"The Daily Life of a Beekeeper in Europe",
"Why Farmers Use Pesticides on Their Crops"
],
"e": "القطعة تشرح دور النحل في تلقيح المحاصيل، وأسباب تناقصه، ونتائج خسارته، وكيف نحميه عشان نحمي أكلنا."
}
]
},
{
"n": 25,
"k": 25,
"title": "Managing Your Time: Working Smarter, Not Longer",
"text": [
"1. Many students believe that the key to managing time is simply to work longer hours. They stay up late, study while checking messages, and feel proud of how busy they are. However, research on attention and productivity suggests that the amount of time we spend on a task matters less than how we spend it. Being busy, in other words, is not the same as being productive.",
"2. One common habit is multitasking, such as writing an assignment while replying to messages and watching videos. Many people assume this saves time, but psychologists have found that the brain does not really do two demanding tasks at once. Instead, it switches rapidly between _them_, and each switch costs a little time and concentration. As a result, people who multitask often take longer to finish their work and make more mistakes, even though they may feel more efficient.",
"3. Another obstacle is procrastination, the habit of delaying tasks that need to be done. It is often seen as a sign of laziness, but some researchers argue that it is more closely linked to emotions. People tend to put off tasks that make them feel anxious, bored, or unsure where to start. If this view is correct, then simply telling yourself to work harder is unlikely to help. A more effective approach may be to break a large task into small, clear steps, so that starting feels less _overwhelming_.",
"4. Many time-management experts also recommend working in focused blocks. A student might, for example, study for twenty-five minutes with the phone in another room, then take a short break before beginning the next block. This method works partly because a fixed period feels manageable, and partly because the regular breaks help to maintain energy. It should be noted, however, that no single technique suits everyone; some people concentrate best in longer sessions, and the important thing is to find a pattern that can be kept up.",
"5. Finally, good time management is as much about deciding what not to do as about doing more. Students who try to accept every invitation and complete every task perfectly often end up _exhausted_. Setting priorities, by asking which tasks are truly important and which can wait, allows people to use their limited energy where it matters most. Sleep, too, should be treated as a priority rather than a luxury, since a tired mind works slowly and remembers less."
],
"qs": [
{
"q": "According to paragraph 1, research suggests that ______.",
"o": [
"how we spend time on a task matters more than how long we spend",
"students should work longer hours if they want to manage time well",
"busy people are always more productive than people who are not busy",
"studying late at night is the best method for most students"
],
"e": "الفقرة 1: «the amount of time we spend on a task matters less than how we spend it»."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"two demanding tasks",
"psychologists",
"people who multitask",
"mistakes"
],
"e": "«the brain does not really do two demanding tasks at once. Instead, it switches rapidly between them» ← them = المهمتين."
},
{
"q": "What can we understand from paragraph 2?",
"o": [
"Feeling efficient does not always mean being efficient.",
"Multitasking helps people finish their work faster.",
"The brain can easily do two demanding tasks at once.",
"People who multitask never make mistakes."
],
"e": "الفقرة 2: اللي يسوون أكثر من شي «often take longer… and make more mistakes, even though they may feel more efficient» ← يحسون إنهم منجزين وهم مو كذا."
},
{
"q": "According to some researchers, procrastination is more closely linked to ______.",
"o": [
"emotions",
"laziness",
"lack of sleep",
"multitasking"
],
"e": "الفقرة 3: «some researchers argue that it is more closely linked to emotions»."
},
{
"q": "Which reason for putting off tasks does the writer NOT mention?",
"o": [
"The deadline is still far away.",
"The task makes people feel anxious.",
"The task makes people feel bored.",
"People are unsure where to start."
],
"e": "الفقرة 3: «tasks that make them feel anxious, bored, or unsure where to start» ← إن الموعد النهائي لسه بعيد ما انذكر."
},
{
"q": "What does the underlined word \"overwhelming\" in paragraph 3 mean?",
"o": [
"too big or difficult to deal with",
"enjoyable and relaxing to work on",
"too unimportant to think about",
"quick and simple to start and finish"
],
"e": "overwhelming = شي كبير ومرهق تحس إنك ما تقدر عليه. عشان كذا الكاتب ينصح تقسم المهمة لخطوات صغيرة."
},
{
"q": "The writer gives the example of studying for twenty-five minutes with the phone in another room to show ______.",
"o": [
"how working in focused blocks can be done",
"that phones should never be used by students",
"that breaks waste a lot of time",
"that longer study sessions are always better"
],
"e": "الفقرة 4: بعد «recommend working in focused blocks» قال «A student might, for example, study for twenty-five minutes…» ← مثال على طريقة الفترات المركزة."
},
{
"q": "What is the writer's attitude toward the focused-block method?",
"o": [
"It is useful, but it does not suit everyone.",
"It is the only method that works.",
"It is a waste of time.",
"It works only for people who study at night."
],
"e": "الفقرة 4: شرح ليش تنفع، وبعدها: «no single technique suits everyone; some people concentrate best in longer sessions»."
},
{
"q": "What does the underlined word \"exhausted\" in paragraph 5 mean?",
"o": [
"very tired",
"very successful",
"very popular",
"very bored"
],
"e": "exhausted = تعبان مرة ومستنزف. اللي يقبل كل دعوة ويبي يخلص كل شي بكمال يتعب."
},
{
"q": "What is the best title for the passage?",
"o": [
"Better Ways to Manage Your Time",
"Why Students Should Study Longer Hours Every Night",
"How to Reply to Messages While Doing Homework",
"A Guide to Popular Video Games for Students"
],
"e": "الفقرة 1: «Being busy, in other words, is not the same as being productive»، وباقي القطعة طرق أفضل لتنظيم الوقت (ترك تعدد المهام، تقسيم المهمة لخطوات، الفترات المركزة، الأولويات والنوم) ← فأفضل عنوان: Better Ways to Manage Your Time"
}
]
}
];
