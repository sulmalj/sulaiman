/* القطع (Reading) — كل قطعة مع أسئلتها — ملف مولّد بالسكربت tools/english/build_data.py (لا تعدّله يدوياً)
   o[0] = الإجابة الصحيحة (الخيارات تنخلط في الموقع) */
window.READING = [
{
"n": 1,
"k": 1,
"title": "Laughter in Hospitals and Schools",
"text": [
"1. There are many positive effects of laughter. Laughing is fun. Laughing helps us relax in stressful situations. Laughter also helps people forget about their pain and _facilitates_ learning. Indeed, one study found that students who laugh more remember more things and complete their homework more quickly. With these facts in mind, there are two areas where we should try to help people laugh more: hospitals and schools.",
"2. Hospitals, of course, have many people who are in pain. For serious pain, doctors _prescribe_ drugs to patients, but laughter could help reduce the need to take too many pills. How? One idea is for hospitals to make sure that each room has a television or a laptop where patients can watch funny videos. Another idea is for hospitals to give patients fun games to play with each other. This is probably better than funny videos because people laugh the most when they're around other people. Finally, hospitals can tell visitors how helpful laughter is. _They_ should try to make the patients they're visiting laugh.",
"3. Schools are another great place to use laughter. Professors and teachers usually work hard to create great lessons, but teachers rarely try hard enough to make their students laugh. One accounting professor, for example, knew that his lessons were boring, so he told the students a joke every five or ten minutes. The jokes weren't really funny, but his students still laughed. _They_ also remembered the lessons more. Simple ideas like this can make a big difference."
],
"qs": [
{
"q": "The writer thinks that telling students jokes is a ______.",
"o": [
"simple idea",
"funny idea",
"boring idea",
"great idea"
],
"e": "الفقرة 3 آخر جملة: «Simple ideas like this can make a big difference» ← الكاتب يعتبر فكرة النكت فكرة بسيطة (simple idea).",
"x": 1
},
{
"q": "People laugh the most when they're ______.",
"o": [
"around other people",
"in stressful situations",
"watching funny videos",
"not in pain or at school"
],
"e": "الفقرة 2: «people laugh the most when they're around other people».",
"x": 1
},
{
"q": "Laughter helps people ______ their pain.",
"o": [
"forget about",
"remember",
"explain",
"learn about"
],
"e": "الفقرة 1: «Laughter also helps people forget about their pain».",
"x": 1
},
{
"q": "Why does the writer think professors and teachers should try to make students laugh?",
"o": [
"Students will remember more from the lessons.",
"Students never complete their homework quickly.",
"Professors rarely make great efforts.",
"Classes are usually boring."
],
"e": "الفقرة 3: الطلاب ضحكوا و«They also remembered the lessons more» ← يتذكرون الدروس أكثر.",
"x": 1
},
{
"q": "What does the underlined word \"facilitates\" in paragraph 1 mean?",
"o": [
"helps",
"remembers",
"stops",
"slows down"
],
"e": "facilitates learning = يسهّل التعلّم ويساعد عليه ← helps.",
"x": 1
},
{
"q": "What does the underlined word \"prescribe\" in paragraph 2 mean?",
"o": [
"give",
"take",
"watch",
"use"
],
"e": "«doctors prescribe drugs to patients» = الدكتور يعطي (يصرف) الدواء للمريض ← give.",
"x": 1
},
{
"q": "What does the underlined word \"They\" in paragraph 2 refer to?",
"o": [
"visitors",
"videos",
"hospitals",
"patients"
],
"e": "الجملة قبلها: «hospitals can tell visitors how helpful laughter is. They should try…» ← They = الزوار (visitors).",
"x": 1
},
{
"q": "What does the underlined word \"They\" in paragraph 3 refer to?",
"o": [
"The students",
"The professors",
"The jokes",
"The lessons"
],
"e": "الجملة قبلها: «his students still laughed. They also remembered…» ← They = الطلاب.",
"x": 1
},
{
"q": "What is the best title for the passage?",
"o": [
"Two places that need more laughter",
"Patients and laughter",
"Students and laughter",
"The main reasons of laughter"
],
"e": "الفقرة 1: «there are two areas where we should try to help people laugh more: hospitals and schools» ← مكانين يحتاجون ضحك أكثر.",
"x": 1
},
{
"q": "According to paragraph 1, students who laugh more ______.",
"o": [
"complete their homework more quickly",
"take fewer tests at school",
"sleep better at night",
"talk more in class"
],
"e": "الفقرة 1: «one study found that students who laugh more remember more things and complete their homework more quickly»."
}
],
"x": 1
},
{
"n": 2,
"k": 2,
"title": "Working From Home",
"text": [
"1. Alex begins his day with some coffee. Then he takes a short walk in a nearby park before _heading to_ work. But he doesn't need to go far. He just walks back home, opens up his laptop, and gets started. Alex works from home every day. You might think this sounds great. After all, many people don't like their offices. At home, they can make things exactly how they like. But many workers actually find working from home to be more stressful. Alex says this is true for him. He explains, \"It's like the workday never ends. When I used to go to an office, I'd leave work and not think about _it_ until the next day. Now, I answer emails and texts at all hours of the day.\"",
"2. Working from home is becoming more common and even normal in some industries. For employers, it saves money. They don't need to pay for office space. They also don't need to _spring for_ things like office parties, or provide places like game rooms where workers can relax. And then workers save a lot of time. In most countries, workers need 30 to 60 minutes to get to work. Working from home means you get an hour or two of extra time each day.",
"3. But, as we can see with Alex, it's not perfect for workers. That's why businesses should still try to reduce workplace stress. One idea is to provide online meditation classes. Workers can do something quiet together that helps _them_ improve their attention. Another idea is to just make a rule that says workers can't send emails after a certain time. Working from home certainly has its advantages, but it's not without problems. Ideas like these, though, can make it much better."
],
"qs": [
{
"q": "How much time do workers need to get to work in most countries?",
"o": [
"30 to 60 minutes",
"An hour or two",
"10 to 20 minutes",
"More than two hours"
],
"e": "الفقرة 2: «In most countries, workers need 30 to 60 minutes to get to work».",
"x": 1
},
{
"q": "Workers who take online meditation classes ______.",
"o": [
"can improve their attention",
"can't send emails after a certain time",
"go to the office every day",
"need more time to get to work"
],
"e": "الفقرة 3: «Workers can do something quiet together that helps them improve their attention».",
"x": 1
},
{
"q": "In paragraph 2, why does the writer mention not needing to provide places for workers to relax?",
"o": [
"To show how employers save money",
"To show that workers don't like game rooms",
"To explain why workers feel stressed",
"To show that offices are not safe"
],
"e": "الفقرة 2 تتكلم عن توفير المال: «For employers, it saves money… They also don't need to… provide places like game rooms» ← المثال يوضّح كيف يوفّر صاحب العمل.",
"x": 1
},
{
"q": "What do the underlined words \"heading to\" in paragraph 1 mean?",
"o": [
"going to",
"coming back from",
"looking at",
"thinking about"
],
"e": "«before heading to work» = قبل ما يروح للعمل ← going to."
},
{
"q": "What does the underlined word \"it\" in paragraph 1 refer to?",
"o": [
"work",
"the park",
"the coffee",
"the laptop"
],
"e": "«I'd leave work and not think about it until the next day» ← it ترجع على work."
},
{
"q": "What do the underlined words \"spring for\" in paragraph 2 mean?",
"o": [
"pay for",
"look for",
"ask for",
"wait for"
],
"e": "«spring for things like office parties» = يدفع تكاليف الحفلات ← pay for."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"workers",
"businesses",
"classes",
"emails"
],
"e": "«Workers can do something quiet together that helps them…» ← them = العمّال (workers)."
},
{
"q": "Why does Alex find working from home stressful?",
"o": [
"He feels like the workday never ends.",
"He doesn't like his laptop.",
"He needs an hour to get to work.",
"His home is too noisy."
],
"e": "الفقرة 1: Alex يقول «It's like the workday never ends… I answer emails and texts at all hours»."
},
{
"q": "What does Alex do before he starts work?",
"o": [
"He has some coffee and takes a short walk.",
"He drives to his office in the city centre.",
"He reads the news on his phone in bed.",
"He goes to an online meditation class."
],
"e": "الفقرة 1: «Alex begins his day with some coffee. Then he takes a short walk in a nearby park»."
},
{
"q": "What is the best title for the passage?",
"o": [
"The Good and Bad Sides of Working From Home",
"Why Working From Home Is Perfect for Everyone",
"Why Offices Are Always Better Than Home",
"Office Parties: What Employers Should Pay For"
],
"e": "آخر الفقرة 3: «Working from home certainly has its advantages, but it's not without problems» ← فأفضل عنوان: The Good and Bad Sides of Working From Home"
}
],
"x": 1
},
{
"n": 3,
"k": 3,
"title": "Stress at Work",
"text": [
"1. The stress of modern jobs can make it challenging for employees to focus while they are working. This stress may also lead to employees getting sick more often or even quitting. When this happens, employers must use time and resources to find and train new employees.",
"2. Popular solutions for this problem may include buying plants for the office, providing lunches on birthdays, creating game rooms, and hosting meditation classes. These solutions may help some employees, but they don't _give a boost_ to everyone. Some employees, for example, say meditation doesn't support them at all and adds to their stress. They spend the whole time thinking about the problems in their lives, and it's hard to stop thinking about _them_ when they return to work afterwards.",
"3. In fact, the best solutions for workplace stress tend to happen _spontaneously_. Carefully planned solutions can feel like more work for employees, while those that happen in the moment tend to be more effective and enjoyable.",
"4. So, for example, instead of carefully planning a party, buying gifts, or building a game room, be ready to act quickly when you hear a good idea. Someone might say, \"I wish I could try every cake at that café.\" Suddenly, the boss could say, \"That's a great idea! Let's all go do it right now!\" Imagine working somewhere where fun things like that could happen at any moment. That doesn't sound like a stressful workplace at all!"
],
"qs": [
{
"q": "The writer says it's ______ for employees to focus while working.",
"o": [
"challenging",
"successful",
"interesting",
"relaxing"
],
"e": "الفقرة 1: «The stress of modern jobs can make it challenging for employees to focus».",
"x": 1
},
{
"q": "Some employees don't like meditation classes because the classes ______.",
"o": [
"add to their stress",
"use time and resources",
"take place during lunch",
"make them miss work"
],
"e": "الفقرة 2: «meditation doesn't support them at all and adds to their stress».",
"x": 1
},
{
"q": "The writer says that carefully planned solutions feel like ______ for employees.",
"o": [
"more work",
"more time",
"more rest",
"more fun"
],
"e": "الفقرة 3: «Carefully planned solutions can feel like more work for employees».",
"x": 1
},
{
"q": "The writer gives an example to show how ______.",
"o": [
"trying cakes together can be better than building a game room",
"planning a party can be better than building a game room",
"building a game room can be better than trying cakes",
"planning a party can be better than trying cakes"
],
"e": "الفقرة 4: بدل بناء غرفة ألعاب (building a game room)، المدير يقول «Let's all go do it right now!» ويروحون يجربون الكيك ← تجربة الكيك أحسن من بناء غرفة ألعاب.",
"x": 1
},
{
"q": "Which idea for reducing stress does the writer NOT mention?",
"o": [
"buying books",
"buying plants",
"buying lunches",
"buying gifts"
],
"e": "الفقرة 2 ذكرت plants و lunches، والفقرة 4 ذكرت gifts. أما الكتب (books) ما انذكرت.",
"x": 1
},
{
"q": "What do the underlined words \"give a boost\" in paragraph 2 mean?",
"o": [
"help",
"stress",
"entertain",
"stop"
],
"e": "«they don't give a boost to everyone» = ما تساعد الكل ← help.",
"x": 1
},
{
"q": "What does the underlined word \"spontaneously\" in paragraph 3 mean?",
"o": [
"without planning",
"without helping",
"with careful thinking",
"with a lot of work"
],
"e": "الفقرة 3: الحلول «spontaneously» عكس «Carefully planned»، يعني تصير فجأة «in the moment» ← without planning.",
"x": 1
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"the problems in their lives",
"the employees",
"the meditation classes",
"the game rooms"
],
"e": "«thinking about the problems in their lives, and it's hard to stop thinking about them» ← them = المشاكل."
},
{
"q": "What happens when employees get sick often or quit?",
"o": [
"Employers must find and train new employees.",
"Employers must build more game rooms.",
"Employees must take more meditation classes.",
"Employees must work longer hours."
],
"e": "الفقرة 1: «employers must use time and resources to find and train new employees»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Spontaneous ways to reduce stress at work",
"How to plan a perfect office party",
"Why meditation is the best solution",
"Building game rooms at work"
],
"e": "القطعة كلها عن حلول ضغط العمل، وأحسنها اللي تصير بدون تخطيط (spontaneously)."
}
],
"x": 1
},
{
"n": 4,
"k": 26,
"title": "Apples in Washington State",
"text": [
"1. In most countries, people eat apples all the time. They're sweet, crunchy, and healthy. For this reason, they're a _beloved_ snack for both children and adults. People also love to use apples to make apple juice, apple pie, apple butter, and so on. But while apples are popular everywhere, the people who love apples most might live in Washington State, USA.",
"2. Located next to the Pacific Ocean in the northwest of the United States, Washington State is famous for its biggest city, Seattle, and for its technology companies, like Amazon. But _it_ is also a great place to grow apples. The weather is usually sunny, but not too hot, in the summer. This is good because apple trees need at least six hours of sun every day when they're growing in the summer. The weather should be warm, but not too hot outside. However, apple trees also need the temperature to be cold sometimes. Every year, the trees should get between 500 and 1,000 hours between 0 and 5°C. Their flowers don't grow well if the weather isn't cold sometimes. That's fine because in Washington the winter temperatures are a little cold and it can rain 15 to 25 days each month. This would _cripple_ another fruit like an orange, but not apples. In Washington State, farmers grow more than 10 billion (that's 10,000,000,000) of _them_ every year.",
"3. The people in Washington love to celebrate their fruit. Starting in the spring, there are Apple Blossom Festivals, where you can listen to music and enjoy the beautiful apple trees. Then, usually in October, there are festivals where you can do things like pick apples, try to win apple-eating contests, and drive around the farms. Many people in Washington think it's the best time of the year."
],
"qs": [
{
"q": "The writer says that people eat apples in ______.",
"o": [
"most countries",
"diet classes",
"the kitchen",
"some states"
],
"e": "الفقرة 1 أول جملة: «In most countries, people eat apples all the time» ← الجواب most countries.",
"x": 1
},
{
"q": "Which technology company does the author mention?",
"o": [
"Amazon",
"Starbucks",
"Seattle",
"Northwest"
],
"e": "الفقرة 2: «famous for its biggest city, Seattle, and for its technology companies, like Amazon» ← Seattle مدينة مو شركة، وNorthwest مكان (شمال غرب أمريكا).",
"x": 1
},
{
"q": "People in Washington celebrate apples by ______.",
"o": [
"listening to music",
"cooking food",
"selling flowers",
"performing dances"
],
"e": "الفقرة 3: «there are Apple Blossom Festivals, where you can listen to music and enjoy the beautiful apple trees» ← يحتفلون بسماع الموسيقى.",
"x": 1
},
{
"q": "What does the underlined word \"it\" in paragraph 2 refer to?",
"o": [
"Washington State",
"The United States",
"the biggest city",
"technology company"
],
"e": "الفقرة 2: «Washington State is famous for its biggest city, Seattle, and for its technology companies, like Amazon. But it is also a great place to grow apples» ← الكلام كله عن ولاية Washington، فـ it = Washington State.",
"x": 1
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"apples",
"farmers",
"trees",
"oranges"
],
"e": "الفقرة 2 آخر جملة: «farmers grow more than 10 billion (that's 10,000,000,000) of them every year» ← المزارعين يزرعون أكثر من 10 مليار تفاحة، فـ them = apples.",
"x": 1
},
{
"q": "How is growing apples different from growing oranges?",
"o": [
"Apples need warm and cold weather.",
"Oranges need extremely rainy weather.",
"Apples need temperatures to always be cold.",
"Oranges need six hours of sun every day."
],
"e": "الفقرة 2: التفاح يحتاج جو دافي في الصيف «The weather should be warm, but not too hot outside» ويحتاج برد أحيانًا «apple trees also need the temperature to be cold sometimes»، أما البرد والمطر فيضرون البرتقال: «This would cripple another fruit like an orange, but not apples».",
"x": 1
},
{
"q": "Which activity does the author NOT mention?",
"o": [
"learning the history of apples",
"joining apple eating contests",
"making apple juice",
"driving around a farm"
],
"e": "الفقرة 1 ذكرت «apple juice»، والفقرة 3 ذكرت «try to win apple-eating contests, and drive around the farms». أما تعلّم تاريخ التفاح ما انذكر أبدًا.",
"x": 1
},
{
"q": "What does the word \"beloved\" in paragraph 1 mean?",
"o": [
"really liked",
"a little liked",
"sometimes eaten",
"not eaten"
],
"e": "الفقرة 1: «They're sweet, crunchy, and healthy. For this reason, they're a beloved snack for both children and adults» ← حلو ومقرمش وصحي، فالكل يحبه كثير ← beloved = really liked.",
"x": 1
},
{
"q": "What does the word \"cripple\" in paragraph 2 mean?",
"o": [
"hurt badly or kill",
"make sweet like sugar",
"make grow large",
"give a lot of water to"
],
"e": "الفقرة 2: البرد والمطر الكثير «This would cripple another fruit like an orange, but not apples» ← يضرون البرتقال كثير بس ما يضرون التفاح ← cripple = hurt badly or kill.",
"x": 1
},
{
"q": "What is the best title for the passage?",
"o": [
"Washington: The Best Place to Grow Apples",
"The Biggest Types of Trees in USA",
"How to Grow Apples in Warm Weather",
"The Advantages of Eating Apples"
],
"e": "القطعة كلها عن التفاح في Washington: إنها «a great place to grow apples» (الفقرة 2)، وأهلها يحتفلون فيه (الفقرة 3) ← العنوان Washington: The Best Place to Grow Apples.",
"x": 1
}
],
"x": 1
},
{
"n": 5,
"k": 27,
"title": "My Family",
"text": [
"1. What kind of people are your family? What do they look like? As for me, everyone in my family is a bit different. My dad and his brothers, for example, are all quite large. My mom and my sisters are rather thin, though. Actually, everyone on my mom's side of the family is _slender_. And it's not just how we look. Some people in my family are always shy around new people. They're cool people, but they don't know what to say. Others are very outgoing and love telling stories. It's not a problem though. Often the more outgoing family members introduce shy family members to new friends.",
"2. It's interesting to think how we are different from each other. There are, however, two things that are true for everyone in my family. First, everyone is very neat. Even busy family members still find time to keep things clean. My cousin, for example, goes to school and has a part-time job at a bookstore. Her life is _hectic_ but her kitchen is always clean because _she_ washes all the dishes and wipes down the tables and counters after each meal.",
"3. The second thing that is true for everyone in my family is that we're all so nice. We all love to help out our friends and family members. Especially when someone has a big problem, we all focus on helping to solve the problem. For example, recently my uncle lost his job. He is my dad's younger brother. Right away, everyone started texting him to ask how they could help. We also told him about new job opportunities. It wasn't long before _he_ got a new job."
],
"qs": [
{
"q": "The writer says that everyone in her family is ______.",
"o": [
"nice",
"busy",
"honest",
"similar"
],
"e": "الفقرة 3: «we're all so nice» ← nice. وما يصير similar لأن الفقرة 1 تقول «everyone in my family is a bit different».",
"x": 1
},
{
"q": "Who does the writer say is thin?",
"o": [
"her mom",
"her dad",
"her cousin",
"her brother"
],
"e": "الفقرة 1: «My mom and my sisters are rather thin» ← her mom.",
"x": 1
},
{
"q": "The writer believes that some people in her family are ______.",
"o": [
"outgoing",
"creative",
"talkative",
"dangerous"
],
"e": "الفقرة 1: «Others are very outgoing and love telling stories» ← الكلمة في القطعة outgoing (انتبه لفخ talkative).",
"x": 1
},
{
"q": "What does the underlined word \"she\" in paragraph 2 refer to?",
"o": [
"the writer's cousin",
"the writer's sister",
"the writer's mother",
"the writer's aunt"
],
"e": "الفقرة 2: الكلام عن «My cousin… her kitchen is always clean because she washes all the dishes» ← she = the writer's cousin.",
"x": 1
},
{
"q": "What does the underlined word \"he\" in paragraph 3 refer to?",
"o": [
"the writer's uncle",
"the writer's friend",
"the writer's dad",
"the writer's brother"
],
"e": "الفقرة 3: «recently my uncle lost his job» و«It wasn't long before he got a new job» ← he = the writer's uncle.",
"x": 1
},
{
"q": "The writer's cousin cleans her kitchen ______.",
"o": [
"after meals",
"once a day",
"before school",
"on weekends"
],
"e": "الفقرة 2: «wipes down the tables and counters after each meal» ← after meals.",
"x": 1
},
{
"q": "Where does the writer's cousin work?",
"o": [
"a bookstore",
"a bank",
"a phone store",
"a restaurant"
],
"e": "الفقرة 2: «has a part-time job at a bookstore» ← a bookstore.",
"x": 1
},
{
"q": "What does the underlined word \"slender\" in paragraph 1 mean?",
"o": [
"thin",
"large",
"cool",
"quiet"
],
"e": "الفقرة 1: «My mom and my sisters are rather thin… everyone on my mom's side of the family is slender» ← slender = thin.",
"x": 1
},
{
"q": "What does the underlined word \"hectic\" in paragraph 2 mean?",
"o": [
"busy",
"boring",
"impossible",
"neat"
],
"e": "الفقرة 2: «Even busy family members still find time to keep things clean»، وبنت عمها تدرس وتشتغل ← hectic = busy.",
"x": 1
},
{
"q": "What is the best title for the passage?",
"o": [
"Ways My Family Is the Same and Different",
"How My Mom and Dad Are Different",
"The Most Interesting Family in the World",
"My Cousin's Life, Work and Characteristics"
],
"e": "الفقرة 1 عن الاختلافات، والفقرة 2: «There are, however, two things that are true for everyone in my family» ← العنوان Ways My Family Is the Same and Different.",
"x": 1
}
],
"x": 1
},
{
"n": 6,
"k": 4,
"title": "Making Friends at University",
"text": [
"1. Starting university is an exciting step, but for many young people it is also a lonely time. Some students move to a new city and leave their families and old friends behind, while others simply find that their school friends have chosen different universities. Although these feelings are normal, they should not be ignored. Research suggests that students who build friendships during their first year usually feel happier, and they are also less likely to leave their studies early.",
"2. One of the easiest ways to meet people is to join a student club. Most universities have clubs for sports, volunteering, photography and many other interests. Because members already share a hobby, conversations start naturally and nobody has to search for something to say. Study groups are another good choice. When classmates prepare for an exam together, they help each other with difficult lessons, and they _gradually_ get to know each other as well.",
"3. However, for shy students, even a short conversation can feel difficult. Experts _encourage_ these students to begin with small steps instead of waiting for a big chance. They can arrive at class a few minutes early and say hello to the person sitting next to them, or they can ask a classmate a simple question about the homework. Faisal, a second-year student, says that this worked for him. \"In my first month, I didn't know anyone,\" he explains. \"Then I started asking the student next to me about our assignments. Now _he_ is my closest friend.\"",
"4. Finally, new students should remember that real friendships need time. It is common to feel disappointed when a friendship does not grow quickly, but this is not a reason to give up. A friendly smile, a little effort every day and some patience can turn a group of strangers into friends for life."
],
"qs": [
{
"q": "The writer says that students who build friendships during their first year usually feel ______.",
"o": [
"happier",
"lonelier",
"more tired",
"more nervous"
],
"e": "الفقرة 1: «students who build friendships during their first year usually feel happier» ← يحسون بسعادة أكثر."
},
{
"q": "Conversations start naturally in a student club because members already ______.",
"o": [
"share a hobby",
"know each other",
"study together",
"live nearby"
],
"e": "الفقرة 2: «Because members already share a hobby, conversations start naturally» ← لأن الأعضاء عندهم نفس الهواية."
},
{
"q": "Which club does the writer NOT mention?",
"o": [
"art",
"sports",
"volunteering",
"photography"
],
"e": "الفقرة 2 ذكرت «clubs for sports, volunteering, photography» — نادي الفن (art) ما انذكر."
},
{
"q": "What does the underlined word \"gradually\" in paragraph 2 mean?",
"o": [
"slowly",
"suddenly",
"rarely",
"easily"
],
"e": "«they gradually get to know each other» = يتعرفون على بعض شوي شوي مع الوقت ← slowly."
},
{
"q": "What does the underlined word \"encourage\" in paragraph 3 mean?",
"o": [
"advise",
"prevent",
"force",
"blame"
],
"e": "«Experts encourage these students to begin with small steps» = الخبراء ينصحونهم ويشجعونهم يبدون بخطوات صغيرة ← advise."
},
{
"q": "The writer says that shy students can arrive at class ______.",
"o": [
"a few minutes early",
"right on time",
"with a friend",
"after the break"
],
"e": "الفقرة 3: «They can arrive at class a few minutes early and say hello to the person sitting next to them» ← يجون قبل المحاضرة بدقايق ويسلّمون على اللي جنبهم."
},
{
"q": "What does the underlined word \"he\" in paragraph 3 refer to?",
"o": [
"Faisal's classmate",
"Faisal himself",
"Faisal's teacher",
"an expert"
],
"e": "فيصل قال: «Then I started asking the student next to me about our assignments. Now he is my closest friend» ← he = الطالب اللي كان جنبه في الفصل (زميله)."
},
{
"q": "The writer gives the example of Faisal to show that ______.",
"o": [
"small steps can work",
"clubs are not useful",
"study groups are better",
"teachers can help"
],
"e": "الفقرة 3: بعد ما ذكر الخطوات الصغيرة قال «Faisal, a second-year student, says that this worked for him» ← بدأ بسؤال بسيط وصار صاحبه الأقرب."
},
{
"q": "The writer says that when a friendship does not grow quickly, students should ______.",
"o": [
"be patient",
"give up",
"change clubs",
"tell their families"
],
"e": "الفقرة 4: «this is not a reason to give up» و«some patience can turn a group of strangers into friends for life» ← يصبرون وما يستسلمون."
},
{
"q": "What is the best title for the passage?",
"o": [
"Making Friends in Your First Year",
"Why Shy Students Leave University",
"The Best Clubs at University",
"How to Study for Exams in Groups"
],
"e": "القطعة كلها عن طرق تكوين صداقات في أول سنة بالجامعة (الأندية، مجموعات المذاكرة، خطوات صغيرة للخجولين، الصبر)."
}
]
},
{
"n": 7,
"k": 5,
"title": "Collecting Things",
"text": [
"1. Collecting is one of the oldest and most common hobbies in the world. People collect stamps, coins, old cameras, football shirts, and even pens from hotels they have stayed in. What makes this hobby so popular is that almost anyone can start _it_. You do not need special skills or expensive equipment, and you can begin at any age with only a few items.",
"2. People collect things for different reasons. For some, the hobby is a way to relax. Searching for a new item and organising a collection can help them forget the pressures of work or study. For others, collecting is a way to learn. A person who collects coins, for example, often reads about the history of the countries that produced them. Collecting can also be social. Collectors meet at clubs, markets and online groups, where they _exchange_ items and share advice with people who have the same interest.",
"3. Some collections become surprisingly valuable. A stamp that cost very little when it was printed may be worth a great deal today if only a few copies still exist. However, most experts say that people should not start collecting only to make money. The value of an item can rise or fall, and it is rarely possible to predict which objects will become popular in the future. In their opinion, the real reward of collecting is the enjoyment it brings.",
"4. Although collecting has many benefits, it can also cause problems. Some collectors spend more money than they can afford, while others keep so many objects that their homes become full and untidy. To avoid this, experts suggest setting a monthly budget and deciding on a clear theme, such as coins from one region or books by one writer. This keeps the collection _manageable_ and the hobby enjoyable."
],
"qs": [
{
"q": "The writer says that to start collecting, you only need ______.",
"o": [
"a few items",
"special skills",
"expensive equipment",
"a lot of money"
],
"e": "الفقرة 1: «You do not need special skills or expensive equipment, and you can begin at any age with only a few items»."
},
{
"q": "What does the underlined word \"it\" in paragraph 1 refer to?",
"o": [
"the hobby",
"the equipment",
"a hotel",
"a football shirt"
],
"e": "«What makes this hobby so popular is that almost anyone can start it» ← it = هواية الجمع."
},
{
"q": "Which item does the writer NOT mention?",
"o": [
"toys",
"stamps",
"football shirts",
"old cameras"
],
"e": "الفقرة 1 ذكرت «stamps, coins, old cameras, football shirts, and even pens» — الألعاب (toys) ما انذكرت."
},
{
"q": "A person who collects coins often reads about ______.",
"o": [
"the history of countries",
"famous collectors",
"coin prices",
"making money"
],
"e": "الفقرة 2: «A person who collects coins, for example, often reads about the history of the countries that produced them»."
},
{
"q": "What does the underlined word \"exchange\" in paragraph 2 mean?",
"o": [
"swap",
"throw away",
"repair",
"hide"
],
"e": "«they exchange items» = يتبادلون القطع، يعطي قطعة وياخذ بدالها ← swap."
},
{
"q": "The writer gives the example of a stamp to show that some collections can become ______.",
"o": [
"very valuable",
"very cheap",
"easy to find",
"hard to sell"
],
"e": "الفقرة 3 تبدأ: «Some collections become surprisingly valuable» وبعدها مثال الطابع اللي صار يسوى كثير."
},
{
"q": "Experts say people should not collect only to make money because the value of an item can ______.",
"o": [
"rise or fall",
"never change",
"only rise",
"stay low"
],
"e": "الفقرة 3: «The value of an item can rise or fall, and it is rarely possible to predict which objects will become popular»."
},
{
"q": "Which problem of collecting does the writer mention?",
"o": [
"untidy homes",
"lost friends",
"broken items",
"missed classes"
],
"e": "الفقرة 4: «others keep so many objects that their homes become full and untidy»."
},
{
"q": "What does the underlined word \"manageable\" in paragraph 4 mean?",
"o": [
"easy to control",
"very expensive",
"very large",
"boring"
],
"e": "الميزانية والموضوع الواضح يخلون المجموعة «manageable» = سهل التحكم فيها وما تكبر زيادة ← easy to control."
},
{
"q": "What is the best title for the passage?",
"o": [
"Collecting: An Enjoyable Hobby That Needs a Plan",
"Collecting: The Fastest Way to Make Money",
"Why Only Rich People Can Collect Things",
"Stamps: The Only Items Worth Collecting"
],
"e": "القطعة تذكر فوائد الجمع (الاسترخاء، التعلم، الناس)، وبعدين تنبّه على المشاكل وتنصح بميزانية وموضوع واضح ← فأفضل عنوان: Collecting: An Enjoyable Hobby That Needs a Plan"
}
]
},
{
"n": 8,
"k": 6,
"title": "Learning a Foreign Language",
"text": [
"1. In today's connected world, more and more people are learning a foreign language. Some learn for work, others for travel or study abroad, and some simply enjoy the challenge. Although learning a language takes time and effort, most people who do it say that the benefits are worth it.",
"2. The most obvious advantage is a practical one. Many companies prefer to hire employees who can communicate with customers and partners in other countries, so a second language can open the door to better jobs. A new language also helps people understand other cultures. When travellers can read signs, order food and chat with local people, their trip becomes much richer. In addition, some research suggests that learning a language can improve concentration and problem-solving skills, even for older adults.",
"3. So what is the best way to learn? Most teachers agree that regular practice is more _effective_ than long but rare study sessions. Spending twenty minutes a day with the language is usually better than studying for three hours once a week. Learners can watch films with subtitles, listen to podcasts on the way to university, or use apps that turn lessons into games. Another popular method is finding a language partner: someone who speaks the language well and wants to learn yours. _They_ can meet online and correct each other's mistakes.",
"4. Many learners, however, are afraid of making mistakes, so they avoid speaking. This is one of the biggest _obstacles_ to progress. Mistakes are a normal part of learning, and people who speak often, even with errors, usually improve faster than those who wait until they feel perfect. As one teacher puts it, \"Nobody learns to swim without getting wet.\" Learners should therefore be brave and use every opportunity to practise the language they are studying."
],
"qs": [
{
"q": "According to the writer, most people who learn a foreign language say that the benefits are ______.",
"o": [
"worth it",
"very small",
"only for work",
"hard to see"
],
"e": "الفقرة 1: «Although learning a language takes time and effort, most people who do it say that the benefits are worth it»."
},
{
"q": "A second language can help people get better jobs because many companies want employees who can ______.",
"o": [
"talk to foreign customers",
"work long hours",
"study abroad",
"teach languages"
],
"e": "الفقرة 2: «Many companies prefer to hire employees who can communicate with customers and partners in other countries»."
},
{
"q": "Which benefit of learning a language does the writer NOT mention?",
"o": [
"saving money",
"understanding cultures",
"better jobs",
"better concentration"
],
"e": "الفقرة 2 ذكرت الوظائف الأفضل وفهم الثقافات و«improve concentration»، أما توفير الفلوس ما انذكر."
},
{
"q": "According to the writer, which way of studying is usually better?",
"o": [
"20 minutes a day",
"3 hours once a week",
"one long session",
"only before exams"
],
"e": "الفقرة 3: «Spending twenty minutes a day with the language is usually better than studying for three hours once a week»."
},
{
"q": "What does the underlined word \"effective\" in paragraph 3 mean?",
"o": [
"successful",
"expensive",
"boring",
"difficult"
],
"e": "«regular practice is more effective» = التدريب المنتظم يجيب نتيجة أفضل وأنجح ← successful."
},
{
"q": "What does the underlined word \"They\" in paragraph 3 refer to?",
"o": [
"learner and partner",
"teachers and students",
"apps and games",
"films and podcasts"
],
"e": "قبلها: «finding a language partner: someone who speaks the language well and wants to learn yours. They can meet online» ← They = المتعلم وشريكه في اللغة."
},
{
"q": "Many learners avoid speaking because they are afraid of ______.",
"o": [
"making mistakes",
"their teachers",
"using apps",
"other cultures"
],
"e": "الفقرة 4: «Many learners, however, are afraid of making mistakes, so they avoid speaking»."
},
{
"q": "What does the underlined word \"obstacles\" in paragraph 4 mean?",
"o": [
"difficulties",
"methods",
"chances",
"rewards"
],
"e": "الخوف من الغلط وعدم الكلام «one of the biggest obstacles to progress» = من أكبر العوائق اللي توقف التقدم ← difficulties."
},
{
"q": "The writer uses the words \"Nobody learns to swim without getting wet\" to show that mistakes are ______.",
"o": [
"normal",
"dangerous",
"rare",
"avoidable"
],
"e": "الفقرة 4: الجملة جات بعد «Mistakes are a normal part of learning» ← مثل ما ما تتعلم السباحة بدون ما تتبلل، ما تتعلم لغة بدون أغلاط."
},
{
"q": "What is the best title for the passage?",
"o": [
"Why and how to learn a foreign language",
"The best apps for learning languages",
"Finding a job in another country",
"Learning to swim as an adult"
],
"e": "القطعة تذكر فوائد تعلم اللغة (الفقرة 2) وطريقة تعلمها (الفقرة 3 و4)."
}
]
},
{
"n": 9,
"k": 7,
"title": "Online Classes or Classrooms?",
"text": [
"1. Not long ago, studying at university meant sitting in a lecture hall at a fixed time. Today, a growing number of students take some or all of their courses online. They watch recorded lectures, join live discussions and submit assignments from home. This change has started a debate: some people believe online learning is the future of education, while others think traditional classrooms are still the better choice.",
"2. Supporters of online classes point to their flexibility. Students can study at any time and in any place, which is especially _convenient_ for people who have a job or children to look after. Online courses can also be cheaper, because students save money on transport and do not need to rent a room near the campus. Some shy students say they feel more comfortable asking questions in a chat box than raising their hand in front of a large class.",
"3. On the other hand, online learning has clear disadvantages. Studying at home requires a lot of self-discipline, and many students find it hard to stay focused when their phones, the television or family members are nearby. Technical problems, such as a weak internet connection, can also interrupt lessons. In addition, students who learn only online miss the chance to meet classmates face to face, and for many young people these friendships are one of the most valuable parts of university life.",
"4. So which is better? The honest answer is that it _depends on_ the student. Learners who are organised and good at managing their time often do well online, while those who need more support and structure usually prefer a classroom. For this reason, many universities now offer \"blended\" courses, which combine online lessons with regular meetings on campus. This allows students to enjoy the advantages of both methods and choose what suits _them_ best."
],
"qs": [
{
"q": "Students who take courses online submit their assignments ______.",
"o": [
"from home",
"on campus",
"in the library",
"after exams"
],
"e": "الفقرة 1: «They watch recorded lectures, join live discussions and submit assignments from home»."
},
{
"q": "According to their supporters, what is the main advantage of online classes?",
"o": [
"flexibility",
"friendships",
"self-discipline",
"fast internet"
],
"e": "الفقرة 2: «Supporters of online classes point to their flexibility» ← المرونة."
},
{
"q": "What does the underlined word \"convenient\" in paragraph 2 mean?",
"o": [
"suitable",
"expensive",
"boring",
"dangerous"
],
"e": "الدراسة في أي وقت ومكان «convenient» للي عنده دوام أو أطفال = مريحة ومناسبة لظروفه ← suitable."
},
{
"q": "Online courses can be cheaper because students save money on ______.",
"o": [
"transport and rent",
"books and laptops",
"food and drinks",
"fees and exams"
],
"e": "الفقرة 2: «students save money on transport and do not need to rent a room near the campus»."
},
{
"q": "Some shy students feel more comfortable asking questions in ______.",
"o": [
"a chat box",
"a large class",
"the library",
"small groups"
],
"e": "الفقرة 2: «Some shy students say they feel more comfortable asking questions in a chat box than raising their hand»."
},
{
"q": "Which disadvantage of online learning does the writer NOT mention?",
"o": [
"expensive computers",
"technical problems",
"distractions at home",
"missing classmates"
],
"e": "الفقرة 3 ذكرت الملهيات (الجوال والتلفزيون والأهل)، و«Technical problems»، و«miss the chance to meet classmates» — غلاء الأجهزة ما انذكر."
},
{
"q": "What do the underlined words \"depends on\" in paragraph 4 mean?",
"o": [
"changes according to",
"is the same for",
"is bad for",
"has nothing to do with"
],
"e": "«it depends on the student» = الجواب يختلف حسب الطالب، بعدها الكاتب وضّح مين ينفع له أونلاين ومين ينفع له الفصل ← changes according to."
},
{
"q": "Which students often do well online?",
"o": [
"organised students",
"students needing support",
"students who prefer classrooms",
"students near the campus"
],
"e": "الفقرة 4: «Learners who are organised and good at managing their time often do well online»."
},
{
"q": "What does the underlined word \"them\" in paragraph 4 refer to?",
"o": [
"students",
"universities",
"blended courses",
"regular meetings"
],
"e": "«This allows students to enjoy the advantages of both methods and choose what suits them best» ← them = الطلاب."
},
{
"q": "What is the best title for the passage?",
"o": [
"Online Classes and Classrooms: Pros and Cons",
"Why Online Classes Will Replace Universities",
"Why Classrooms Are Always Better for Everyone",
"Online Classes: The Only Choice for Shy Students"
],
"e": "الكاتب ذكر مميزات الأونلاين (الفقرة 2) وعيوبه (الفقرة 3)، وقال «it depends on the student» ← فأفضل عنوان: Online Classes and Classrooms: Pros and Cons"
}
]
},
{
"n": 10,
"k": 8,
"title": "Fast Food and Our Health",
"text": [
"1. Fast food is part of daily life in many countries, including Saudi Arabia. It is quick, cheap and easy to find, and delivery apps now bring burgers, pizza and fried chicken to our doors in minutes. For busy students and workers, this is very attractive. However, doctors warn that eating fast food too often can seriously _affect_ our health.",
"2. The main problem is what fast food contains. Most meals are high in salt, sugar and fat, which make the food taste good but can cause problems if we eat them regularly. People who eat fast food several times a week are more likely to become overweight and to develop heart disease or diabetes later in life. In addition, these meals usually contain few vitamins and little fibre, so they fill the stomach without giving the body what it really needs. Large soft drinks, which are often included in meal deals, add even more sugar.",
"3. If fast food is so unhealthy, why do people eat so much of it? One reason is time: many people finish work or classes late and feel too tired to cook. Another reason is price, because a fast food meal is sometimes cheaper than a healthy one. Advertising also plays an important role. Fast food companies spend huge amounts of money on adverts, and many of _them_ are designed to attract children and teenagers.",
"4. The good news is that we do not have to give up fast food completely. Experts suggest treating it as an _occasional_ meal rather than a daily habit. When we do order, we can choose grilled chicken instead of fried, a salad instead of fries, and water instead of soda. Cooking simple meals at home, even two or three times a week, is another good idea. Home-made food is usually healthier, and it is often cheaper too."
],
"qs": [
{
"q": "According to paragraph 1, delivery apps bring fast food to our doors ______.",
"o": [
"in minutes",
"in hours",
"for free",
"once a day"
],
"e": "الفقرة 1: «delivery apps now bring burgers, pizza and fried chicken to our doors in minutes»."
},
{
"q": "What does the underlined word \"affect\" in paragraph 1 mean?",
"o": [
"change",
"protect",
"check",
"forget"
],
"e": "«can seriously affect our health» = يأثّر على صحتنا ويغيّرها تأثير كبير ← change."
},
{
"q": "According to the writer, salt, sugar and fat make the food ______.",
"o": [
"taste good",
"healthier",
"cheaper",
"last longer"
],
"e": "الفقرة 2: «salt, sugar and fat, which make the food taste good but can cause problems»."
},
{
"q": "Which health problem does the writer NOT mention?",
"o": [
"poor eyesight",
"heart disease",
"diabetes",
"becoming overweight"
],
"e": "الفقرة 2 ذكرت «become overweight and to develop heart disease or diabetes» — ضعف النظر ما انذكر."
},
{
"q": "Fast food fills the stomach without giving the body what it needs because it contains few ______.",
"o": [
"vitamins",
"fats",
"sugars",
"salts"
],
"e": "الفقرة 2: «these meals usually contain few vitamins and little fibre, so they fill the stomach without giving the body what it really needs». (الملح والسكر والدهون فيها كثير مو قليل.)"
},
{
"q": "How many reasons does the writer give in paragraph 3 for why people eat so much fast food?",
"o": [
"three",
"two",
"four",
"five"
],
"e": "الفقرة 3 فيها ثلاث أسباب: الوقت «One reason is time»، والسعر «Another reason is price»، والإعلانات «Advertising also plays an important role»."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"adverts",
"fast food companies",
"children and teenagers",
"healthy meals"
],
"e": "«Fast food companies spend huge amounts of money on adverts, and many of them are designed to attract children» ← them = الإعلانات."
},
{
"q": "What does the underlined word \"occasional\" in paragraph 4 mean?",
"o": [
"happening sometimes",
"happening daily",
"very large",
"very cheap"
],
"e": "«an occasional meal rather than a daily habit» = وجبة بين فترة وفترة مو كل يوم ← happening sometimes."
},
{
"q": "According to paragraph 4, home-made food is usually ______.",
"o": [
"healthier and cheaper",
"healthier but costly",
"cheaper but unhealthy",
"quicker to make"
],
"e": "الفقرة 4: «Home-made food is usually healthier, and it is often cheaper too»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Fast food: why we eat it and how to eat less",
"The long history of fast food restaurants",
"Delivery apps and how they work in Saudi Arabia",
"How to cook a healthy meal at home"
],
"e": "القطعة عن أضرار الوجبات السريعة، وليش ناكلها كثير، وكيف نقلل منها."
}
]
},
{
"n": 11,
"k": 9,
"title": "Organic Food",
"text": [
"1. Walk into almost any large supermarket today and you will probably find a section for organic food. Organic fruit, vegetables, meat and dairy products are produced without most artificial chemicals. Organic farmers do not use chemical sprays to kill insects or weeds, and their animals are not given medicines unless they are really ill. Instead, farmers use natural methods, such as moving crops to different fields each year to keep the soil healthy.",
"2. Many shoppers choose organic products because they believe these products are healthier. Some studies suggest that organic fruit and vegetables contain slightly more of certain nutrients, although scientists still disagree about how important this difference is. Many people also buy organic food because it is better for the environment. Since fewer chemicals are used, the soil, rivers and wild animals near organic farms are less likely to be _harmed_.",
"3. However, organic food has one major disadvantage: its price. Organic products can cost from 20 to 100 percent more than ordinary ones. There are several reasons for this. Organic farming needs more workers, because jobs like removing weeds are often done by hand. Organic farms also usually produce smaller harvests, so the _supply_ is lower, and when something is limited, its price tends to rise.",
"4. So, is organic food worth the extra money? Experts have different opinions, but most of them agree on one point: eating plenty of fruit and vegetables matters more than whether _they_ are organic or not. In other words, a person who eats ordinary vegetables every day is doing much better than someone who rarely eats vegetables at all. For families with a limited budget, some experts recommend a simple approach: buy organic versions only of the foods you eat most often, and choose ordinary products for everything else."
],
"qs": [
{
"q": "What do organic farmers use instead of chemicals?",
"o": [
"natural methods",
"medicines",
"more machines",
"stronger sprays"
],
"e": "الفقرة 1: «Instead, farmers use natural methods, such as moving crops to different fields each year»."
},
{
"q": "Why do organic farmers move crops to different fields each year?",
"o": [
"to keep the soil healthy",
"to dry the soil",
"to save water",
"to attract buyers"
],
"e": "الفقرة 1: «moving crops to different fields each year to keep the soil healthy»."
},
{
"q": "Scientists still disagree about how important the difference in ______ is.",
"o": [
"nutrients",
"prices",
"harvests",
"chemicals"
],
"e": "الفقرة 2: «organic fruit and vegetables contain slightly more of certain nutrients, although scientists still disagree about how important this difference is» ← الفرق في العناصر الغذائية."
},
{
"q": "What does the underlined word \"harmed\" in paragraph 2 mean?",
"o": [
"damaged",
"helped",
"cleaned",
"moved"
],
"e": "«are less likely to be harmed» = احتمال إنها تتضرر أقل ← damaged."
},
{
"q": "According to the writer, organic products can cost ______ more than ordinary ones.",
"o": [
"20 to 100 percent",
"exactly 20 percent",
"100 to 200 percent",
"less than 10 percent"
],
"e": "الفقرة 3: «Organic products can cost from 20 to 100 percent more than ordinary ones»."
},
{
"q": "Organic farming needs more workers because jobs like removing weeds are often done ______.",
"o": [
"by hand",
"by machine",
"at night",
"by animals"
],
"e": "الفقرة 3: «Organic farming needs more workers, because jobs like removing weeds are often done by hand»."
},
{
"q": "What does the underlined word \"supply\" in paragraph 3 mean?",
"o": [
"the amount available",
"the price",
"the number of buyers",
"the taste"
],
"e": "المزارع تنتج محصول أقل «so the supply is lower» = الكمية المتوفرة أقل ← the amount available."
},
{
"q": "What does the underlined word \"they\" in paragraph 4 refer to?",
"o": [
"fruit and vegetables",
"the experts' opinions",
"families on a budget",
"ordinary products"
],
"e": "«eating plenty of fruit and vegetables matters more than whether they are organic or not» ← they = الفواكه والخضار."
},
{
"q": "Some experts tell families with a limited budget to buy organic versions only of ______.",
"o": [
"the foods they eat most",
"the cheapest foods",
"meat and dairy",
"imported foods"
],
"e": "الفقرة 4: «buy organic versions only of the foods you eat most often, and choose ordinary products for everything else»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Organic Food: Benefits and High Prices",
"Why Organic Food Is Always Much Healthier",
"Why Organic Farming Is Bad for the Environment",
"Why Supermarkets Should Stop Selling Ordinary Food"
],
"e": "القطعة ذكرت فوائد الأغذية العضوية (الفقرة 2) وغلاها (الفقرة 3)، ونصائح للي ميزانيته محدودة (الفقرة 4) ← فأفضل عنوان: Organic Food: Benefits and High Prices"
}
]
},
{
"n": 12,
"k": 10,
"title": "Celebrating Eid",
"text": [
"1. Eid is one of the happiest times of the year for Muslims around the world, and in Saudi Arabia it is a special time for families. There are two Eids every year. Eid al-Fitr comes at the end of Ramadan, the month of fasting, while Eid al-Adha comes during the season of Hajj. Although the two celebrations are different in some ways, both bring people together and fill the streets with a joyful atmosphere.",
"2. On the morning of Eid, people wake up early, put on new clothes and go to the mosque or to large open areas for the Eid prayer. Afterwards, they greet each other with phrases such as \"Eid Mubarak\" and begin visiting relatives. In many families, everyone gathers at the house of the grandparents, because showing respect to older members of the family is an important value. Children especially look forward to this day, since adults give _them_ money or small gifts known as \"Eidiya\".",
"3. Food plays a central role in the celebration. Hosts serve Arabic coffee, dates and sweets to every guest, and large meals of traditional dishes such as kabsa are prepared for lunch. During Eid al-Adha, many families also sacrifice a sheep and _distribute_ the meat among relatives, neighbours and people in need. This custom reminds everyone that Eid is not only about personal happiness but also about sharing with others.",
"4. In recent years, Eid celebrations in Saudi cities have become even more varied. Many cities organise fireworks, festivals and shows for children, and parks, malls and seafronts become extremely _crowded_ in the evenings. Some families now prefer to travel during the Eid holiday, either inside the Kingdom or abroad. However, for most people, the heart of Eid has not changed: it is still about spending time with the people they love."
],
"qs": [
{
"q": "According to the writer, Eid al-Fitr comes at ______.",
"o": [
"the end of Ramadan",
"the start of Ramadan",
"the end of summer",
"the start of the year"
],
"e": "الفقرة 1: «Eid al-Fitr comes at the end of Ramadan». أما موسم الحج فهو لعيد الأضحى."
},
{
"q": "Where do people go for the Eid prayer?",
"o": [
"the mosque or open areas",
"the grandparents' house",
"parks and malls",
"the seafront"
],
"e": "الفقرة 2: «go to the mosque or to large open areas for the Eid prayer»."
},
{
"q": "Many families gather at the grandparents' house because showing respect to ______ is an important value.",
"o": [
"older family members",
"neighbours",
"young children",
"new visitors"
],
"e": "الفقرة 2: «because showing respect to older members of the family is an important value»."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"children",
"adults",
"relatives",
"grandparents"
],
"e": "«Children especially look forward to this day, since adults give them money» ← them = الأطفال."
},
{
"q": "Which food does the writer NOT mention?",
"o": [
"soup",
"dates",
"sweets",
"kabsa"
],
"e": "الفقرة 3 ذكرت «Arabic coffee, dates and sweets» و«kabsa» — الشوربة (soup) ما انذكرت."
},
{
"q": "What does the underlined word \"distribute\" in paragraph 3 mean?",
"o": [
"give out",
"sell",
"cook",
"keep"
],
"e": "«distribute the meat among relatives, neighbours and people in need» = يوزّعون اللحم على الأقارب والجيران والمحتاجين ← give out."
},
{
"q": "The custom of sacrificing a sheep reminds everyone that Eid is also about ______.",
"o": [
"sharing with others",
"travelling abroad",
"eating large meals",
"wearing new clothes"
],
"e": "الفقرة 3: «This custom reminds everyone that Eid is not only about personal happiness but also about sharing with others»."
},
{
"q": "What does the underlined word \"crowded\" in paragraph 4 mean?",
"o": [
"full of people",
"empty",
"quiet",
"closed"
],
"e": "«parks, malls and seafronts become extremely crowded» لأن الناس كلها تطلع ← full of people (زحمة)."
},
{
"q": "According to the writer, the heart of Eid is still about ______.",
"o": [
"time with loved ones",
"travelling abroad",
"watching fireworks",
"going shopping"
],
"e": "الفقرة 4: «the heart of Eid has not changed: it is still about spending time with the people they love»."
},
{
"q": "What is the best title for the passage?",
"o": [
"How people celebrate Eid in Saudi Arabia",
"The history of Hajj in Saudi Arabia",
"Travelling abroad during the holidays",
"How to cook traditional Saudi dishes"
],
"e": "القطعة كلها عن احتفال العيد في السعودية: الصلاة والزيارات والعيدية والأكل والفعاليات."
}
]
},
{
"n": 13,
"k": 11,
"title": "Travelling on a Small Budget",
"text": [
"1. Many people dream of travelling but believe they cannot afford it. They imagine expensive flights, luxury hotels and costly restaurants. In reality, it is possible to visit interesting places without spending a fortune. The secret is careful planning, and travellers who prepare well can often spend much less than others on a similar trip.",
"2. The first and most important step is choosing when to travel. Flights and hotels are usually most expensive during school holidays and public holidays, when many families travel at the same time. Travelling in the quieter months of the year can reduce costs a lot. It is also wise to book tickets early, because prices often _increase_ as the travel date gets closer. Many travellers use price-comparison websites and set alerts so that they know when a ticket becomes cheaper.",
"3. Accommodation is usually the second biggest cost of a trip. Instead of staying in an expensive hotel, travellers can choose a small guesthouse or rent an apartment with friends and share the cost. Apartments have another advantage: most of them have a kitchen. Preparing breakfast or a simple dinner is much cheaper than eating every meal in a restaurant, and visiting local supermarkets can be an interesting experience in itself.",
"4. Finally, travellers should look for activities that cost little or nothing. Many cities have free museums, public parks and lively markets, and walking around a new neighbourhood is often the best way to discover it. Using public transport instead of taxis also saves money. Buses and trains are usually cheap and _reliable_, and _they_ allow visitors to see how local people really live. With a little research, a small budget does not have to mean a boring holiday."
],
"qs": [
{
"q": "According to the writer, the secret of travelling on a small budget is ______.",
"o": [
"careful planning",
"luxury hotels",
"travelling alone",
"eating out"
],
"e": "الفقرة 1: «The secret is careful planning»."
},
{
"q": "Flights and hotels are most expensive during school holidays because many families ______.",
"o": [
"travel at the same time",
"stay at home",
"book early",
"rent apartments"
],
"e": "الفقرة 2: «during school holidays and public holidays, when many families travel at the same time»."
},
{
"q": "What does the underlined word \"increase\" in paragraph 2 mean?",
"o": [
"go up",
"go down",
"stay the same",
"disappear"
],
"e": "«prices often increase as the travel date gets closer» = الأسعار ترتفع كل ما قرب موعد السفر ← go up."
},
{
"q": "Many travellers set alerts so that they know when a ticket becomes ______.",
"o": [
"cheaper",
"sold out",
"more expensive",
"cancelled"
],
"e": "الفقرة 2: «set alerts so that they know when a ticket becomes cheaper»."
},
{
"q": "According to the writer, accommodation is usually ______ of a trip.",
"o": [
"the second biggest cost",
"the biggest cost",
"the smallest cost",
"the cheapest part"
],
"e": "الفقرة 3: «Accommodation is usually the second biggest cost of a trip»."
},
{
"q": "What advantage of apartments does the writer mention?",
"o": [
"a kitchen",
"free tours",
"a swimming pool",
"free breakfast"
],
"e": "الفقرة 3: «Apartments have another advantage: most of them have a kitchen»."
},
{
"q": "Which cheap activity does the writer NOT mention?",
"o": [
"going to the beach",
"visiting free museums",
"walking around",
"visiting markets"
],
"e": "الفقرة 4 ذكرت «free museums, public parks and lively markets» والمشي في حي جديد — البحر (the beach) ما انذكر."
},
{
"q": "What does the underlined word \"reliable\" in paragraph 4 mean?",
"o": [
"trustworthy",
"dangerous",
"expensive",
"slow"
],
"e": "«Buses and trains are usually cheap and reliable» = تقدر تعتمد عليها وتوصلك في وقتها ← trustworthy."
},
{
"q": "What does the underlined word \"they\" in paragraph 4 refer to?",
"o": [
"buses and trains",
"visitors",
"taxis",
"local people"
],
"e": "«Buses and trains are usually cheap and reliable, and they allow visitors to see how local people really live» ← they = الباصات والقطارات."
},
{
"q": "What is the best title for the passage?",
"o": [
"How to Travel Without Spending a Fortune",
"Why Travelling Is Too Expensive for Students",
"Why Hotels Are Cheaper Than Apartments",
"Taxis: The Best Way to Save Money on Holiday"
],
"e": "الفقرة 1: «it is possible to visit interesting places without spending a fortune. The secret is careful planning»، وباقي القطعة نصائح للتوفير ← فأفضل عنوان: How to Travel Without Spending a Fortune"
}
]
},
{
"n": 14,
"k": 12,
"title": "Spending Time in Nature",
"text": [
"1. Modern life keeps most of us indoors. We study in classrooms, work in offices and spend our free time at home in front of screens. Some researchers believe that people in many countries spend around 90 percent of their time inside buildings or cars. Although this lifestyle is comfortable, a growing amount of research suggests that we are missing something important: regular contact with nature.",
"2. One of the clearest benefits of nature is its effect on our mood. In several studies, people who walked in a park said they felt calmer and more positive than people who walked the same distance along a busy street. Being outdoors also makes us move more. In a garden or a park, we naturally walk, play or ride a bike instead of sitting still. In addition, sunlight helps the body produce vitamin D, which is important for strong bones.",
"3. Nature may even help us think more clearly. Teachers have noticed that students who spend their break outdoors often _concentrate_ better when they return to class. For this reason, some schools in countries such as Denmark and Germany run \"forest schools\", where children spend part of the school day learning outside, whatever the weather. Supporters say that these children become more confident and more curious about the world around _them_.",
"4. The good news is that we do not need to live near mountains or the sea to enjoy these benefits. A study in England found that people who spent at least two hours a week in green places were more likely to say that their health was good. This time does not have to come all at once; it can be _divided_ into short visits. A walk after dinner, a weekend picnic or simply reading under a tree all count. Even looking after a few plants on a balcony can help."
],
"qs": [
{
"q": "According to some researchers, people in many countries spend around ______ of their time inside buildings or cars.",
"o": [
"90 percent",
"50 percent",
"9 percent",
"20 percent"
],
"e": "الفقرة 1: «spend around 90 percent of their time inside buildings or cars»."
},
{
"q": "In the studies in paragraph 2, people who walked in a park felt ______.",
"o": [
"calmer",
"more tired",
"more nervous",
"hungrier"
],
"e": "الفقرة 2: «people who walked in a park said they felt calmer and more positive»."
},
{
"q": "According to the writer, sunlight helps the body ______.",
"o": [
"produce vitamin D",
"stay awake",
"lose weight",
"move faster"
],
"e": "الفقرة 2: «sunlight helps the body produce vitamin D, which is important for strong bones»."
},
{
"q": "Which benefit of nature does the writer NOT mention?",
"o": [
"better sleep",
"a better mood",
"more movement",
"stronger bones"
],
"e": "الفقرة 2 ذكرت المزاج «effect on our mood» والحركة والعظام القوية «strong bones» — النوم ما انذكر."
},
{
"q": "What does the underlined word \"concentrate\" in paragraph 3 mean?",
"o": [
"pay attention",
"relax",
"forget",
"play"
],
"e": "«students who spend their break outdoors often concentrate better» = يركزون أكثر في الدرس ← pay attention."
},
{
"q": "In \"forest schools\", children spend part of the school day ______.",
"o": [
"learning outside",
"planting trees",
"studying online",
"playing sports"
],
"e": "الفقرة 3: «children spend part of the school day learning outside, whatever the weather» ← يعني حتى لو الجو مو حلو."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"the children",
"the supporters",
"the teachers",
"the countries"
],
"e": "«these children become more confident and more curious about the world around them» ← them = الأطفال."
},
{
"q": "The study in England looked at people who spent at least ______ a week in green places.",
"o": [
"two hours",
"ten hours",
"two days",
"thirty minutes"
],
"e": "الفقرة 4: «people who spent at least two hours a week in green places were more likely to say that their health was good»."
},
{
"q": "What does the underlined word \"divided\" in paragraph 4 mean?",
"o": [
"split into parts",
"added together",
"doubled",
"forgotten"
],
"e": "«it can be divided into short visits» = الساعتين ممكن تتقسم على زيارات قصيرة ← split into parts."
},
{
"q": "What is the best title for the passage?",
"o": [
"Why we should spend more time in nature",
"Forest schools in Europe",
"How to grow plants on a balcony",
"Life in big cities"
],
"e": "القطعة كلها عن فوائد الطبيعة (المزاج، الحركة، التركيز، الصحة) وإننا لازم نطلع لها أكثر."
}
]
},
{
"n": 15,
"k": 13,
"title": "The Student Housing Problem",
"text": [
"1. Every year, thousands of young people leave their hometowns and move to big cities to study at university. For many, finding a place to live is the first real challenge, and it often begins weeks before classes start. In most large cities, there is a _shortage_ of student housing, which means there are not enough rooms for everyone who needs one. As a result, rents near the campus have risen quickly.",
"2. Why is student housing so expensive? The main reason is demand. When hundreds of students want to live in the same small area, landlords know that someone will always pay, so they can ask for more money. Another reason is that universities accept more students every year, but new buildings take a long time to build. Because of this, some students have to rent rooms far away from the university. _They_ may spend up to two hours on buses every day, which leaves them tired and with less time to study.",
"3. Students have found different ways to deal with the problem. The most common solution is to share an apartment with one or two roommates, so that they can divide the rent and the bills. Others prefer to live with a relative in the city, although this means following the family's rules. Some universities are also building new dormitories, which are usually cheaper than private apartments and much closer to classes. However, places in these dormitories are limited, so students should apply as early as possible.",
"4. Before signing a contract, students should consider a few things. Location comes first: a cheap room is not a good _bargain_ if it takes two hours to reach the campus. Students should also visit the apartment and check that it is clean, safe and quiet enough for studying. Finally, they should read the contract carefully and ask the landlord about extra costs such as electricity, water and internet. A little research early can save a lot of money and stress."
],
"qs": [
{
"q": "According to the writer, the search for a place to live often begins ______.",
"o": [
"weeks before classes",
"on the first day",
"after the first exam",
"in the final year"
],
"e": "الفقرة 1: «it often begins weeks before classes start» ← البحث عن سكن يبدأ قبل الدراسة بأسابيع."
},
{
"q": "What does the underlined word \"shortage\" in paragraph 1 mean?",
"o": [
"a lack",
"a high price",
"a short visit",
"a large number"
],
"e": "نفس الجملة تشرحها: «which means there are not enough rooms for everyone who needs one» ← shortage = نقص (ما فيه كفاية) = a lack."
},
{
"q": "Landlords can ask for more money because many students want to ______.",
"o": [
"live in the same area",
"live far away",
"pay less rent",
"buy apartments"
],
"e": "الفقرة 2: «When hundreds of students want to live in the same small area, landlords know that someone will always pay» ← الطلب كثير فيرفعون السعر."
},
{
"q": "What does the underlined word \"They\" in paragraph 2 refer to?",
"o": [
"students living far away",
"landlords near the campus",
"universities in the city",
"the new buildings"
],
"e": "الجملة قبلها: «some students have to rent rooms far away from the university. They may spend up to two hours on buses» ← They = الطلاب اللي يسكنون بعيد."
},
{
"q": "According to paragraph 2, long bus journeys every day can leave students ______.",
"o": [
"tired",
"relaxed",
"richer",
"happier"
],
"e": "الفقرة 2: «which leaves them tired and with less time to study»."
},
{
"q": "What is the most common solution to the housing problem?",
"o": [
"sharing an apartment",
"living with a relative",
"moving into a dormitory",
"renting far away"
],
"e": "الفقرة 3: «The most common solution is to share an apartment with one or two roommates» ← الحلول الثانية موجودة بس مو هي الأشهر."
},
{
"q": "Students should apply for a dormitory as early as possible because places are ______.",
"o": [
"limited",
"expensive",
"far away",
"noisy"
],
"e": "الفقرة 3: «places in these dormitories are limited, so students should apply as early as possible» ← الأماكن محدودة."
},
{
"q": "What does the underlined word \"bargain\" in paragraph 4 mean?",
"o": [
"a good deal",
"a long trip",
"a written agreement",
"a quiet place"
],
"e": "«a cheap room is not a good bargain if it takes two hours to reach the campus» ← bargain = صفقة تستاهل فلوسها؛ يعني الرخيص البعيد ما يستاهل."
},
{
"q": "Which extra cost does the writer NOT mention?",
"o": [
"furniture",
"electricity",
"water",
"internet"
],
"e": "الفقرة 4 ذكرت «extra costs such as electricity, water and internet»، والأثاث (furniture) ما انذكر."
},
{
"q": "What is the best title for the passage?",
"o": [
"Finding a place to live as a student",
"Why universities accept more students",
"Life in a university dormitory",
"How landlords choose their tenants"
],
"e": "القطعة كلها عن مشكلة سكن الطلاب: أسبابها، وحلولها، ووش يفكر فيه الطالب قبل ما يختار."
}
]
},
{
"n": 16,
"k": 14,
"title": "Living With a Roommate",
"text": [
"1. For many university students, sharing an apartment or a dormitory room is a normal part of student life. Living with a roommate has clear benefits. It reduces the cost of rent and bills, and it means you are _rarely_ alone when you come home after a long day. However, sharing a small space with another person is not always easy, especially if you have never lived away from your family before. Small problems can quickly grow into big arguments.",
"2. The most common problem is cleaning. Some people are very _tidy_, while others leave their clothes and dirty dishes everywhere. If one roommate always cleans the kitchen and the other never does, the first one will soon feel angry. Noise is another common complaint. One roommate may want to sleep early before a morning class, while the other likes to watch films late at night or invite friends over. Sharing food can also cause trouble, for example when one person eats something that the other bought.",
"3. The best way to avoid these problems is to talk about rules before moving in together. Roommates can make a cleaning schedule, so that each person is responsible for certain jobs on certain days. They can also agree on quiet hours, such as after 11 p.m. on weekdays, and decide whether guests are allowed during the exam period. Money should be discussed too. Some roommates put a fixed amount of money into a shared box every month and use _it_ to buy things they both need, like soap and rice.",
"4. Even with clear rules, problems will sometimes happen. When something bothers you, experts suggest speaking to your roommate calmly and directly instead of complaining to other friends or waiting until you explode. It also helps to remember that your roommate is probably learning to live with someone else for the first time, just like you. With patience and respect, many roommates become close friends who stay in touch long after graduation."
],
"qs": [
{
"q": "According to the writer, living with a roommate reduces the cost of ______.",
"o": [
"rent and bills",
"food and drinks",
"books and classes",
"clothes and furniture"
],
"e": "الفقرة 1: «It reduces the cost of rent and bills»."
},
{
"q": "What does the underlined word \"rarely\" in paragraph 1 mean?",
"o": [
"not often",
"always",
"usually",
"quickly"
],
"e": "«you are rarely alone when you come home» = نادراً تكون لحالك ← not often."
},
{
"q": "The writer says that sharing a small space is especially hard for people who have never lived away from their ______.",
"o": [
"family",
"friends",
"roommates",
"teachers"
],
"e": "الفقرة 1: «especially if you have never lived away from your family before»."
},
{
"q": "What does the underlined word \"tidy\" in paragraph 2 mean?",
"o": [
"neat",
"noisy",
"angry",
"friendly"
],
"e": "الجملة تقارن: «Some people are very tidy, while others leave their clothes and dirty dishes everywhere» ← tidy عكس الفوضوي = مرتّب ونظيف (neat)."
},
{
"q": "Which problem does the writer NOT mention in paragraph 2?",
"o": [
"the internet bill",
"cleaning",
"noise",
"sharing food"
],
"e": "الفقرة 2 ذكرت التنظيف «cleaning» والإزعاج «Noise» والأكل «Sharing food»، وفاتورة الإنترنت ما انذكرت."
},
{
"q": "The writer gives the example of one roommate sleeping early while the other watches films late at night to show a problem with ______.",
"o": [
"noise",
"cleaning",
"money",
"food"
],
"e": "الفقرة 2: «Noise is another common complaint. One roommate may want to sleep early… while the other likes to watch films late at night» ← المثال عن مشكلة الإزعاج."
},
{
"q": "With a cleaning schedule, each person is responsible for ______.",
"o": [
"certain jobs",
"all the jobs",
"the money",
"the guests"
],
"e": "الفقرة 3: «so that each person is responsible for certain jobs on certain days»."
},
{
"q": "What does the underlined word \"it\" in paragraph 3 refer to?",
"o": [
"the shared money",
"the cleaning schedule",
"the exam period",
"quiet hours"
],
"e": "«put a fixed amount of money into a shared box every month and use it to buy things» ← it = الفلوس اللي في الصندوق المشترك."
},
{
"q": "When something bothers you, experts suggest speaking to your roommate ______.",
"o": [
"calmly and directly",
"loudly and angrily",
"through other friends",
"once a month"
],
"e": "الفقرة 4: «experts suggest speaking to your roommate calmly and directly instead of complaining to other friends»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Living With a Roommate: Problems and Solutions",
"Why Students Should Always Live Alone",
"Why Roommates Never Become Friends",
"Cleaning: The Only Problem Roommates Have"
],
"e": "الفقرة 1 تذكر فوائد السكن مع شخص بس تقول «Small problems can quickly grow into big arguments»، والفقرة 2 المشاكل (التنظيف والإزعاج والأكل)، والفقرتين 3 و4 الحلول: «talk about rules before moving in together» والكلام بهدوء ← فأفضل عنوان: Living With a Roommate: Problems and Solutions"
}
]
},
{
"n": 17,
"k": 15,
"title": "Breaking Bad Habits",
"text": [
"1. Almost everyone has at least one bad habit. Some people drink too many sugary drinks, some stay up late scrolling on their phones, and others always leave their work until the last minute. Many of us have tried to stop these habits. However, breaking a habit is often much harder than we expect, because habits happen automatically, without much thinking. The good news is that a few practical steps can make the change easier.",
"2. The first step is to start small. Many people fail because they try to change everything at once. For example, some people who drink five cans of soft drinks a day decide to stop completely overnight. After two or three days, _they_ usually feel tired and give up. It is more realistic to reduce the number _gradually_, perhaps to four cans a day in the first week and three in the second. Small successes make people feel confident and encourage them to continue.",
"3. Another useful idea is to make the bad habit more difficult and the good habit easier. If you waste hours on social media, you can delete the apps from your phone and use them only on your computer. Some people also find it helpful to _replace_ a bad habit with a better one. Instead of checking their phone when they feel bored, for instance, they read a few pages of a book or go for a short walk.",
"4. Finally, be patient with yourself. One well-known study found that it took people an average of 66 days to make a new behaviour automatic, although for some people it took much longer. During this time, you will probably make mistakes. If you fail one day, do not see it as the end; simply start again the next day. It can also help to tell a friend about your goal, because people who share their plans often feel more responsible for keeping them."
],
"qs": [
{
"q": "Which bad habit does the writer NOT mention in paragraph 1?",
"o": [
"eating fast food",
"sugary drinks",
"late-night scrolling",
"last-minute work"
],
"e": "الفقرة 1 ذكرت «drink too many sugary drinks» و«stay up late scrolling on their phones» و«leave their work until the last minute»، والأكل السريع ما انذكر."
},
{
"q": "According to the writer, breaking a habit is hard because habits happen ______.",
"o": [
"automatically",
"rarely",
"slowly",
"on purpose"
],
"e": "الفقرة 1: «because habits happen automatically, without much thinking»."
},
{
"q": "Why do many people fail to break a bad habit?",
"o": [
"changing everything at once",
"starting with small steps",
"telling their friends",
"deleting their apps"
],
"e": "الفقرة 2: «Many people fail because they try to change everything at once»."
},
{
"q": "What does the underlined word \"they\" in paragraph 2 refer to?",
"o": [
"the soft-drink drinkers",
"the small successes",
"the soft-drink cans",
"the first few days"
],
"e": "الجملة قبلها: «some people who drink five cans of soft drinks a day decide to stop completely… After two or three days, they usually feel tired» ← they = الناس اللي يشربون خمس علب."
},
{
"q": "What does the underlined word \"gradually\" in paragraph 2 mean?",
"o": [
"little by little",
"suddenly",
"completely",
"happily"
],
"e": "المثال يوضّح: من خمس علب لأربع ثم ثلاث ← «reduce the number gradually» = شوي شوي."
},
{
"q": "The writer gives the example of deleting social media apps to show how to make a bad habit more ______.",
"o": [
"difficult",
"enjoyable",
"automatic",
"popular"
],
"e": "الفقرة 3: «make the bad habit more difficult… you can delete the apps from your phone» ← المثال يوضّح كيف تصعّب العادة السيئة."
},
{
"q": "What does the underlined word \"replace\" in paragraph 3 mean?",
"o": [
"swap",
"forget",
"repeat",
"hide"
],
"e": "المثال بعدها: بدال ما يمسك الجوال يقرأ كتاب ← «replace a bad habit with a better one» = يحط شي مكان شي (يبدّل)."
},
{
"q": "According to the study in paragraph 4, it took people an average of ______ to make a new behaviour automatic.",
"o": [
"66 days",
"6 days",
"one week",
"66 weeks"
],
"e": "الفقرة 4: «it took people an average of 66 days to make a new behaviour automatic»."
},
{
"q": "Telling a friend about your goal can help because you may feel more ______.",
"o": [
"responsible",
"relaxed",
"bored",
"tired"
],
"e": "الفقرة 4: «because people who share their plans often feel more responsible for keeping them»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Practical steps to break a bad habit",
"Why sugary drinks are dangerous",
"The problem with social media",
"How to make new friends"
],
"e": "القطعة كلها خطوات عملية: «start small» وصعّب العادة السيئة، و«be patient with yourself»."
}
]
},
{
"n": 18,
"k": 16,
"title": "Addicted to Our Phones",
"text": [
"1. Today, it is hard to imagine life without a smartphone. We use our phones to talk to our families, read the news, pay for shopping, find our way around the city and even study for exams. Because phones are so useful, many people carry them everywhere and feel nervous when the battery is low. Some experts believe that certain people have become so _dependent_ on their phones that their behaviour is similar to an addiction.",
"2. Surveys suggest that many people check their phones dozens of times a day, often without a clear reason. Some people reach for their phone the moment they wake up, and the last thing they see before sleeping is a bright screen. This habit can affect our health in several ways. Looking at a screen late at night can make it harder to fall asleep, and staring at small text for hours can make our eyes tired. Heavy phone use has also been linked to stress, because people feel they must answer every message immediately.",
"3. Phones can also affect our relationships. In many homes and cafés, it is common to see a group of friends or family members sitting together while each person looks at their own screen. Although _they_ are in the same place, they are _hardly_ talking to each other. Some people even feel hurt when the person they are speaking to keeps checking messages. Over time, this can make relationships weaker, because real conversations need full attention.",
"4. Fortunately, there are simple ways to take back control. One idea is to turn off notifications for apps that are not important. Another is to create phone-free times, such as during meals or the first hour after waking up. Many phones now show a daily report of screen time, and people are often surprised when they see the total. The aim is not to stop using phones completely, but to use them in a more balanced way."
],
"qs": [
{
"q": "Which use of phones does the writer NOT mention in paragraph 1?",
"o": [
"taking photos",
"reading the news",
"paying for shopping",
"finding our way"
],
"e": "الفقرة 1 ذكرت «read the news, pay for shopping, find our way around the city»، والتصوير ما انذكر."
},
{
"q": "What does the underlined word \"dependent\" in paragraph 1 mean?",
"o": [
"relying on",
"bored with",
"afraid of",
"careless with"
],
"e": "«so dependent on their phones that their behaviour is similar to an addiction» ← dependent on = معتمد عليه لدرجة ما يقدر يستغني عنه (relying on)."
},
{
"q": "Looking at a screen late at night can make it harder to ______.",
"o": [
"fall asleep",
"find our way",
"read the news",
"make calls"
],
"e": "الفقرة 2: «Looking at a screen late at night can make it harder to fall asleep»."
},
{
"q": "Heavy phone use has been linked to stress because people feel they must answer every message ______.",
"o": [
"immediately",
"politely",
"in person",
"at night"
],
"e": "الفقرة 2: «linked to stress, because people feel they must answer every message immediately»."
},
{
"q": "What does the underlined word \"they\" in paragraph 3 refer to?",
"o": [
"the people sitting together",
"the homes and cafés",
"their own screens",
"the messages"
],
"e": "الجملة قبلها: «a group of friends or family members sitting together… Although they are in the same place» ← they = الأصحاب أو الأهل الجالسين مع بعض."
},
{
"q": "What does the underlined word \"hardly\" in paragraph 3 mean?",
"o": [
"almost not",
"very loudly",
"very often",
"happily"
],
"e": "«Although they are in the same place, they are hardly talking» ← مع إنهم مع بعض بالكاد يتكلمون = almost not."
},
{
"q": "Phone use can make relationships weaker because real conversations need ______.",
"o": [
"full attention",
"more phones",
"long messages",
"video calls"
],
"e": "الفقرة 3: «this can make relationships weaker, because real conversations need full attention»."
},
{
"q": "How do people often feel when they see their total screen time?",
"o": [
"surprised",
"bored",
"angry",
"proud"
],
"e": "الفقرة 4: «people are often surprised when they see the total»."
},
{
"q": "According to the writer, the aim is to use phones in a more ______ way.",
"o": [
"balanced",
"frequent",
"expensive",
"secret"
],
"e": "الفقرة 4: «The aim is not to stop using phones completely, but to use them in a more balanced way»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Our Phones: Effects and Solutions",
"The History of the Smartphone",
"Choosing a New Phone",
"Why Phones Are Cheaper Today"
],
"e": "القطعة عن تأثير الجوال على الصحة والعلاقات (الفقرة 2 و3)، وبعدها طرق «to take back control» (الفقرة 4)."
}
]
},
{
"n": 19,
"k": 17,
"title": "Why Sleep Matters",
"text": [
"1. Many university students believe that sleep is a waste of time. During the exam period, especially, they stay up late to study, and at other times they stay awake chatting with friends or watching TV series. They think that sleeping less gives them more hours to get things done. However, a large amount of research shows the opposite: when we do not sleep enough, almost everything we do during the day becomes slower and more difficult.",
"2. Health experts recommend that adults get seven to nine hours of sleep every night, while teenagers need around eight to ten. Many young people, however, sleep much less, particularly on weekdays. After just one short night, people often feel _irritable_ and get angry about small things that would not normally bother them. They also find it harder to concentrate in lectures, and they may make more mistakes in simple tasks. Driving when very tired is especially dangerous, because a sleepy driver reacts more slowly.",
"3. Over a longer period, poor sleep can affect the body as well as the mind. People who regularly sleep too little tend to catch colds more often, because their bodies are less able to fight illness. Some studies also suggest that tired people feel hungrier and choose more sugary food, which can lead to weight gain. In other words, sleep is not a break from a healthy life; it is an important part of _it_.",
"4. The good news is that most people can improve their sleep with a few simple changes. Experts suggest going to bed and getting up at the same time every day, even at weekends, so that the body gets used to a regular pattern. It is also _wise_ to avoid coffee, tea and energy drinks in the late afternoon and evening. Finally, screens should be turned off about an hour before bed, and the bedroom should be dark, quiet and comfortable."
],
"qs": [
{
"q": "Many students sleep less because they think it gives them more ______.",
"o": [
"time",
"energy",
"friends",
"money"
],
"e": "الفقرة 1: «They think that sleeping less gives them more hours to get things done» ← يحسبون إنه يعطيهم وقت أكثر."
},
{
"q": "According to the writer, how much sleep do teenagers need?",
"o": [
"eight to ten hours",
"seven to nine hours",
"less than seven hours",
"about five hours"
],
"e": "الفقرة 2: «while teenagers need around eight to ten» ← (سبع لتسع للكبار مو للمراهقين)."
},
{
"q": "What does the underlined word \"irritable\" in paragraph 2 mean?",
"o": [
"easily annoyed",
"very active",
"calm",
"quiet"
],
"e": "الجملة نفسها توضّحها: «get angry about small things that would not normally bother them» ← irritable = سريع الانزعاج والعصبية."
},
{
"q": "Which problem does the writer NOT mention in paragraph 2?",
"o": [
"headaches",
"poor concentration",
"more mistakes",
"dangerous driving"
],
"e": "الفقرة 2 ذكرت ضعف التركيز «harder to concentrate» والأخطاء «more mistakes in simple tasks» وخطر السواقة «Driving when very tired is especially dangerous»، والصداع ما انذكر."
},
{
"q": "Driving when very tired is especially dangerous because a sleepy driver ______.",
"o": [
"reacts more slowly",
"drives too fast",
"forgets the way",
"uses the phone"
],
"e": "الفقرة 2: «because a sleepy driver reacts more slowly»."
},
{
"q": "People who regularly sleep too little catch colds more often because their bodies are less able to fight ______.",
"o": [
"illness",
"hunger",
"stress",
"sleep"
],
"e": "الفقرة 3: «tend to catch colds more often, because their bodies are less able to fight illness»."
},
{
"q": "According to some studies, tired people feel ______.",
"o": [
"hungrier",
"less hungry",
"more active",
"healthier"
],
"e": "الفقرة 3: «Some studies also suggest that tired people feel hungrier and choose more sugary food»."
},
{
"q": "What does the underlined word \"it\" in paragraph 3 refer to?",
"o": [
"a healthy life",
"sleep",
"the body",
"weight gain"
],
"e": "«sleep is not a break from a healthy life; it is an important part of it» ← النوم جزء مهم من الحياة الصحية، فـ it الثانية = a healthy life."
},
{
"q": "What does the underlined word \"wise\" in paragraph 4 mean?",
"o": [
"sensible",
"difficult",
"not allowed",
"expensive"
],
"e": "«It is also wise to avoid coffee… in the late afternoon» = من الحكمة / فكرة زينة ← sensible."
},
{
"q": "What is the best title for the passage?",
"o": [
"Why we need enough sleep and how to get it",
"How to study all night before an exam",
"The dangers of energy drinks",
"Why students like watching TV series"
],
"e": "القطعة عن أضرار قلة النوم (الفقرة 2 و3) وطرق تحسين النوم (الفقرة 4)."
}
]
},
{
"n": 20,
"k": 18,
"title": "Exercise and Energy",
"text": [
"1. Many people say they are simply too tired to exercise. After a long day at work or university, the last thing they want to do is go for a run; they would rather sit on the sofa and look at their phones. It seems _logical_ that exercise would make a tired person even more tired. Surprisingly, however, research suggests that the opposite is often true: regular physical activity can actually give people more energy.",
"2. How does this happen? When you exercise regularly, your heart and lungs become stronger, so your body can carry oxygen to your muscles more efficiently. As a result, everyday activities such as climbing stairs or carrying shopping bags _require_ less effort. Exercise also has a positive effect on mood. During physical activity, the brain releases chemicals that help people feel happier and more relaxed, which is why many people say they feel fresh after a walk, even if they felt tired before _it_.",
"3. You do not need expensive equipment or a gym membership to be active. Walking, running and cycling are free, and you can do them almost anywhere. In hot weather, some people in Saudi Arabia walk inside shopping malls, while others use the walking paths in their neighbourhood after sunset. At home, simple exercises like push-ups, squats and skipping with a rope can be done in a small space. Even household jobs such as cleaning and gardening count as physical activity.",
"4. The World Health Organization recommends that adults do at least 150 minutes of moderate activity every week. That may sound like a lot, but it is only about 30 minutes a day, five days a week. Beginners can start with ten minutes a day and increase the time slowly. Experts also advise choosing an activity you really enjoy, whether it is football, swimming or walking with a friend. If you enjoy it, you are much more likely to continue for months instead of giving up after a week."
],
"qs": [
{
"q": "What does the underlined word \"logical\" in paragraph 1 mean?",
"o": [
"reasonable",
"funny",
"dangerous",
"impossible"
],
"e": "«It seems logical that exercise would make a tired person even more tired» = يبان منطقي ومعقول ← reasonable."
},
{
"q": "Research suggests that regular physical activity can give people more ______.",
"o": [
"energy",
"stress",
"free time",
"money"
],
"e": "الفقرة 1: «research suggests that the opposite is often true: regular physical activity can actually give people more energy»."
},
{
"q": "When your heart and lungs become stronger, your body can carry ______ to your muscles more efficiently.",
"o": [
"oxygen",
"water",
"sugar",
"vitamins"
],
"e": "الفقرة 2: «your heart and lungs become stronger, so your body can carry oxygen to your muscles more efficiently»."
},
{
"q": "What does the underlined word \"require\" in paragraph 2 mean?",
"o": [
"need",
"give",
"avoid",
"finish"
],
"e": "«everyday activities… require less effort» = تحتاج مجهود أقل ← need."
},
{
"q": "What does the underlined word \"it\" in paragraph 2 refer to?",
"o": [
"a walk",
"the brain",
"the heart",
"mood"
],
"e": "«they feel fresh after a walk, even if they felt tired before it» ← تعبانين قبل المشي ← it = a walk."
},
{
"q": "Which activity does the writer NOT mention in paragraph 3?",
"o": [
"lifting weights",
"push-ups",
"skipping with a rope",
"gardening"
],
"e": "الفقرة 3 ذكرت «push-ups, squats and skipping with a rope» و«cleaning and gardening»، ورفع الأثقال ما انذكر."
},
{
"q": "The writer gives the example of people walking inside shopping malls to show that people can stay active even in ______.",
"o": [
"hot weather",
"cold weather",
"rainy weather",
"snowy weather"
],
"e": "الفقرة 3: «In hot weather, some people in Saudi Arabia walk inside shopping malls» ← حتى مع الحر تقدر تتحرك."
},
{
"q": "According to the World Health Organization, adults should do at least ______ of moderate activity.",
"o": [
"150 minutes a week",
"150 minutes a day",
"50 minutes a week",
"10 minutes a week"
],
"e": "الفقرة 4: «adults do at least 150 minutes of moderate activity every week»."
},
{
"q": "Experts advise choosing an activity you really enjoy because you are more likely to ______.",
"o": [
"continue for months",
"give up quickly",
"spend less money",
"lose weight"
],
"e": "الفقرة 4: «If you enjoy it, you are much more likely to continue for months instead of giving up after a week»."
},
{
"q": "What is the best title for the passage?",
"o": [
"The Surprising Benefits of Regular Exercise",
"Why Tired People Should Never Exercise",
"Exercise: Only Possible in an Expensive Gym",
"Why Housework Is Better Than Sports"
],
"e": "الفقرة 1: «research suggests that the opposite is often true»، والفقرة 2 تشرح فوائد الرياضة المنتظمة (طاقة أكثر ومزاج أحسن)، والفقرتين 3 و4 كيف تبدأ بسهولة ← فأفضل عنوان: The Surprising Benefits of Regular Exercise"
}
]
},
{
"n": 21,
"k": 19,
"title": "Vitamins: Food or Pills?",
"text": [
"1. Vitamins are substances that our bodies need in small amounts to work _properly_. They help us grow, keep our bones and skin healthy, and protect us from illness. In recent years, vitamin pills have become very popular, and pharmacies now sell dozens of types. Many people take a pill every morning because they believe it will make them stronger or give them more energy, even if they already feel healthy.",
"2. However, many doctors question whether healthy people really need these _supplements_. In their view, a balanced diet that includes fruit, vegetables, grains, milk products, and meat or fish usually provides all the vitamins the body needs. For example, oranges and strawberries are rich in vitamin C, carrots contain a substance that the body turns into vitamin A, and eggs and oily fish provide some vitamin D. Food also contains fibre and other useful things that a pill cannot offer.",
"3. On the other hand, some groups of people may benefit from extra vitamins. Pregnant women are often advised to take folic acid, a B vitamin, and older people sometimes need vitamin D, especially if they rarely go outside. Our skin makes vitamin D when it is exposed to sunlight, so people who spend most of the day indoors may not get enough. People who do not eat any animal products may also need vitamin B12, because _it_ is found mainly in meat, fish, eggs and milk. In these cases, a doctor can do a blood test before suggesting the right amount.",
"4. Also, more is not always better. Some vitamins, such as A and D, are stored in the body, so taking large amounts over a long time can be harmful. Vitamin pills can also be expensive, and the money might be better spent on fresh food. Most experts agree that pills should be used to support a good diet, not to replace it. Before taking supplements, it is best to talk to a doctor first."
],
"qs": [
{
"q": "What does the underlined word \"properly\" in paragraph 1 mean?",
"o": [
"correctly",
"slowly",
"rarely",
"quickly"
],
"e": "«our bodies need in small amounts to work properly» = عشان الجسم يشتغل صح وبالشكل المطلوب ← correctly."
},
{
"q": "Many people take a vitamin pill every morning because they believe it will give them more ______.",
"o": [
"energy",
"time",
"sleep",
"money"
],
"e": "الفقرة 1: «because they believe it will make them stronger or give them more energy, even if they already feel healthy»."
},
{
"q": "What does the underlined word \"supplements\" in paragraph 2 mean?",
"o": [
"extra vitamin pills",
"fresh vegetables",
"blood tests",
"pharmacies"
],
"e": "«whether healthy people really need these supplements» ← يقصد حبوب الفيتامين اللي تكلّم عنها في الفقرة 1 = مكمّلات تنأخذ زيادة على الأكل."
},
{
"q": "According to many doctors, a balanced diet usually provides ______.",
"o": [
"enough vitamins",
"too few vitamins",
"harmful vitamins",
"only vitamin C"
],
"e": "الفقرة 2: «a balanced diet… usually provides all the vitamins the body needs»."
},
{
"q": "Which food does the writer NOT mention as a source of vitamins?",
"o": [
"bananas",
"oranges",
"carrots",
"eggs"
],
"e": "الفقرة 2 ذكرت «oranges and strawberries» و«carrots» و«eggs and oily fish»، والموز ما انذكر."
},
{
"q": "According to paragraph 2, what can food offer that a pill cannot?",
"o": [
"fibre",
"vitamin B12",
"folic acid",
"vitamin D"
],
"e": "الفقرة 2: «Food also contains fibre and other useful things that a pill cannot offer»."
},
{
"q": "Our skin makes vitamin D when it is exposed to ______.",
"o": [
"sunlight",
"water",
"cold air",
"fresh food"
],
"e": "الفقرة 3: «Our skin makes vitamin D when it is exposed to sunlight, so people who spend most of the day indoors may not get enough»."
},
{
"q": "What does the underlined word \"it\" in paragraph 3 refer to?",
"o": [
"vitamin B12",
"a blood test",
"folic acid",
"sunlight"
],
"e": "«may also need vitamin B12, because it is found mainly in meat, fish, eggs and milk» ← it = vitamin B12."
},
{
"q": "Taking large amounts of vitamins A and D over a long time can be harmful because they are ______ in the body.",
"o": [
"stored",
"destroyed",
"not needed",
"quickly lost"
],
"e": "الفقرة 4: «Some vitamins, such as A and D, are stored in the body, so taking large amounts over a long time can be harmful»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Vitamins: Food or Pills?",
"Why Everyone Needs Vitamin Pills Every Day",
"Vitamin Pills: Always Dangerous",
"Fresh Food: Too Expensive for Most Families"
],
"e": "الفقرة 2: الأكل المتوازن «usually provides all the vitamins the body needs»، والفقرة 3: «some groups of people may benefit from extra vitamins» ← فأفضل عنوان: Vitamins: Food or Pills?"
}
]
},
{
"n": 22,
"k": 20,
"title": "Loneliness in Older People",
"text": [
"1. Loneliness is becoming a serious problem in many parts of the world, and older people are among those most at risk. As people age, their children often move to other cities for work or study, and old friends may become ill or pass away. Retirement can also take away the daily contact that people used to have with their colleagues. As a result, many older people spend long hours alone at home, and some may go several days without a real conversation.",
"2. Loneliness is more than a sad feeling. Some researchers have compared its effect on health to that of smoking around fifteen cigarettes a day. Lonely older people are more likely to suffer from heart disease and poor sleep, and they often lose interest in cooking healthy meals or going for walks. Doctors in some countries report that lonely patients visit _them_ more often, not always because they are ill, but because the visit gives them a chance to talk to someone.",
"3. Many communities are now looking for ways to keep older people _connected_. Some neighbourhood centres organise weekly activities, such as reading groups, light exercise classes and shared meals. In a few countries, some universities run home-share programmes: a student lives with an older person for a very low rent and, in return, spends time with them and helps with jobs around the house. Both sides benefit, because the student saves money and the older person enjoys company and feels safer.",
"4. There are also small things that each of us can do. We can call our grandparents regularly instead of only on special occasions, visit an elderly neighbour, or show an older relative how to make video calls so that they can see family members who live far away. These actions take little time, but they can make a huge difference to someone's day. After all, most of us will be old one day, and we will also hope that someone remembers to _check on_ us."
],
"qs": [
{
"q": "Which reason for loneliness does the writer NOT mention in paragraph 1?",
"o": [
"moving house",
"children moving away",
"friends' illness",
"retirement"
],
"e": "الفقرة 1 ذكرت «their children often move to other cities» و«old friends may become ill or pass away» و«Retirement»، والانتقال لبيت جديد ما انذكر."
},
{
"q": "According to the writer, retirement can take away people's daily contact with their ______.",
"o": [
"colleagues",
"children",
"neighbours",
"doctors"
],
"e": "الفقرة 1: «Retirement can also take away the daily contact that people used to have with their colleagues»."
},
{
"q": "Some researchers have compared the effect of loneliness on health to smoking around ______ cigarettes a day.",
"o": [
"fifteen",
"five",
"fifty",
"twenty"
],
"e": "الفقرة 2: «compared its effect on health to that of smoking around fifteen cigarettes a day»."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"doctors",
"lonely patients",
"healthy meals",
"cigarettes"
],
"e": "«Doctors in some countries report that lonely patients visit them more often» ← المرضى يزورون الدكاترة ← them = doctors."
},
{
"q": "Lonely older people are more likely to suffer from heart disease and ______.",
"o": [
"poor sleep",
"poor eyesight",
"back pain",
"headaches"
],
"e": "الفقرة 2: «Lonely older people are more likely to suffer from heart disease and poor sleep»."
},
{
"q": "What does the underlined word \"connected\" in paragraph 3 mean?",
"o": [
"in contact with others",
"far from others",
"living alone",
"very busy"
],
"e": "«keep older people connected» وبعدها أمثلة يقابلون فيها ناس ← connected = متواصلين مع غيرهم."
},
{
"q": "In a home-share programme, who does the student live with?",
"o": [
"an older person",
"a classmate",
"a doctor",
"a teacher"
],
"e": "الفقرة 3: «a student lives with an older person for a very low rent and, in return, spends time with them and helps with jobs around the house»."
},
{
"q": "Why does the writer suggest showing an older relative how to make video calls?",
"o": [
"to see family far away",
"to work from home",
"to watch films",
"to call doctors"
],
"e": "الفقرة 4: «show an older relative how to make video calls so that they can see family members who live far away»."
},
{
"q": "What do the underlined words \"check on\" in paragraph 4 mean?",
"o": [
"ask about",
"forget about",
"pay for",
"complain about"
],
"e": "«we will also hope that someone remembers to check on us» = يسأل عنّا ويتطمّن علينا ← ask about."
},
{
"q": "What is the best title for the passage?",
"o": [
"Loneliness in old age and how we can help",
"How students can save money on rent",
"The dangers of smoking",
"Why older people should keep working"
],
"e": "القطعة عن أسباب وحدة كبار السن وأضرارها (الفقرة 1 و2)، وكيف المجتمع وكل واحد فينا يقدر يساعد (الفقرة 3 و4)."
}
]
},
{
"n": 23,
"k": 21,
"title": "Can a Metro Change a Car City?",
"text": [
"1. For decades, Riyadh was designed around the car. Wide highways, cheap fuel and long distances between neighbourhoods meant that most families depended on private vehicles, and public transport played only a small role in daily life. As the population grew, this approach began to show its limits: traffic jams became longer, journeys became less predictable, and the city's air quality suffered. The Riyadh Metro, which opened to the public in stages from late 2024, is the city's most ambitious attempt to offer an alternative.",
"2. The system is impressive by any standard. It has six lines and dozens of stations, and its trains are driverless, which allows _them_ to run frequently and reliably. Supporters argue that its value goes far beyond saving time. A single train can carry hundreds of passengers who would otherwise each drive a car, so a well-used metro could considerably reduce congestion and emissions. It may also give more independence to people who cannot or do not want to drive, such as many students and older residents.",
"3. Nevertheless, building a metro is one thing; persuading people to _abandon_ their cars is another. Experience from other car-dependent cities suggests that habits change slowly. Many residents live far from the nearest station, and walking even a short distance in the summer heat is unpleasant. For these people, the metro only makes sense if the \"first and last mile\" (the trip from home to the station and from the station to the final destination) is easy. This is why planners have linked the metro to a large network of buses.",
"4. There is also the question of cost. A metro is extremely expensive to build and to operate, and its success is often judged by how many passengers use it. If few people use it, critics may argue that the money could have been better spent. On the other hand, transport projects are usually designed for the long term. A city that is expected to keep growing for decades cannot simply keep building wider roads, because new roads tend to attract even more traffic.",
"5. In the end, the metro's real test will not be its technology but people's behaviour. If it becomes a normal part of daily life, the way students reach their universities and employees reach their offices, it could gradually reshape how the city grows, encouraging homes, shops and workplaces to _cluster_ around stations. If not, it may remain an impressive system that many residents admire but rarely use. Either way, it represents a significant shift in how Riyadh thinks about moving people rather than simply moving cars."
],
"qs": [
{
"q": "According to the writer, most families in Riyadh depended on cars because of ______.",
"o": [
"wide highways, cheap fuel and long distances",
"long traffic jams and poor air quality",
"the opening of the Riyadh Metro",
"the lack of private vehicles"
],
"e": "الفقرة 1: «Wide highways, cheap fuel and long distances between neighbourhoods meant that most families depended on private vehicles». أما الزحمة وتلوّث الهوا فهي نتيجة (صارت بعدين) مو السبب."
},
{
"q": "What does the underlined word \"them\" in paragraph 2 refer to?",
"o": [
"the trains",
"the stations",
"the lines",
"the passengers"
],
"e": "«its trains are driverless, which allows them to run frequently» ← اللي تمشي بشكل متكرر هي القطارات، فـ them = the trains."
},
{
"q": "Which benefit of the metro does the writer NOT mention?",
"o": [
"creating new jobs for residents",
"reducing congestion",
"reducing emissions",
"giving more independence to people who do not drive"
],
"e": "الفقرة 2 ذكرت تقليل الزحمة والانبعاثات: «reduce congestion and emissions»، وذكرت الاستقلالية لمن ما يسوق: «give more independence to people who cannot or do not want to drive». أما الوظايف ما انذكرت أبداً."
},
{
"q": "What does the underlined word \"abandon\" in paragraph 3 mean?",
"o": [
"give up",
"repair",
"share",
"buy"
],
"e": "abandon = يتخلّى عن الشي ويتركه. «persuading people to abandon their cars» = إقناع الناس يتركون سياراتهم ← give up."
},
{
"q": "According to paragraph 3, the \"first and last mile\" is ______.",
"o": [
"the trip between the station and home or the final destination",
"the distance between two metro stations on the same line",
"the first and last train that runs every day of the week",
"the road between Riyadh and the other cities in the Kingdom"
],
"e": "الفقرة 3 شرحتها بين قوسين: «the trip from home to the station and from the station to the final destination»."
},
{
"q": "Why does the writer say that \"new roads tend to attract even more traffic\"?",
"o": [
"To explain why building wider roads is not a long-term solution",
"To show that the metro costs too much money to build and run",
"To prove that very few passengers have used the metro so far",
"To show that Riyadh has stopped growing and needs no new roads"
],
"e": "الفقرة 4: «cannot simply keep building wider roads, because new roads tend to attract even more traffic» ← الكاتب يوضح إن توسيع الطرق مو حل على المدى البعيد، عشان كذا المترو مشروع طويل المدى."
},
{
"q": "What does the underlined word \"cluster\" in paragraph 5 mean?",
"o": [
"gather together",
"close down",
"move away",
"grow smaller"
],
"e": "cluster = تتجمّع قريب من بعض. «encouraging homes, shops and workplaces to cluster around stations» = البيوت والمحلات تتجمّع حول المحطات ← gather together."
},
{
"q": "Which statement would the writer most likely agree with?",
"o": [
"Changing people's habits is harder than building the metro.",
"The metro's technology is its biggest weakness.",
"Riyadh should build more highways instead of a metro.",
"Walking to the stations is pleasant in the summer."
],
"e": "الفقرة 3: «building a metro is one thing; persuading people to abandon their cars is another» ← يعني إقناع الناس يتركون سياراتهم أصعب من بناء المترو. والخيارات الباقية غلط: الكاتب يقول النظام «impressive by any standard»، و«cannot simply keep building wider roads»، والمشي في حر الصيف «unpleasant»."
},
{
"q": "How would you describe the writer's attitude toward the metro?",
"o": [
"hopeful, but aware of its challenges",
"completely negative about its future",
"sure that it will fail very soon",
"not interested in the project at all"
],
"e": "الكاتب يمدحه: «The system is impressive by any standard» ويقول «it could gradually reshape how the city grows»، بس يذكر الصعوبات: «If not, it may remain an impressive system that many residents admire but rarely use» ← متفائل بس واقعي، ومو متأكد إنه بيفشل."
},
{
"q": "What is the best title for the passage?",
"o": [
"Can a Metro Change a Car City?",
"How the Metro Solved All of Riyadh's Problems",
"Why Riyadh Should Spend Its Money on Cars",
"Driverless Trains: Cheaper Than Buses"
],
"e": "القطعة تناقش المترو: مميزاته (الفقرة 2) وصعوباته (الفقرتين 3 و4)، والفقرة 5 تلخصها: «the metro's real test will not be its technology but people's behaviour» ← فأفضل عنوان: Can a Metro Change a Car City?"
}
]
},
{
"n": 24,
"k": 22,
"title": "Does Volunteering Always Help?",
"text": [
"1. Volunteering, giving time and skills without payment, is usually seen as something entirely positive. In recent years it has grown considerably in Saudi Arabia, where national plans aim to reach one million volunteers a year. Universities encourage students to take part, and many employers say that they value volunteer experience when they hire new staff. Yet researchers and charity workers increasingly argue that volunteering is not automatically beneficial; its value depends largely on how it is organised.",
"2. The benefits for volunteers themselves are well documented. Studies tend to find that people who volunteer regularly report greater life satisfaction and a stronger sense of purpose. Volunteering can also be a practical way to develop skills that are hard to learn in a classroom, such as managing a team, solving unexpected problems or communicating with people from different backgrounds. For a university student with little work experience, a well-chosen volunteer role can provide evidence of these abilities that a degree alone cannot.",
"3. The picture becomes more complicated when we look at the people and organisations that volunteers are meant to help. Charities often explain that untrained volunteers who appear for a single afternoon can create extra work: someone must train _them_, supervise them and correct their mistakes. In the worst cases, short visits to care homes or hospitals may satisfy the volunteers' wish to feel useful more than the real needs of the people there. This is why many organisations prefer a smaller number of _committed_ volunteers to a large crowd who come once and never return.",
"4. Motivation matters too. When students volunteer mainly to add a line to their CV, they may choose activities that look impressive rather than ones that match their skills or the community's needs. This does not mean that such volunteers do no good. However, research suggests that people whose motives are mainly about helping others tend to continue volunteering for longer, which benefits everyone involved.",
"5. None of this is an argument against volunteering. Rather, it suggests a more thoughtful approach. Before signing up, volunteers could ask what the organisation actually needs, whether they can commit to it regularly, and how their particular skills might be used. Organisations, for their part, can make roles clearer and offer proper training. When both sides take these steps, volunteering is far more likely to be what most people assume it already is: a _genuine_ benefit for the community and the volunteer alike."
],
"qs": [
{
"q": "According to the writer, the value of volunteering depends mainly on ______.",
"o": [
"how it is organised",
"how many volunteers take part",
"how much volunteers are paid",
"where volunteers study"
],
"e": "الفقرة 1 آخر جملة: «its value depends largely on how it is organised»."
},
{
"q": "Which skill does the writer NOT mention?",
"o": [
"writing reports",
"managing a team",
"solving unexpected problems",
"communicating with people from different backgrounds"
],
"e": "الفقرة 2 ذكرت: «managing a team, solving unexpected problems or communicating with people from different backgrounds»، وكتابة التقارير ما انذكرت."
},
{
"q": "According to paragraph 2, people who volunteer regularly tend to report ______.",
"o": [
"greater life satisfaction and a stronger sense of purpose",
"higher salaries and better jobs after university",
"less stress during their studies and exams",
"more free time and fewer problems at home"
],
"e": "الفقرة 2: «people who volunteer regularly report greater life satisfaction and a stronger sense of purpose»."
},
{
"q": "What does the underlined word \"them\" in paragraph 3 refer to?",
"o": [
"untrained volunteers",
"charities",
"care homes",
"the people in hospitals"
],
"e": "«untrained volunteers who appear for a single afternoon can create extra work: someone must train them» ← اللي يحتاجون تدريب هم المتطوعين غير المدرّبين."
},
{
"q": "The writer gives the example of short visits to care homes or hospitals to show that ______.",
"o": [
"some visits help the volunteers more than the people there",
"care homes and hospitals do not accept volunteers",
"volunteers should visit hospitals more often",
"short visits are the best kind of volunteering"
],
"e": "الفقرة 3: «short visits to care homes or hospitals may satisfy the volunteers' wish to feel useful more than the real needs of the people there» ← الزيارة القصيرة أحياناً تفيد المتطوع (يحس إنه مفيد) أكثر من الناس اللي هناك."
},
{
"q": "What does the underlined word \"committed\" in paragraph 3 mean?",
"o": [
"loyal and dedicated",
"well-paid and famous",
"untrained and new",
"temporary and busy"
],
"e": "committed = ملتزم ومخلص. والجملة تقارنهم بـ«a large crowd who come once and never return» ← الملتزمين هم اللي يجون بانتظام."
},
{
"q": "What can we understand from paragraph 4?",
"o": [
"Students who volunteer mainly for their CV may not continue for long.",
"Volunteers who want a better CV do no good at all.",
"Employers are not interested in volunteer experience.",
"Impressive activities always match the community's needs."
],
"e": "الفقرة 4: «people whose motives are mainly about helping others tend to continue volunteering for longer» ← نفهم إن اللي يتطوع عشان السيرة الذاتية بس ممكن ما يكمّل طويل. والفقرة نفسها تقول «This does not mean that such volunteers do no good»، فخيار (do no good at all) غلط."
},
{
"q": "What does the underlined word \"genuine\" in paragraph 5 mean?",
"o": [
"real",
"small",
"temporary",
"expensive"
],
"e": "genuine = حقيقي. «a genuine benefit for the community» = فايدة حقيقية للمجتمع ← real."
},
{
"q": "Which statement would the writer most likely agree with?",
"o": [
"Organisations should make volunteer roles clear and train volunteers properly.",
"Volunteering is always helpful, however it is organised.",
"Volunteers should choose activities that look impressive on a CV.",
"Volunteering has no benefits for the volunteers themselves."
],
"e": "الفقرة 5: «Organisations, for their part, can make roles clearer and offer proper training». والخيارات الباقية عكس كلام الكاتب: قال إن التطوع «not automatically beneficial»، وإن الأنشطة اللي «look impressive» ممكن ما تناسب احتياج المجتمع، وإن فوائده للمتطوع «well documented»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Does Volunteering Always Help?",
"Why Students Should Stop Volunteering",
"How to Find a Well-Paid Job",
"Life in Care Homes and Hospitals"
],
"e": "القطعة كلها تناقش هل التطوع مفيد دائمًا: الفقرة 1 «volunteering is not automatically beneficial; its value depends largely on how it is organised»، والفقرة 5 «None of this is an argument against volunteering» ← العنوان Does Volunteering Always Help? والكاتب ما قال وقّفوا التطوع."
}
]
},
{
"n": 25,
"k": 23,
"title": "Video Games: Harmful Habit or Useful Tool?",
"text": [
"1. Few forms of entertainment divide opinion as sharply as video games. For many parents and teachers, _they_ are a waste of time at best and a danger at worst, responsible for poor grades, lack of sleep and aggressive behaviour. For their supporters, games are a modern art form that can develop skills and bring people together. The evidence suggests that the truth lies somewhere between these two positions.",
"2. The fear that violent games make young people violent has received a great deal of attention, yet research has not provided a clear answer. Some laboratory studies have found that players feel slightly more aggressive immediately after playing, but these effects tend to be small and _short-lived_. Larger studies that follow young people over several years have generally failed to find a strong link between gaming and serious violence. Many researchers therefore argue that other factors, such as family life and friendships, are far more important.",
"3. On the positive side, a number of studies suggest that certain action games may improve visual attention, the ability to notice and follow several things on a screen at once. Puzzle and strategy games require planning and patience, and online team games can require players to communicate and cooperate under pressure. However, researchers are careful to point out that these benefits are often limited to tasks similar to the game itself. Becoming skilled at a fast-moving game does not necessarily make someone better at studying for an exam.",
"4. A more serious concern is the amount of time some players spend gaming. In 2019, the World Health Organization recognised \"gaming disorder\" as a medical condition, describing it as a pattern of play that a person cannot control and that continues despite harmful consequences for their studies, work or relationships. It is important to note that this condition affects only a small minority of players. For most people, the real risk is simply that games, which are designed to be highly rewarding, can push out other activities such as sleep, exercise and face-to-face conversation.",
"5. For this reason, many experts now focus less on whether games are good or bad and more on how they are used. Questions about what kind of game is being played, for how long, and at what cost to other parts of life are likely to be more useful than general _condemnation_. A teenager who plays with friends for an hour after finishing his homework is in a very different situation from one who plays alone until three in the morning. Treating both cases in the same way helps no one."
],
"qs": [
{
"q": "What does the underlined word \"they\" in paragraph 1 refer to?",
"o": [
"video games",
"parents and teachers",
"poor grades",
"supporters"
],
"e": "«For many parents and teachers, they are a waste of time» ← اللي يعتبرونها مضيعة للوقت هي الألعاب، فـ they = video games."
},
{
"q": "According to paragraph 1, many parents and teachers blame video games for ______.",
"o": [
"poor grades, lack of sleep and aggressive behaviour",
"poor eyesight, headaches and serious back pain",
"high costs, arguments and problems in the family",
"weak attention, poor planning and lack of patience"
],
"e": "الفقرة 1: «responsible for poor grades, lack of sleep and aggressive behaviour»."
},
{
"q": "What does the underlined word \"short-lived\" in paragraph 2 mean?",
"o": [
"lasting only a short time",
"very strong and serious",
"easy to notice at once",
"dangerous for a long time"
],
"e": "short-lived = ما يدوم إلا وقت قصير. والجملة تقول الشعور بالعدوانية يكون «immediately after playing» ويكون صغير ومؤقت."
},
{
"q": "What have larger studies that follow young people over several years generally found?",
"o": [
"There is no strong link between gaming and serious violence.",
"Violent games make most young people violent in later life.",
"Players feel much more aggressive for many years after playing.",
"Family life is much less important than the games people play."
],
"e": "الفقرة 2: «Larger studies that follow young people over several years have generally failed to find a strong link between gaming and serious violence»."
},
{
"q": "Which possible benefit of games does the writer NOT mention?",
"o": [
"learning a foreign language",
"better visual attention",
"planning and patience",
"communicating and cooperating with others"
],
"e": "الفقرة 3 ذكرت: «improve visual attention» و«require planning and patience» و«communicate and cooperate under pressure»، وتعلّم لغة أجنبية ما انذكر."
},
{
"q": "What can we understand from paragraph 3?",
"o": [
"A skill learned in a game may not help much with schoolwork.",
"Becoming skilled at action games makes students better at exams.",
"Puzzle and strategy games do not require any planning or patience.",
"Online team games stop players from communicating with each other."
],
"e": "الفقرة 3: «these benefits are often limited to tasks similar to the game itself. Becoming skilled at a fast-moving game does not necessarily make someone better at studying for an exam» ← المهارة من اللعبة ما تفيد بالضرورة في الدراسة."
},
{
"q": "According to paragraph 4, for most players the real risk is that games ______.",
"o": [
"can take time away from sleep, exercise and conversation",
"cause a serious medical condition that they cannot control",
"make them violent and aggressive towards other people",
"are too difficult and too expensive to play"
],
"e": "الفقرة 4: «For most people, the real risk is simply that games… can push out other activities such as sleep, exercise and face-to-face conversation». أما «gaming disorder» فالكاتب يقول «affects only a small minority of players»."
},
{
"q": "What does the underlined word \"condemnation\" in paragraph 5 mean?",
"o": [
"strong criticism",
"careful study",
"public praise",
"free time"
],
"e": "condemnation = انتقاد شديد ورفض. الكاتب يقول الأسئلة المحددة أفيد من إنك تنتقد الألعاب كلها بشكل عام."
},
{
"q": "The writer gives the example of two teenagers to show that ______.",
"o": [
"different ways of playing should not be judged in the same way",
"teenagers should never play after homework",
"playing with friends is more dangerous than playing alone",
"all teenagers who play games are addicted"
],
"e": "الفقرة 5: اللي يلعب ساعة مع أصحابه بعد واجبه «is in a very different situation from one who plays alone until three in the morning. Treating both cases in the same way helps no one»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Video Games: Harmful Habit or Useful Tool?",
"Why Video Games Make Young People Violent",
"How to Become a Professional Gamer",
"The History of the World Health Organization"
],
"e": "القطعة تعرض الرأيين: الضرر، ورأي المؤيدين إن «games are a modern art form that can develop skills»، وتقول «the truth lies somewhere between these two positions» ← العنوان يجمع الضرر والفايدة. وما قالت إن الألعاب تخلي الشباب عنيفين: «failed to find a strong link between gaming and serious violence»."
}
]
},
{
"n": 26,
"k": 24,
"title": "Farming Without Fields",
"text": [
"1. When we imagine a farm, we usually picture open fields, tractors and long rows of crops under the sun. Yet a growing number of companies are trying something very different: growing vegetables indoors, on tall stacks of shelves inside buildings in the middle of cities. This approach, known as vertical farming, uses LED lights instead of sunlight, and the plants often grow with their roots in water rich in nutrients rather than in soil. Supporters describe it as the future of food; critics are less convinced.",
"2. The arguments in its favour are attractive, particularly for countries with hot climates and limited water. Because the water in a vertical farm is collected and reused, supporters say that it can use far less water than traditional agriculture. Crops can be grown all year round, _regardless of_ the weather, and since insects can hardly get into a closed building, few or no pesticides are needed. Farms can also be built close to the people who will eat the food, which reduces the distance it has to travel and means that vegetables can reach shops fresher.",
"3. The main problem is energy. Sunlight is free, whereas the lights, heating and air-conditioning in an indoor farm must be paid for, and electricity costs can make the food expensive to produce. If that electricity comes from fossil fuels, the environmental benefits may be considerably smaller than they first appear. In recent years, several well-known vertical-farming companies in Europe and North America have closed or faced serious financial difficulties, partly because of rising energy prices.",
"4. There is also a limit to what can be grown. Leafy greens such as lettuce and herbs grow quickly and take up little space, so _they_ suit indoor farms well. Staple crops such as wheat and rice, on the other hand, need large areas and long growing periods, and producing them indoors is currently far too costly. Vertical farms are therefore unlikely to replace traditional farms; at most, they can _supplement_ them by supplying certain fresh products.",
"5. For countries like Saudi Arabia, which imports a large share of its food and has very limited water, the technology remains interesting, and a number of indoor farms have already been built in the region. Its long-term success, however, is likely to depend on cheaper renewable energy, particularly solar power. If energy costs fall, vertical farming could become a sensible part of a sustainable food system. Until then, it is perhaps best seen not as a revolution in agriculture but as a promising experiment."
],
"qs": [
{
"q": "According to paragraph 1, plants in a vertical farm often grow ______.",
"o": [
"with their roots in water rich in nutrients",
"in open fields under the summer sun",
"in large areas of soil rich in nutrients",
"without any kind of light or water at all"
],
"e": "الفقرة 1: «the plants often grow with their roots in water rich in nutrients rather than in soil»."
},
{
"q": "What do the underlined words \"regardless of\" in paragraph 2 mean?",
"o": [
"without being affected by",
"because of",
"only during",
"in order to change"
],
"e": "regardless of = بغض النظر عن. «Crops can be grown all year round, regardless of the weather» = يزرعون طول السنة والجو ما يأثّر ← without being affected by."
},
{
"q": "Why are few or no pesticides needed in a vertical farm?",
"o": [
"Insects can hardly get into a closed building.",
"The plants grow without any water at all.",
"The LED lights are strong enough to kill insects.",
"The farms are built far away from cities."
],
"e": "الفقرة 2: «since insects can hardly get into a closed building, few or no pesticides are needed» ← الحشرات ما تقدر تدخل المبنى المقفل تقريباً."
},
{
"q": "Which advantage of vertical farming does the writer NOT mention?",
"o": [
"cheaper vegetables for shoppers",
"using less water",
"growing crops all year round",
"vegetables reaching shops fresher"
],
"e": "الفقرة 2 ذكرت: «far less water» و«all year round» و«vegetables can reach shops fresher». أما الخضار الأرخص ما انذكرت كميزة، بالعكس الفقرة 3 تقول الطاقة «can make the food expensive to produce»."
},
{
"q": "Why does the writer mention that several vertical-farming companies have closed?",
"o": [
"To show that the cost of energy is a real problem",
"To show that vertical farms use too much water",
"To prove that indoor farms in Saudi Arabia will close",
"To explain why lettuce grows quickly"
],
"e": "الفقرة 3 تبدأ بـ«The main problem is energy» وتختم إن الشركات سكّرت أو تعثّرت «partly because of rising energy prices» ← المثال يوضّح إن غلاء الطاقة مشكلة حقيقية."
},
{
"q": "What does the underlined word \"they\" in paragraph 4 refer to?",
"o": [
"leafy greens such as lettuce and herbs",
"indoor farms",
"staple crops such as wheat and rice",
"traditional farms"
],
"e": "«Leafy greens such as lettuce and herbs grow quickly and take up little space, so they suit indoor farms well» ← اللي تناسب المزارع الداخلية هي الخضار الورقية."
},
{
"q": "What does the underlined word \"supplement\" in paragraph 4 mean?",
"o": [
"add to",
"replace",
"damage",
"compete with"
],
"e": "supplement = يكمّل ويضيف. الجملة قبلها تقول «unlikely to replace traditional farms» ← ما تحل محلها، بس تضيف لها منتجات طازجة ← add to."
},
{
"q": "What can we understand from paragraph 4?",
"o": [
"Vertical farms are unlikely to provide most of the world's wheat and rice.",
"Lettuce and herbs need large areas and long growing periods.",
"Wheat and rice grow faster indoors than lettuce and herbs do.",
"Traditional farms will soon disappear because of vertical farms."
],
"e": "الفقرة 4: القمح والرز «need large areas and long growing periods, and producing them indoors is currently far too costly» ← فالمزارع العمودية ما راح توفر أغلب القمح والرز."
},
{
"q": "Which statement would the writer most likely agree with?",
"o": [
"Cheaper renewable energy could make vertical farming more successful.",
"Vertical farming has already replaced traditional agriculture.",
"Countries with little water should not try indoor farming.",
"Energy costs are not important for indoor farms."
],
"e": "الفقرة 5: «Its long-term success, however, is likely to depend on cheaper renewable energy… If energy costs fall, vertical farming could become a sensible part of a sustainable food system»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Vertical Farming: A Promising but Costly Idea",
"How to Grow Wheat and Rice Indoors",
"Why Traditional Farms Will Disappear",
"The History of Farming in Saudi Arabia"
],
"e": "القطعة تذكر مميزات المزارع العمودية ومشكلة غلاء الطاقة، وتختم: «it is perhaps best seen not as a revolution in agriculture but as a promising experiment» ← فكرة واعدة بس مكلفة."
}
]
},
{
"n": 27,
"k": 25,
"title": "Can Mistakes Help Us Learn?",
"text": [
"1. Most students are taught, directly or indirectly, that mistakes are something to avoid. A wrong answer loses marks, and a low grade can feel like a judgement on a person's intelligence. Yet a large body of research in psychology and education suggests that making errors, and more importantly paying attention to them, is one of the most effective ways to learn.",
"2. One reason is that mistakes show us exactly where our understanding is weak. A student who gets every question right on a practice test learns relatively little about what to study next, whereas one who gets several questions wrong has a clear map of the gaps in his knowledge. Studies of what is sometimes called the \"pretesting effect\" have found that trying to answer a question, even unsuccessfully, before being told the answer often helps people remember the correct information better later. In other words, the effort of struggling appears to prepare the brain to learn.",
"3. Attitudes towards mistakes also matter. The psychologist Carol Dweck became famous for the idea of a \"growth mindset\": the belief that abilities can be developed through effort and good strategies, rather than being fixed from birth. According to this view, students who see a poor result as information, rather than as proof that they are \"not clever enough\", are more likely to keep trying and, eventually, to improve. The idea has been _enormously_ popular in schools around the world.",
"4. However, the story is not as simple as it once seemed. Some large studies that tried to repeat the early research found that programmes designed to teach a growth mindset had, on average, only small effects on students' grades. Critics argue that the concept was sometimes reduced to slogans, such as telling children to \"try harder\", without teaching them how to study more effectively. Effort alone, _they_ point out, is not enough if a student keeps repeating the same unsuccessful method.",
"5. What, then, should students take from this? The evidence suggests that mistakes are valuable only when they are examined. Simply noticing that an answer was wrong is less useful than asking why it was wrong and what should be done differently next time. A student who keeps a short list of errors from past homework and tests, and reviews it before an exam, is using mistakes in the way research recommends. Seen like this, a wrong answer is not a _setback_ but a piece of feedback, and often a more useful one than a correct answer."
],
"qs": [
{
"q": "According to paragraph 1, a low grade can feel like ______.",
"o": [
"a judgement on a person's intelligence",
"a useful piece of feedback",
"a clear map of what to study",
"a reason to keep trying"
],
"e": "الفقرة 1: «a low grade can feel like a judgement on a person's intelligence» ← الطالب يحس الدرجة حكم على ذكائه."
},
{
"q": "According to studies of the \"pretesting effect\", trying to answer a question before being told the answer ______.",
"o": [
"often helps people remember the correct information better",
"always leads people to the correct answer the first time",
"makes people forget the correct information more quickly",
"is only useful when the person's first answer is correct"
],
"e": "الفقرة 2: «trying to answer a question, even unsuccessfully, before being told the answer often helps people remember the correct information better later»."
},
{
"q": "The writer gives the example of two students and a practice test to show that ______.",
"o": [
"wrong answers show a student what he needs to study",
"practice tests are a waste of time",
"good students never make mistakes",
"students should not take practice tests before exams"
],
"e": "الفقرة 2: اللي جاوب كل شي صح «learns relatively little about what to study next»، واللي غلط في كم سؤال «has a clear map of the gaps in his knowledge» ← الأخطاء توضح له وش يذاكر."
},
{
"q": "According to the idea of a \"growth mindset\", abilities ______.",
"o": [
"can be developed through effort and good strategies",
"are fixed from birth and cannot be developed",
"cannot be changed after students leave school",
"are the same in every student, whatever they do"
],
"e": "الفقرة 3: «the belief that abilities can be developed through effort and good strategies, rather than being fixed from birth»."
},
{
"q": "What does the underlined word \"enormously\" in paragraph 3 mean?",
"o": [
"very greatly",
"slightly",
"rarely",
"recently"
],
"e": "enormously = بشكل كبير جداً. «The idea has been enormously popular in schools around the world» = الفكرة انتشرت انتشار كبير جداً ← very greatly."
},
{
"q": "What can we understand from paragraph 4?",
"o": [
"Early hopes for growth-mindset programmes were probably too high.",
"Growth-mindset programmes greatly improved most students' grades.",
"Growth-mindset programmes had no effect on any student.",
"Nobody tried to repeat the early research."
],
"e": "الفقرة 4: «the story is not as simple as it once seemed» والدراسات الكبيرة لقت «only small effects on students' grades» ← نفهم إن التوقعات الأولى كانت أكبر من النتيجة."
},
{
"q": "What does the underlined word \"they\" in paragraph 4 refer to?",
"o": [
"critics",
"students",
"children",
"large studies"
],
"e": "«Critics argue that… Effort alone, they point out, is not enough» ← اللي يوضّحون هذا الكلام هم النقّاد (critics)."
},
{
"q": "What does the underlined word \"setback\" in paragraph 5 mean?",
"o": [
"a problem that delays your progress",
"a useful piece of information",
"a correct answer",
"a short list of errors"
],
"e": "setback = انتكاسة أو عقبة تأخّرك. الكاتب يقول الغلط مو عقبة «but a piece of feedback» ← يعني setback عكس «a piece of feedback»، فخيار (a useful piece of information) غلط."
},
{
"q": "Which statement would the writer most likely agree with?",
"o": [
"Asking why an answer was wrong is more useful than just noticing it.",
"Students should try to avoid all mistakes in their homework and tests.",
"Effort alone always leads to better grades, whatever method students use.",
"Correct answers always teach students more than wrong answers do."
],
"e": "الفقرة 5: «Simply noticing that an answer was wrong is less useful than asking why it was wrong and what should be done differently next time»."
},
{
"q": "What is the best title for the passage?",
"o": [
"Can Mistakes Help Us Learn?",
"How to Get Full Marks in Every Test",
"The Life Story of Carol Dweck",
"Why Teachers Should Stop Giving Grades"
],
"e": "القطعة كلها عن فايدة الأخطاء في التعلّم: الفقرة 1 «making errors, and more importantly paying attention to them, is one of the most effective ways to learn»، والفقرة 5 «mistakes are valuable only when they are examined» ← Can Mistakes Help Us Learn? (وCarol Dweck انذكرت فكرتها بس، مو قصة حياتها)."
}
]
}
];
